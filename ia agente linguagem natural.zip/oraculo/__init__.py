"""
ORÁCULO — Agente de IA 100% Offline para Android (Termux)

Assistente de voz que ouve, entende, executa e responde — tudo no seu bolso.
"""

__version__ = "1.0.0"
__author__ = "ORÁCULO Project"
__license__ = "MIT"