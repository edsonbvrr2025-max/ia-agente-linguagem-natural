"""
Implementação das ferramentas de memória (function calling).
Estas funções são chamadas pelo LLM via function calling.
"""

from typing import Dict, Any, List, Optional
from oraculo.memory import create_memory, MemoryFact
from oraculo.config import get_config
from oraculo.utils.logger import get_logger

logger = get_logger(__name__)


class MemoryTools:
    """Wrapper para ferramentas de memória expostas ao LLM."""

    def __init__(self):
        self.config = get_config().memory
        self.file_memory = None
        self.vector_memory = None
        self._init_memories()

    def _init_memories(self):
        """Inicializa backends de memória."""
        # File memory (sempre)
        self.file_memory = create_memory(
            "file",
            file_path=Path(self.config.file_path),
            profile_path=Path(self.config.profile_path),
        )
        self.file_memory.load()

        # Vector memory (opcional)
        if self.config.use_vector:
            self.vector_memory = create_memory(
                "vector",
                db_path=Path(self.config.vector_db),
                embedding_model=Path(self.config.embedding_model),
                file_memory=self.file_memory,
            )
            self.vector_memory.load()
            # Sync inicial
            self.vector_memory.sync_from_file_memory()

    # =========================================================================
    # FERRAMENTAS EXPOSTAS AO LLM
    # =========================================================================

    def memoria_adicionar(
        self,
        secao: str,
        chave: str,
        valor: str,
        contexto: str = ""
    ) -> Dict[str, Any]:
        """
        Adiciona fato à memória.

        Args:
            secao: "Contatos" | "Preferências" | "Rotinas" | "Fatos Diversos"
            chave: Identificador único (ex: "mãe", "alarme_manha")
            valor: Valor completo (ex: "Maria Silva, +55 11 99999-9999, WhatsApp")
            contexto: Info adicional opcional

        Returns:
            Dict com sucesso e mensagem
        """
        try:
            success = self.file_memory.adicionar(secao, chave, valor, contexto)

            if success and self.vector_memory:
                self.vector_memory.adicionar(secao, chave, valor, contexto)

            if success:
                return {
                    "success": True,
                    "message": f"Adicionado em {secao}: {chave} = {valor}",
                }
            else:
                return {
                    "success": False,
                    "message": f"Falha ao adicionar. Seção inválida: {secao}",
                }

        except Exception as e:
            logger.error(f"Erro em memoria_adicionar: {e}")
            return {"success": False, "message": f"Erro: {e}"}

    def memoria_remover(self, secao: str, chave: str) -> Dict[str, Any]:
        """Remove fato da memória."""
        try:
            success = self.file_memory.remover(secao, chave)

            if success and self.vector_memory:
                self.vector_memory.remover(secao, chave)

            if success:
                return {
                    "success": True,
                    "message": f"Removido de {secao}: {chave}",
                }
            else:
                return {
                    "success": False,
                    "message": f"Não encontrado: {chave} em {secao}",
                }

        except Exception as e:
            logger.error(f"Erro em memoria_remover: {e}")
            return {"success": False, "message": f"Erro: {e}"}

    def memoria_buscar(self, query: str, secao: str = "Todas") -> Dict[str, Any]:
        """Busca fatos na memória."""
        try:
            # Usa vector se disponível, senão file
            if self.vector_memory and self.config.use_vector:
                results = self.vector_memory.buscar(query, secao, top_k=self.config.top_k)
            else:
                results = self.file_memory.buscar(query, secao, top_k=self.config.top_k)

            if not results:
                return {
                    "success": True,
                    "message": f"Nenhum resultado para '{query}'",
                    "facts": [],
                }

            facts_list = [
                {
                    "secao": f.secao,
                    "chave": f.chave,
                    "valor": f.valor,
                    "contexto": f.contexto,
                }
                for f in results
            ]

            return {
                "success": True,
                "message": f"Encontrados {len(results)} resultado(s)",
                "facts": facts_list,
            }

        except Exception as e:
            logger.error(f"Erro em memoria_buscar: {e}")
            return {"success": False, "message": f"Erro: {e}", "facts": []}

    def memoria_listar(self, secao: str = "Todas") -> Dict[str, Any]:
        """Lista fatos da memória."""
        try:
            results = self.file_memory.listar(secao)

            if not results:
                return {
                    "success": True,
                    "message": f"Memória vazia" + (f" na seção {secao}" if secao != "Todas" else ""),
                    "facts": [],
                }

            facts_list = [
                {
                    "secao": f.secao,
                    "chave": f.chave,
                    "valor": f.valor,
                    "contexto": f.contexto,
                }
                for f in results
            ]

            return {
                "success": True,
                "message": f"{len(results)} fato(s) em {secao}",
                "facts": facts_list,
            }

        except Exception as e:
            logger.error(f"Erro em memoria_listar: {e}")
            return {"success": False, "message": f"Erro: {e}", "facts": []}


# Instância global
_memory_tools: Optional[MemoryTools] = None


def get_memory_tools() -> MemoryTools:
    """Retorna instância singleton de MemoryTools."""
    global _memory_tools
    if _memory_tools is None:
        _memory_tools = MemoryTools()
    return _memory_tools


# Funções de conveniência para function calling direto
def memoria_adicionar(secao: str, chave: str, valor: str, contexto: str = "") -> Dict[str, Any]:
    return get_memory_tools().memoria_adicionar(secao, chave, valor, contexto)


def memoria_remover(secao: str, chave: str) -> Dict[str, Any]:
    return get_memory_tools().memoria_remover(secao, chave)


def memoria_buscar(query: str, secao: str = "Todas") -> Dict[str, Any]:
    return get_memory_tools().memoria_buscar(query, secao)


def memoria_listar(secao: str = "Todas") -> Dict[str, Any]:
    return get_memory_tools().memoria_listar(secao)


# Mapeamento nome -> função para dispatch
MEMORY_TOOL_FUNCTIONS = {
    "memoria_adicionar": memoria_adicionar,
    "memoria_remover": memoria_remover,
    "memoria_buscar": memoria_buscar,
    "memoria_listar": memoria_listar,
}


def execute_memory_tool(name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
    """Executa ferramenta de memória por nome."""
    func = MEMORY_TOOL_FUNCTIONS.get(name)
    if not func:
        return {"success": False, "message": f"Ferramenta desconhecida: {name}"}
    return func(**arguments)