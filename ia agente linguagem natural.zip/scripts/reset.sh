#!/bin/bash
# ORÁCULO — Reset completo (limpa tudo e reinstala)
# USE COM CUIDADO — APAGA MEMÓRIA, CONFIG, MODELOS, LOGS

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[AVISO]${NC} $1"; }
log_error() { echo -e "${RED}[ERRO]${NC} $1"; }

echo "=========================================="
echo "  ⚠️  ORÁCULO — RESET COMPLETO"
echo "=========================================="
echo ""
log_error "ISTO VAI APAGAR TUDO:"
echo "  - memoria.md (sua memória pessoal)"
echo "  - perfil.md (seu perfil)"
echo "  - config.yaml (configurações)"
echo "  - memory/vectors.db (índice vetorial)"
echo "  - models/ (todos os modelos baixados)"
echo "  - logs/ (logs)"
echo "  - backups/ (backups)"
echo "  - .buildozer/ (cache de build)"
echo "  - bin/ (APKs gerados)"
echo "  - __pycache__/ .pytest_cache/ etc."
echo ""
log_warn "FAÇA BACKUP ANTES: bash scripts/backup.sh"
echo ""

read -p "Tem certeza? Digite 'RESET' para confirmar: " CONFIRM
if [ "$CONFIRM" != "RESET" ]; then
    log_info "Cancelado."
    exit 0
fi

echo ""
log_info "Fazendo backup de segurança automático..."
bash scripts/backup.sh

echo ""
log_info "Limpando arquivos..."

# Remove arquivos de dados
rm -f memoria.md perfil.md config.yaml
rm -rf memory/vectors.db
rm -rf models/llm/* models/stt/* models/tts/* models/embeddings/*
rm -rf logs/*
rm -rf backups/*
rm -rf .buildozer/*
rm -rf bin/*
rm -rf __pycache__ .pytest_cache .coverage htmlcov
find . -name "*.pyc" -delete
find . -name "*.pyo" -delete
find . -name "*$py.class" -delete

# Recria arquivos base
log_info "Recriando arquivos base..."

cat > memoria.md << 'EOF'
# Memória do ORÁCULO

## Contatos

## Preferências

## Rotinas

## Fatos Diversos
EOF

cat > perfil.md << 'EOF'
# Perfil do Usuário

**Nome**: 
**Cidade**: 
**Fuso Horário**: 
**Idioma**: pt-BR
**Estilo de Comunicação**: informal, direto, coloquial
EOF

# config.yaml será restaurado do git se existir, senão usa default
if git show HEAD:config.yaml > config.yaml 2>/dev/null; then
    log_ok "config.yaml restaurado do git"
else
    log_warn "config.yaml não no git, crie manualmente ou rode instalador"
fi

# Recria diretórios
mkdir -p models/llm models/stt models/tts models/embeddings memory backups logs

log_ok "Reset concluído!"
echo ""
echo "Próximos passos:"
echo "  1. Edite config.yaml e perfil.md"
echo "  2. Baixe modelos: bash scripts/download_models.sh --all"
echo "  3. Configure ADB: bash scripts/setup_adb_wireless.sh"
echo "  4. Teste: python -m tests.test_stt"
echo ""