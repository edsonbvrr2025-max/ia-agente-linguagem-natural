"""
LLM via llama.cpp Python bindings — Modelo local GGUF com function calling.

Requer:
- pip install llama-cpp-python (ou compilar no Termux com Vulkan)
- Modelo GGUF em models/llm/

Modelos recomendados (3B-4B, Q4_K_M):
- Qwen2.5-3B-Instruct-Q4_K_M.gguf      ~2.1 GB  ← RECOMENDADO (melhor pt-BR, function calling)
- Llama-3.2-3B-Instruct-Q4_K_M.gguf     ~2.0 GB
- Gemma-3-4B-IT-Q4_K_M.gguf             ~2.5 GB
- Phi-4-mini-Instruct-Q4_K_M.gguf       ~1.8 GB  (mais rápido, menos capaz)

Download: https://huggingface.co/collections/quantized-models
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional

from oraculo.llm import LLMEngine, LLMResponse, ToolCall, register_engine
from oraculo.utils.logger import get_logger

logger = get_logger(__name__)


class LlamaCppLLM(LLMEngine):
    """Wrapper para llama-cpp-python."""

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        super().__init__(model_path, config)
        self.llm = None
        self._model_params = {
            "n_ctx": config.get("n_ctx", 4096),
            "n_gpu_layers": config.get("n_gpu_layers", -1),
            "n_threads": config.get("threads", 4),
            "verbose": False,
            "use_mmap": True,
            "use_mlock": False,  # Pode causar OOM no Android
        }
        self._gen_params = {
            "temperature": config.get("temperature", 0.3),
            "top_p": config.get("top_p", 0.9),
            "top_k": config.get("top_k", 40),
            "repeat_penalty": config.get("repeat_penalty", 1.1),
        }

    def load(self) -> bool:
        """Carrega modelo GGUF."""
        try:
            from llama_cpp import Llama
        except ImportError:
            logger.error(
                "llama-cpp-python não instalado.\n"
                "Termux (CPU): pip install llama-cpp-python\n"
                "Termux (Vulkan): pip install llama-cpp-python --extra-index-url=https://abetlen.github.io/llama-cpp-python/whl/vulkan"
            )
            return False

        if not self.model_path.exists():
            logger.error(f"Modelo GGUF não encontrado: {self.model_path}")
            logger.info("Baixe em: https://huggingface.co/collections/quantized-models")
            return False

        logger.info(f"Carregando modelo: {self.model_path}")
        logger.info(f"Params: {self._model_params}")

        try:
            self.llm = Llama(
                model_path=str(self.model_path),
                **self._model_params,
            )
            self._loaded = True
            logger.info("Modelo carregado com sucesso")
            return True
        except Exception as e:
            logger.error(f"Erro carregando modelo: {e}")
            return False

    def generate(
        self,
        prompt: str,
        tools: Optional[List[Dict]] = None,
        tool_choice: str = "auto",
        max_tokens: int = 512,
        temperature: float = 0.3,
        stop: Optional[List[str]] = None,
    ) -> LLMResponse:
        """Gera resposta usando llama.cpp."""
        if not self._loaded:
            if not self.load():
                return LLMResponse(text="", tool_calls=[], model="llama_cpp")

        # Prepara parâmetros de geração
        gen_params = self._gen_params.copy()
        gen_params.update({
            "max_tokens": max_tokens,
            "temperature": temperature,
        })
        if stop:
            gen_params["stop"] = stop

        # Adiciona tools se function calling habilitado
        if tools and self.config.get("function_calling", True):
            gen_params["tools"] = tools
            gen_params["tool_choice"] = tool_choice

        logger.debug(f"Gerando resposta (max_tokens={max_tokens}, temp={temperature})")

        try:
            # llama-cpp-python usa create_chat_completion para function calling
            if tools:
                # Converte prompt para formato chat
                messages = self._prompt_to_messages(prompt)
                response = self.llm.create_chat_completion(
                    messages=messages,
                    **gen_params,
                )
                return self._parse_chat_response(response)
            else:
                # Completion simples
                response = self.llm.create_completion(prompt, **gen_params)
                return self._parse_completion_response(response)

        except Exception as e:
            logger.error(f"Erro na geração: {e}")
            return LLMResponse(text=f"Erro: {e}", tool_calls=[], model="llama_cpp")

    def _prompt_to_messages(self, prompt: str) -> List[Dict[str, str]]:
        """Converte prompt simples para formato chat messages."""
        # Assume prompt tem system + user
        # Formato esperado: system prompt primeiro, depois user
        parts = prompt.split("\n\nUser: ", 1)
        if len(parts) == 2:
            system_content = parts[0].replace("System: ", "").strip()
            user_content = parts[1].strip()
            return [
                {"role": "system", "content": system_content},
                {"role": "user", "content": user_content},
            ]
        else:
            # Fallback: tudo como user
            return [{"role": "user", "content": prompt}]

    def _parse_chat_response(self, response: Dict) -> LLMResponse:
        """Parseia resposta do create_chat_completion."""
        try:
            choice = response["choices"][0]
            message = choice["message"]

            text = message.get("content", "") or ""
            tool_calls = []

            if "tool_calls" in message:
                for tc in message["tool_calls"]:
                    if tc["type"] == "function":
                        tool_calls.append({
                            "name": tc["function"]["name"],
                            "arguments": json.loads(tc["function"]["arguments"]),
                            "call_id": tc["id"],
                        })

            usage = response.get("usage", {})
            return LLMResponse(
                text=text.strip(),
                tool_calls=tool_calls,
                usage=usage,
                model="llama_cpp",
            )
        except Exception as e:
            logger.error(f"Erro parseando chat response: {e}")
            return LLMResponse(text="", tool_calls=[], model="llama_cpp")

    def _parse_completion_response(self, response: Dict) -> LLMResponse:
        """Parseia resposta do create_completion."""
        try:
            choice = response["choices"][0]
            text = choice.get("text", "")
            usage = response.get("usage", {})
            return LLMResponse(
                text=text.strip(),
                tool_calls=[],
                usage=usage,
                model="llama_cpp",
            )
        except Exception as e:
            logger.error(f"Erro parseando completion response: {e}")
            return LLMResponse(text="", tool_calls=[], model="llama_cpp")

    def tokenize(self, text: str) -> List[int]:
        """Tokeniza texto."""
        if not self._loaded:
            return []
        return self.llm.tokenize(text.encode("utf-8"))

    def detokenize(self, tokens: List[int]) -> str:
        """Detokeniza."""
        if not self._loaded:
            return ""
        return self.llm.detokenize(tokens).decode("utf-8", errors="ignore")

    def unload(self) -> None:
        """Libera modelo."""
        if self.llm:
            del self.llm
            self.llm = None
        self._loaded = False


# Registra engine
register_engine("llama_cpp", LlamaCppLLM)


def download_model(model_name: str, output_dir: Path) -> bool:
    """
    Baixa modelo GGUF do Hugging Face.

    Modelos recomendados:
    - Qwen2.5-3B-Instruct-Q4_K_M.gguf
    - Llama-3.2-3B-Instruct-Q4_K_M.gguf
    - Gemma-3-4B-IT-Q4_K_M.gguf
    - Phi-4-mini-Instruct-Q4_K_M.gguf
    """
    import urllib.request

    # Mapeia nomes amigáveis para repos HF
    model_map = {
        "qwen2.5-3b-q4": "Qwen/Qwen2.5-3B-Instruct-GGUF",
        "llama-3.2-3b-q4": "meta-llama/Llama-3.2-3B-Instruct-GGUF",
        "gemma-3-4b-q4": "google/gemma-3-4b-it-GGUF",
        "phi-4-mini-q4": "microsoft/Phi-4-mini-instruct-GGUF",
    }

    if model_name not in model_map:
        logger.error(f"Modelo desconhecido: {model_name}. Opções: {list(model_map.keys())}")
        return False

    repo = model_map[model_name]
    filename = f"{model_name}.gguf"
    url = f"https://huggingface.co/{repo}/resolve/main/{filename}"
    output_path = output_dir / filename

    output_dir.mkdir(parents=True, exist_ok=True)

    if output_path.exists():
        logger.info(f"Modelo já existe: {output_path}")
        return True

    logger.info(f"Baixando {filename} de {repo}...")
    logger.warning("Arquivo ~2 GB — pode demorar")

    try:
        urllib.request.urlretrieve(url, output_path)
        logger.info(f"Modelo baixado: {output_path} ({output_path.stat().st_size / 1024 / 1024:.1f} MB)")
        return True
    except Exception as e:
        logger.error(f"Erro baixando modelo: {e}")
        return False


def compile_llama_cpp_python(vulkan: bool = False) -> bool:
    """
    Compila llama-cpp-python no Termux.

    Args:
        vulkan: Se True, compila com suporte Vulkan (requer NDK, libvulkan)
    """
    from oraculo.utils.helpers import run_command, check_command_exists

    if not check_command_exists("pip"):
        logger.error("pip não instalado: pkg install python-pip")
        return False

    if not check_command_exists("cmake"):
        logger.error("cmake não instalado: pkg install cmake")
        return False

    if vulkan:
        logger.info("Instalando llama-cpp-python com Vulkan...")
        # No Termux, precisa compilar localmente
        cmd = [
            "pip", "install", "llama-cpp-python",
            "--no-binary", "llama-cpp-python",
            "-v",
        ]
        env = {
            "GGML_VULKAN": "1",
            "CMAKE_ARGS": "-DGGML_VULKAN=ON",
        }
    else:
        logger.info("Instalando llama-cpp-python (CPU)...")
        cmd = ["pip", "install", "llama-cpp-python"]

    result = run_command(cmd, timeout=600, capture=False)
    return result[0] == 0