"""
Testes para TTS.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from oraculo.config import get_config
from oraculo.tts import create_tts, list_engines
from oraculo.utils.logger import setup_logging


def test_tts_engines():
    print("Engines TTS registradas:", list_engines())


def test_piper():
    config = get_config()
    tts_config = config.tts

    if tts_config.engine != "piper":
        print(f"Engine configurado é {tts_config.engine}")
        return True

    model_path = Path(tts_config.model)
    if not model_path.exists():
        print(f"Modelo Piper não encontrado: {model_path}")
        print("Baixe com: bash scripts/download_models.sh --tts piper_medium")
        return False

    tts = create_tts("piper", model_path, tts_config.__dict__)
    if not tts or not tts.load():
        print("Falha carregando Piper")
        return False

    # Teste síntese
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        temp_path = Path(f.name)

    try:
        result = tts.synthesize("Olá, sou o ORÁCULO. Teste de voz.", temp_path)
        if result.success:
            print(f"Piper OK: {temp_path} ({result.duration:.1f}s)")
            # Tenta tocar
            from oraculo.utils.audio import play_audio
            play_audio(temp_path)
            return True
        else:
            print(f"Piper falhou: {result.error}")
            return False
    finally:
        temp_path.unlink(missing_ok=True)


def test_espeak_ng():
    config = get_config()
    tts_config = config.tts

    if tts_config.engine != "espeak_ng":
        print(f"Engine configurado é {tts_config.engine}")
        return True

    from oraculo.tts.espeak_ng import EspeakNGTTS
    tts = EspeakNGTTS(Path("dummy"), tts_config.__dict__)
    if not tts.load():
        print("espeak-ng não disponível")
        return True  # Não é erro se não for engine principal

    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        temp_path = Path(f.name)

    try:
        result = tts.synthesize("Teste espeak NG.", temp_path)
        if result.success:
            print(f"espeak-ng OK: {temp_path} ({result.duration:.1f}s)")
            from oraculo.utils.audio import play_audio
            play_audio(temp_path)
            return True
        else:
            print(f"espeak-ng falhou: {result.error}")
            return False
    finally:
        temp_path.unlink(missing_ok=True)


def test_sherpa_onnx():
    config = get_config()
    tts_config = config.tts

    if tts_config.engine != "sherpa_onnx":
        print(f"Engine configurado é {tts_config.engine}")
        return True

    model_path = Path(tts_config.model)
    if not model_path.exists():
        print(f"Modelo Sherpa-ONNX não encontrado: {model_path}")
        return False

    from oraculo.tts.sherpa_onnx import SherpaOnnxTTS
    tts = SherpaOnnxTTS(model_path, tts_config.__dict__)
    if not tts.load():
        print("Falha carregando Sherpa-ONNX")
        return False

    print("Sherpa-ONNX carregado OK")
    return True


def main():
    setup_logging()
    print("="*50)
    print("  TESTE TTS")
    print("="*50)

    test_tts_engines()
    print()

    all_passed = True
    all_passed &= test_piper()
    all_passed &= test_espeak_ng()
    all_passed &= test_sherpa_onnx()

    print("\n" + "="*50)
    if all_passed:
        print("  ✅ TODOS OS TESTES PASSARAM")
    else:
        print("  ❌ ALGUNS TESTES FALHARAM")
    print("="*50)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())