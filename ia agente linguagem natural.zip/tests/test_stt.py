"""
Testes para STT.
"""
import sys
from pathlib import Path

# Adiciona raiz do projeto ao path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from oraculo.config import get_config
from oraculo.stt import create_stt, list_engines
from oraculo.utils.logger import setup_logging


def test_stt_engines():
    """Lista engines disponíveis."""
    print("Engines STT registradas:", list_engines())


def test_whisper_cpp():
    """Testa whisper.cpp se disponível."""
    config = get_config()
    stt_config = config.stt

    if stt_config.engine != "whisper_cpp":
        print(f"Engine configurado é {stt_config.engine}, pulando teste whisper.cpp")
        return True

    model_path = Path(stt_config.model)
    if not model_path.exists():
        print(f"Modelo não encontrado: {model_path}")
        print("Baixe com: bash scripts/download_models.sh --stt whisper_base")
        return False

    stt = create_stt("whisper_cpp", model_path, stt_config.__dict__)
    if not stt or not stt.load():
        print("Falha carregando whisper.cpp")
        return False

    # Tenta gravar áudio de teste
    from oraculo.utils.audio import create_silence
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        temp_path = Path(f.name)

    try:
        create_silence(1.0, temp_path)
        result = stt.transcribe(temp_path)
        print(f"whisper.cpp: transcrição de silêncio = '{result.text}' (conf: {result.confidence})")
        return True
    finally:
        temp_path.unlink(missing_ok=True)


def test_vosk():
    """Testa Vosk se disponível."""
    config = get_config()
    stt_config = config.stt

    if stt_config.engine != "vosk":
        print(f"Engine configurado é {stt_config.engine}, pulando teste Vosk")
        return True

    model_path = Path(stt_config.model)
    if not model_path.exists():
        print(f"Modelo Vosk não encontrado: {model_path}")
        return False

    stt = create_stt("vosk", model_path, stt_config.__dict__)
    if not stt or not stt.load():
        print("Falha carregando Vosk")
        return False

    print("Vosk carregado OK")
    return True


def test_termux_stt():
    """Testa termux-stt."""
    from oraculo.stt.termux_stt import TermuxSTT
    from oraculo.utils.helpers import check_command_exists

    if not check_command_exists("termux-stt"):
        print("termux-stt não instalado")
        return True

    stt = TermuxSTT(Path("dummy"), {})
    if stt.load():
        print("termux-stt disponível")
        return True
    return False


def main():
    setup_logging()
    print("="*50)
    print("  TESTE STT")
    print("="*50)

    test_stt_engines()
    print()

    all_passed = True
    all_passed &= test_whisper_cpp()
    all_passed &= test_vosk()
    all_passed &= test_termux_stt()

    print("\n" + "="*50)
    if all_passed:
        print("  ✅ TODOS OS TESTES PASSARAM")
    else:
        print("  ❌ ALGUNS TESTES FALHARAM")
    print("="*50)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())