"""
Testes para Memória (File + Vector).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from oraculo.config import get_config
from oraculo.memory import create_memory, create_memory
from oraculo.memory.tools import get_memory_tools, execute_memory_tool
from oraculo.utils.logger import setup_logging


def test_file_memory():
    """Testa FileMemory."""
    print("\n📝 Testando FileMemory...")

    # Usa arquivo temporário
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as f:
        temp_path = Path(f.name)

    try:
        fm = create_memory("file", file_path=temp_path, profile_path=temp_path.with_name("perfil.md"))
        if not fm.load():
            print("Falha carregando FileMemory")
            return False

        # Adiciona fatos
        assert fm.adicionar("Contatos", "mãe", "Maria, +55 11 99999-9999")
        assert fm.adicionar("Preferências", "respostas", "curtas")
        assert fm.adicionar("Rotinas", "alarme", "6:30 dias úteis")

        print("  Adicionados 3 fatos")

        # Busca
        results = fm.buscar("mãe")
        assert len(results) == 1
        assert results[0].chave == "mãe"
        print(f"  Busca 'mãe': {results[0].valor}")

        # Lista
        all_facts = fm.listar()
        assert len(all_facts) == 3
        print(f"  Total fatos: {len(all_facts)}")

        # Remove
        assert fm.remover("Preferências", "respostas")
        print("  Removido 'respostas'")

        # Verifica remoção
        all_facts = fm.listar()
        assert len(all_facts) == 2
        print("  Confirmação remoção OK")

        # Formatação para prompt
        formatted = fm.get_formatted_memory()
        print(f"  Formatado para prompt:\n{formatted}")

        return True

    finally:
        temp_path.unlink(missing_ok=True)
        temp_path.with_name("perfil.md").unlink(missing_ok=True)


def test_memory_tools():
    """Testa ferramentas de memória (function calling)."""
    print("\n🔧 Testando MemoryTools...")

    # Precisa de config válida
    from oraculo.config import get_config
    config = get_config()

    # Cria tools
    tools = get_memory_tools()

    # Teste adicionar
    result = execute_memory_tool("memoria_adicionar", {
        "secao": "Contatos",
        "chave": "teste_tool",
        "valor": "Valor de teste via tool",
    })
    print(f"  adicionar: {result}")

    # Teste buscar
    result = execute_memory_tool("memoria_buscar", {"query": "teste"})
    print(f"  buscar: {result}")

    # Teste listar
    result = execute_memory_tool("memoria_listar", {"secao": "Contatos"})
    print(f"  listar: {result}")

    # Teste remover
    result = execute_memory_tool("memoria_remover", {"secao": "Contatos", "chave": "teste_tool"})
    print(f"  remover: {result}")

    return True


def test_vector_memory():
    """Testa VectorMemory (se sqlite-vec disponível)."""
    print("\n🔍 Testando VectorMemory...")

    try:
        import sqlite3
        conn = sqlite3.connect(":memory:")
        conn.enable_load_extension(True)
        conn.load_extension("sqlite_vec")
        print("  sqlite-vec disponível")
    except Exception:
        print("  sqlite-vec NÃO disponível (pulando teste vetorial)")
        return True

    # Teste completo requer modelo ONNX — pula se não tiver
    from oraculo.config import get_config
    config = get_config()

    if not config.memory.use_vector:
        print("  Vector memory desabilitado no config")
        return True

    model_path = Path(config.memory.embedding_model)
    if not model_path.exists():
        print(f"  Modelo embedding não encontrado: {model_path}")
        return True

    print("  VectorMemory disponível mas teste completo requer setup")
    return True


def main():
    setup_logging()
    print("="*50)
    print("  TESTE MEMÓRIA")
    print("="*50)

    all_passed = True
    all_passed &= test_file_memory()
    all_passed &= test_memory_tools()
    all_passed &= test_vector_memory()

    print("\n" + "="*50)
    if all_passed:
        print("  ✅ TODOS OS TESTES PASSARAM")
    else:
        print("  ❌ ALGUNS TESTES FALHARAM")
    print("="*50)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())