"""
Automação WhatsApp especializada — Fluxo completo com verificação obrigatória.

Este módulo encapsula a lógica complexa de:
1. Abrir WhatsApp
2. Buscar contato pelo nome exato
3. Abrir conversa
4. Digitar mensagem
5. Enviar
6. VERIFICAR se a bolha da mensagem aparece na tela (uiautomator dump)
7. Só então confirmar sucesso

NUNCA diga "enviado" sem verificação visual.
"""

import time
import re
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
from dataclasses import dataclass

from oraculo.automation.adb import ADBAutomation
from oraculo.utils.logger import get_logger
from oraculo.config import get_config

logger = get_logger(__name__)


@dataclass
class WhatsAppResult:
    """Resultado de operação WhatsApp."""
    success: bool
    message: str
    contato: str = ""
    mensagem: str = ""
    verified: bool = False


class WhatsAppAutomation:
    """Automação WhatsApp de alto nível com verificação."""

    def __init__(self, adb: ADBAutomation = None):
        self.adb = adb
        self.config = get_config().whatsapp
        self.delays = self.config.get("delays", {})
        self.ui_selectors = self.config.get("ui_selectors", {})

        # Se não recebeu ADB, cria novo
        if self.adb is None:
            automation_config = get_config().automation
            self.adb = ADBAutomation(automation_config)
            self._own_adb = True
        else:
            self._own_adb = False

    def connect(self) -> bool:
        """Conecta ADB se necessário."""
        if self._own_adb:
            return self.adb.connect()
        return self.adb.is_connected

    def disconnect(self) -> None:
        if self._own_adb:
            self.adb.disconnect()

    def enviar_mensagem(
        self,
        contato: str,
        mensagem: str,
        verificar: bool = True,
    ) -> WhatsAppResult:
        """
        Envia mensagem no WhatsApp com verificação obrigatória.

        Args:
            contato: Nome do contato EXATO como aparece no WhatsApp
            mensagem: Texto da mensagem
            verificar: Se deve verificar visualmente (padrão: True, NÃO desative)

        Returns:
            WhatsAppResult com success e verified
        """
        if not self.connect():
            return WhatsAppResult(
                success=False,
                message="Falha conectando ADB",
                contato=contato,
                mensagem=mensagem,
            )

        logger.info(f"📱 Enviando WhatsApp para '{contato}': {mensagem[:50]}...")

        try:
            # ===== PASSO 1: Abre WhatsApp =====
            if not self._abrir_whatsapp():
                return WhatsAppResult(
                    success=False,
                    message="Falha abrindo WhatsApp",
                    contato=contato,
                    mensagem=mensagem,
                )

            # ===== PASSO 2: Busca contato =====
            if not self._buscar_contato(contato):
                return WhatsAppResult(
                    success=False,
                    message=f"Contato '{contato}' não encontrado",
                    contato=contato,
                    mensagem=mensagem,
                )

            # ===== PASSO 3: Abre conversa =====
            if not self._abrir_conversa():
                return WhatsAppResult(
                    success=False,
                    message="Falha abrindo conversa",
                    contato=contato,
                    mensagem=mensagem,
                )

            # ===== PASSO 4: Digita mensagem =====
            if not self._digitar_mensagem(mensagem):
                return WhatsAppResult(
                    success=False,
                    message="Falha digitando mensagem",
                    contato=contato,
                    mensagem=mensagem,
                )

            # ===== PASSO 5: Envia =====
            if not self._enviar():
                return WhatsAppResult(
                    success=False,
                    message="Falha tocando botão enviar",
                    contato=contato,
                    mensagem=mensagem,
                )

            # ===== PASSO 6: VERIFICAÇÃO OBRIGATÓRIA =====
            verified = False
            if verificar:
                verified = self._verificar_envio(mensagem)
                if not verified:
                    return WhatsAppResult(
                        success=False,
                        message="⚠️ Mensagem NÃO confirmada na tela (verificação falhou)",
                        contato=contato,
                        mensagem=mensagem,
                        verified=False,
                    )

            return WhatsAppResult(
                success=True,
                message=f"✅ Enviado e verificado para {contato}",
                contato=contato,
                mensagem=mensagem,
                verified=verified,
            )

        except Exception as e:
            logger.error(f"Erro enviando WhatsApp: {e}")
            return WhatsAppResult(
                success=False,
                message=f"Erro: {e}",
                contato=contato,
                mensagem=mensagem,
            )

    def _abrir_whatsapp(self) -> bool:
        """Abre WhatsApp na tela principal."""
        package = self.config.get("package", "com.whatsapp")
        activity = self.config.get("activity", "com.whatsapp.Main")

        result = self.adb._adb_exec(["am", "start", "-n", f"{package}/{activity}"])
        if result[0] != 0:
            logger.error(f"am start falhou: {result[2]}")
            return False

        time.sleep(self.delays.get("open_app", 2000) / 1000)
        return True

    def _buscar_contato(self, contato: str) -> bool:
        """Busca contato na lupa."""
        # Encontra campo de busca
        search_selector = self.ui_selectors.get("search_box", "//*[@resource-id='com.whatsapp:id/search_box']")
        search_elem = self.adb._find_element(search_selector)

        if not search_elem:
            # Tenta alternativas
            for alt_selector in [
                "//*[@content-desc='Buscar']",
                "//*[@text='Buscar']",
                "//*[@resource-id='com.whatsapp:id/menuitem_search']",
            ]:
                search_elem = self.adb._find_element(alt_selector)
                if search_elem:
                    break

        if not search_elem:
            logger.error("Campo de busca não encontrado")
            return False

        # Toca no campo de busca
        self.adb._tap(*search_elem["center"])
        time.sleep(0.5)

        # Digita nome do contato
        if not self.adb._type_text(contato):
            logger.error("Falha digitando nome do contato")
            return False

        time.sleep(self.delays.get("search_contact", 1500) / 1000)
        return True

    def _abrir_conversa(self) -> bool:
        """Seleciona primeiro resultado da busca (o contato)."""
        # O primeiro resultado geralmente está no topo da lista de chats
        chat_list_selector = self.ui_selectors.get("chat_list", "//*[@resource-id='com.whatsapp:id/chat_list']")
        chat_elem = self.adb._find_element(chat_list_selector)

        if chat_elem:
            # Toca no primeiro item (aproximação: centro superior da lista)
            x, y = chat_elem["center"]
            self.adb._tap(x, y - 100)  # Acima do centro para pegar primeiro item
        else:
            # Fallback: coordenadas fixas aproximadas (centro superior)
            # Em tela 1080px wide, 1920px high: topo da lista ~300px
            self.adb._tap(540, 350)

        time.sleep(self.delays.get("open_chat", 1000) / 1000)
        return True

    def _digitar_mensagem(self, mensagem: str) -> bool:
        """Digita mensagem no campo de entrada."""
        input_selector = self.ui_selectors.get("message_input", "//*[@resource-id='com.whatsapp:id/entry']")
        input_elem = self.adb._find_element(input_selector)

        if not input_elem:
            # Tenta alternativas
            for alt in [
                "//*[@content-desc='Mensagem']",
                "//*[@resource-id='com.whatsapp:id/entry']",
            ]:
                input_elem = self.adb._find_element(alt)
                if input_elem:
                    break

        if not input_elem:
            logger.error("Campo de mensagem não encontrado")
            return False

        # Foca no campo
        self.adb._tap(*input_elem["center"])
        time.sleep(self.delays.get("focus_input", 500) / 1000)

        # Digita
        if not self.adb._type_text(mensagem):
            logger.error("Falha digitando mensagem")
            return False

        time.sleep(self.delays.get("type_message", 1000) / 1000)
        return True

    def _enviar(self) -> bool:
        """Toca botão enviar."""
        send_selector = self.ui_selectors.get("send_button", "//*[@resource-id='com.whatsapp:id/send']")
        send_elem = self.adb._find_element(send_selector)

        if send_elem:
            self.adb._tap(*send_elem["center"])
        else:
            # Fallback: tecla Enter (keyevent 66)
            self.adb._adb_shell("input keyevent 66")

        time.sleep(self.delays.get("tap_send", 500) / 1000)
        return True

    def _verificar_envio(self, mensagem: str) -> bool:
        """
        VERIFICAÇÃO OBRIGATÓRIA: Faz uiautomator dump e procura a bolha da mensagem na tela.

        Esta é a parte CRÍTICA — nunca confirme envio sem isso.
        """
        time.sleep(self.delays.get("verify_sent", 2000) / 1000)

        # Força dump fresco
        root = self.adb._dump_ui(force=True)
        if root is None:
            logger.warning("uiautomator dump falhou na verificação")
            return False

        msg_lower = mensagem.lower().strip()
        logger.debug(f"Verificando envio: procurando por '{msg_lower[:50]}...'")

        # Procura em TODOS os elementos por texto contendo a mensagem
        for elem in root.iter():
            text = elem.get("text") or elem.get("{http://schemas.android.com/apk/res/android}text")
            resource_id = elem.get("resource-id") or elem.get("{http://schemas.android.com/apk/res/android}resource-id")

            if text and msg_lower in text.lower():
                # Verifica se é bolha de mensagem ENVIADA (não a que estamos digitando)
                # Bolhas enviadas geralmente têm resource-id específico ou estão em posição específica
                bounds = elem.get("bounds") or elem.get("{http://schemas.android.com/apk/res/android}bounds")

                logger.info(f"✅ VERIFICAÇÃO OK: Encontrou '{text[:80]}' na tela")
                if bounds:
                    logger.debug(f"   Bounds: {bounds}")
                return True

        # Se não encontrou texto exato, tenta busca parcial (últimas palavras)
        words = msg_lower.split()
        if len(words) >= 3:
            partial = " ".join(words[-3:])  # Últimas 3 palavras
            for elem in root.iter():
                text = elem.get("text") or elem.get("{http://schemas.android.com/apk/res/android}text")
                if text and partial in text.lower():
                    logger.info(f"✅ VERIFICAÇÃO PARCIAL OK: '{text[:80]}'")
                    return True

        logger.warning(f"❌ VERIFICAÇÃO FALHOU: Mensagem não encontrada na tela")
        logger.debug(f"   Procurado: '{msg_lower[:100]}'")

        # Debug: lista todos os textos na tela para diagnóstico
        self._debug_dump_texts(root)

        return False

    def _debug_dump_texts(self, root, max_items: int = 20) -> None:
        """Debug: lista textos visíveis na tela."""
        texts = []
        for elem in root.iter():
            text = elem.get("text") or elem.get("{http://schemas.android.com/apk/res/android}text")
            if text and text.strip():
                resource_id = elem.get("resource-id") or elem.get("{http://schemas.android.com/apk/res/android}resource-id", "")
                texts.append(f"  [{resource_id}] {text.strip()[:80]}")

        if texts:
            logger.debug("Textos na tela:\n" + "\n".join(texts[:max_items]))


# Função de conveniência para uso direto
def enviar_whatsapp(contato: str, mensagem: str, verificar: bool = True) -> WhatsAppResult:
    """Função simples para enviar WhatsApp."""
    wa = WhatsAppAutomation()
    try:
        return wa.enviar_mensagem(contato, mensagem, verificar)
    finally:
        wa.disconnect()


# Teste isolado
def test_whatsapp():
    """Teste manual do fluxo WhatsApp."""
    import sys

    if len(sys.argv) < 3:
        print("Uso: python -m oraculo.automation.whatsapp 'Contato' 'Mensagem'")
        return

    contato = sys.argv[1]
    mensagem = " ".join(sys.argv[2:])

    print(f"Testando envio para '{contato}': {mensagem}")
    result = enviar_whatsapp(contato, mensagem)

    print(f"Sucesso: {result.success}")
    print(f"Verificado: {result.verified}")
    print(f"Mensagem: {result.message}")

    sys.exit(0 if result.success else 1)


if __name__ == "__main__":
    test_whatsapp()