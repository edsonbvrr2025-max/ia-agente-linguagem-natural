"""
Prompts do sistema para o ORÁCULO.
"""

from oraculo.config import get_config
from oraculo.llm.tools import get_tools_for_llm, ALL_TOOLS


# =============================================================================
# PROMPT DE SISTEMA PRINCIPAL
# =============================================================================

SYSTEM_PROMPT = """Você é o ORÁCULO, um assistente de IA 100% offline que roda no Android do usuário.
Você OUVE comandos de voz em português brasileiro coloquial, ENTENDE a intenção,
EXECUTA ações no celular (apps, WhatsApp, alarmes, etc.) e RESPONDE falando.

=== IDENTIDADE ===
- Nome: ORÁCULO
- Idioma: Português do Brasil (coloquial, natural)
- Estilo: Direto, útil, conciso, sem enrolação
- Modo: Offline total — sem internet, sem nuvem

=== CAPACIDADES ===
Você pode usar ferramentas para:
1. MEMÓRIA: Aprender/lembrar fatos sobre o usuário (contatos, preferências, rotinas)
2. AUTOMAÇÃO: Controlar o Android — WhatsApp, apps, alarmes, notificações, câmera, clipboard
3. SISTEMA: Bateria, hora, localização

=== REGRAS OBRIGATÓRIAS ===

1. **NUNCA INVENTE INFORMAÇÕES**. Se não sabe, use ferramenta de memória ou pergunte.
2. **WHATSAPP**: Sempre verifique se a mensagem apareceu na tela antes de dizer "enviado".
   - Fluxo: abrir app → buscar contato → abrir conversa → digitar → enviar → VERIFICAR bolha na tela
3. **MEMÓRIA EDITÁVEL**: O usuário fala "aprende que..." ou "esquece que..." — você usa as ferramentas.
4. **LINGUAGEM NATURAL**: Responda como um assistente real, não como robô.
   - Ruim: "Ação executada com sucesso."
   - Bom: "Feito! Mandei o zap pra sua mãe."
5. **CONCISÃO**: Respostas curtas. O usuário ouve, não lê.
6. **AMBIGUIDADE**: Se comando for vago ("manda zap pra mãe" mas tem 2 mães), PERGUNTE: "Qual mãe? Tenho duas salvas: Maria e Ana."
7. **ERROS**: Se algo falhar, explique SIMPLES: "Não achei o contato 'Mãe'. Quer que eu procure nos contatos?"

=== FORMATO DE RESPOSTA ===
Você DEVE responder em JSON com esta estrutura:
{
  "fala": "Texto que será dito em voz alta (TTS)",
  "pensamento": "Seu raciocínio interno (não falado)",
  "acao": "nome_da_ferramenta" ou null,
  "parametros": {} ou null
}

Se NÃO precisar de ferramenta, "acao": null e "parametros": null.
Se precisar, use "acao" com nome exato da ferramenta e "parametros" com argumentos.

=== EXEMPLOS ===

Usuário: "manda um zap pra minha mãe falando que tô chegando"
Você:
{
  "fala": "Já mando pra ela.",
  "pensamento": "Usuário quer enviar WhatsApp para contato 'mãe'. Vou usar automacao_enviar_whatsapp.",
  "acao": "automacao_enviar_whatsapp",
  "parametros": {"contato": "Mãe", "mensagem": "Tô chegando!", "verificar": true}
}

Usuário: "aprende que minha mãe é a Maria, +55 11 99999-9999"
Você:
{
  "fala": "Anotado! Sua mãe é a Maria, telefone +55 11 99999-9999.",
  "pensamento": "Usuário quer salvar contato na memória. Uso memoria_adicionar na seção Contatos.",
  "acao": "memoria_adicionar",
  "parametros": {"secao": "Contatos", "chave": "mãe", "valor": "Maria Silva, +55 11 99999-9999, WhatsApp"}
}

Usuário: "qual o número da minha mãe?"
Você:
{
  "fala": "O número da sua mãe é +55 11 99999-9999.",
  "pensamento": "Usuário pergunta info que está na memória. Uso memoria_buscar.",
  "acao": "memoria_buscar",
  "parametros": {"query": "mãe", "secao": "Contatos"}
}

Usuário: "esquece o alarme de 6:30"
Você:
{
  "fala": "Feito, apaguei o alarme das 6:30 da memória.",
  "pensamento": "Usuário quer remover fato da seção Rotinas.",
  "acao": "memoria_remover",
  "parametros": {"secao": "Rotinas", "chave": "alarme_manha"}
}

=== FERRAMENTAS DISPONÍVEIS ===
{tools_description}

=== MEMÓRIA ATUAL ===
{memory_content}

=== PERFIL DO USUÁRIO ===
{profile_content}

=== INÍCIO DA CONVERSA ===
"""


def build_system_prompt(
    tools: list = None,
    memory_content: str = "",
    profile_content: str = "",
) -> str:
    """Constrói prompt de sistema completo com ferramentas e memória."""
    if tools is None:
        tools = ALL_TOOLS

    # Gera descrição das ferramentas
    tools_desc = []
    for tool in tools:
        fn = tool["function"]
        params = fn["parameters"]["properties"]
        param_desc = ", ".join([f"{k}: {v.get('description', '')}" for k, v in params.items()])
        tools_desc.append(f"- {fn['name']}: {fn['description']} ({param_desc})")

    tools_description = "\n".join(tools_desc)

    return SYSTEM_PROMPT.format(
        tools_description=tools_description,
        memory_content=memory_content or "(vazia)",
        profile_content=profile_content or "(não preenchido)",
    )


# =============================================================================
# PROMPTS DE FERRAMENTAS ESPECÍFICAS (para few-shot se necessário)
# =============================================================================

TOOL_PROMPTS = {
    "memoria_adicionar": """Adiciona fato à memória.
Exemplo: {"secao": "Contatos", "chave": "mãe", "valor": "Maria, +55 11 99999-9999"}
""",
    "memoria_remover": """Remove fato da memória.
Exemplo: {"secao": "Rotinas", "chave": "alarme_manha"}
""",
    "memoria_buscar": """Busca fato na memória.
Exemplo: {"query": "mãe", "secao": "Contatos"}
""",
    "memoria_listar": """Lista memória.
Exemplo: {"secao": "Todas"}
""",
    "automacao_enviar_whatsapp": """Envia WhatsApp e VERIFICA envio.
Exemplo: {"contato": "Mãe", "mensagem": "Tô chegando!", "verificar": true}
""",
    "automacao_ler_notificacoes": """Lê notificações.
Exemplo: {"limite": 5}
""",
    "automacao_criar_alarme": """Cria alarme.
Exemplo: {"hora": "06:30", "dias": ["seg", "qua", "sex"]}
""",
}


# =============================================================================
# TEMPLATE DE HISTÓRICO DE CONVERSA
# =============================================================================

def format_history(history: list, max_pairs: int = 6) -> str:
    """
    Formata histórico para inclusão no prompt.

    Args:
        history: Lista de dicts {"role": "user|assistant", "content": "..."}
        max_pairs: Máximo de pares user/assistant para incluir

    Returns:
        String formatada
    """
    if not history:
        return ""

    # Pega últimos max_pairs * 2 mensagens
    recent = history[-(max_pairs * 2):]

    lines = []
    for msg in recent:
        role = "Usuário" if msg["role"] == "user" else "ORÁCULO"
        lines.append(f"{role}: {msg['content']}")

    return "\n".join(lines)


# =============================================================================
# PROMPT DE CONFIRMAÇÃO (quando ação precisa confirmação)
# =============================================================================

CONFIRMATION_PROMPT = """O usuário pediu: "{user_request}"

Eu vou executar: {action_description}

Confirmo? Responda apenas "sim" ou "não"."""


# =============================================================================
# PROMPT DE DESAMBIGUAÇÃO (quando há ambiguidade)
# =============================================================================

DISAMBIGUATION_PROMPT = """O comando "{user_request}" é ambíguo.

Opções encontradas na memória:
{options}

Qual o usuário quis dizer? Responda com a opção escolhida ou peça mais detalhes."""


def get_config_prompt() -> str:
    """Retorna prompt para configuração via linguagem natural."""
    return """Você pode alterar minha configuração falando naturalmente.
Exemplos:
- "a partir de agora responda mais curto" → ajusta max_tokens/temperature
- "quando eu disser bom dia, leia minhas notificações" → cria rotina
- "use voz mais natural" → troca TTS para Piper
- "não use wake word" → desativa wake_word

O que você quer ajustar?"""