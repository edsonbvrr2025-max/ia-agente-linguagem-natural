"""
Carregamento e validação de configuração (config.yaml).
"""

import yaml
from pathlib import Path
from typing import Any, Dict, Optional
from dataclasses import dataclass, field


@dataclass
class STTConfig:
    engine: str = "whisper_cpp"
    model: str = "models/stt/ggml-base-pt-br.bin"
    language: str = "pt"
    silence_threshold: float = 0.02
    silence_duration: float = 1.5
    whisper: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMConfig:
    engine: str = "llama_cpp"
    model: str = "models/llm/qwen2.5-3b-instruct-q4_k_m.gguf"
    n_ctx: int = 4096
    n_gpu_layers: int = -1
    threads: int = 4
    temperature: float = 0.3
    top_p: float = 0.9
    top_k: int = 40
    repeat_penalty: float = 1.1
    function_calling: bool = True
    parallel_tool_calls: bool = False


@dataclass
class TTSConfig:
    engine: str = "piper"
    model: str = "models/tts/pt_BR-faber-medium.onnx"
    speaker: int = 0
    speed: float = 1.0
    piper: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AutomationConfig:
    method: str = "adb"
    adb_host: str = "127.0.0.1"
    adb_port: int = 5555
    adb_timeout: int = 30
    verify_actions: bool = True
    termux_api: Dict[str, Any] = field(default_factory=dict)
    accessibility: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MemoryConfig:
    file_path: str = "memoria.md"
    profile_path: str = "perfil.md"
    use_vector: bool = True
    vector_db: str = "memory/vectors.db"
    embedding_model: str = "models/embeddings/all-MiniLM-L6-v2.onnx"
    top_k: int = 3
    similarity_threshold: float = 0.7
    format_version: str = "1.0"


@dataclass
class OrchestratorConfig:
    wake_word: str = "oraculo"
    continuous: bool = False
    interruptible: bool = True
    max_history: int = 6
    wakelock: bool = True
    foreground_notification: bool = True
    notification_title: str = "ORÁCULO Ativo"
    notification_text: str = "Toque para abrir / Diga 'oraculo'"
    stt_timeout: int = 10
    llm_timeout: int = 60
    tts_timeout: int = 30
    action_timeout: int = 45


@dataclass
class WhatsAppConfig:
    package: str = "com.whatsapp"
    activity: str = "com.whatsapp.Main"
    ui_selectors: Dict[str, str] = field(default_factory=dict)
    delays: Dict[str, int] = field(default_factory=dict)


@dataclass
class LoggingConfig:
    level: str = "INFO"
    file: str = "oraculo.log"
    max_size_mb: int = 10
    backup_count: int = 3
    console_colors: bool = True


@dataclass
class Config:
    stt: STTConfig = field(default_factory=STTConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    tts: TTSConfig = field(default_factory=TTSConfig)
    automation: AutomationConfig = field(default_factory=AutomationConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    orchestrator: OrchestratorConfig = field(default_factory=OrchestratorConfig)
    whatsapp: WhatsAppConfig = field(default_factory=WhatsAppConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)

    @classmethod
    def load(cls, path: str = "config.yaml") -> "Config":
        """Carrega configuração do arquivo YAML."""
        config_path = Path(path)
        if not config_path.exists():
            # Retorna config padrão se arquivo não existe
            return cls()

        with open(config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        return cls(
            stt=STTConfig(**data.get("stt", {})),
            llm=LLMConfig(**data.get("llm", {})),
            tts=TTSConfig(**data.get("tts", {})),
            automation=AutomationConfig(**data.get("automation", {})),
            memory=MemoryConfig(**data.get("memory", {})),
            orchestrator=OrchestratorConfig(**data.get("orchestrator", {})),
            whatsapp=WhatsAppConfig(**data.get("whatsapp", {})),
            logging=LoggingConfig(**data.get("logging", {})),
        )

    def save(self, path: str = "config.yaml") -> None:
        """Salva configuração no arquivo YAML."""
        data = {
            "stt": self.stt.__dict__,
            "llm": self.llm.__dict__,
            "tts": self.tts.__dict__,
            "automation": self.automation.__dict__,
            "memory": self.memory.__dict__,
            "orchestrator": self.orchestrator.__dict__,
            "whatsapp": self.whatsapp.__dict__,
            "logging": self.logging.__dict__,
        }
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, allow_unicode=True, sort_keys=False)

    def get_model_path(self, model_path: str) -> Path:
        """Resolve caminho do modelo relativo à raiz do projeto."""
        return Path(model_path).expanduser().resolve()


# Instância global (singleton)
_config: Optional[Config] = None


def get_config(path: str = "config.yaml") -> Config:
    """Retorna instância singleton de configuração."""
    global _config
    if _config is None:
        _config = Config.load(path)
    return _config


def reload_config(path: str = "config.yaml") -> Config:
    """Recarrega configuração do arquivo."""
    global _config
    _config = Config.load(path)
    return _config