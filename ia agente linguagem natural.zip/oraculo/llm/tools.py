"""
Definição de ferramentas (Function Calling) para o LLM.

Cada ferramenta segue o formato OpenAI Function Calling:
{
    "type": "function",
    "function": {
        "name": "nome_da_ferramenta",
        "description": "Descrição para o LLM saber quando usar",
        "parameters": {
            "type": "object",
            "properties": {
                "param1": {"type": "string", "description": "..."},
                "param2": {"type": "integer", "description": "..."},
            },
            "required": ["param1"],
        },
    },
}
"""

from typing import List, Dict, Any


# =============================================================================
# FERRAMENTAS DE MEMÓRIA
# =============================================================================

MEMORIA_ADICIONAR = {
    "type": "function",
    "function": {
        "name": "memoria_adicionar",
        "description": "Adiciona um novo fato à memória do agente. Use quando o usuário disser 'aprende que...', 'guarda que...', 'anota que...'. O fato deve ser uma informação útil para futuras interações (contatos, preferências, rotinas, alergias, etc.).",
        "parameters": {
            "type": "object",
            "properties": {
                "secao": {
                    "type": "string",
                    "enum": ["Contatos", "Preferências", "Rotinas", "Fatos Diversos"],
                    "description": "Seção da memória onde o fato se encaixa",
                },
                "chave": {
                    "type": "string",
                    "description": "Nome/chave identificadora do fato (ex: 'mãe', 'alarme_manha', 'alergia')",
                },
                "valor": {
                    "type": "string",
                    "description": "Valor completo do fato (ex: 'Maria Silva, +55 11 99999-9999, WhatsApp')",
                },
                "contexto": {
                    "type": "string",
                    "description": "Contexto adicional ou observações (opcional)",
                },
            },
            "required": ["secao", "chave", "valor"],
        },
    },
}

MEMORIA_REMOVER = {
    "type": "function",
    "function": {
        "name": "memoria_remover",
        "description": "Remove um fato da memória. Use quando o usuário disser 'esquece que...', 'apaga...', 'remove...'.",
        "parameters": {
            "type": "object",
            "properties": {
                "secao": {
                    "type": "string",
                    "enum": ["Contatos", "Preferências", "Rotinas", "Fatos Diversos"],
                    "description": "Seção onde o fato está",
                },
                "chave": {
                    "type": "string",
                    "description": "Chave do fato a remover (exato como salvo)",
                },
            },
            "required": ["secao", "chave"],
        },
    },
}

MEMORIA_BUSCAR = {
    "type": "function",
    "function": {
        "name": "memoria_buscar",
        "description": "Busca fatos na memória por palavra-chave. Use quando precisar de informação salva para responder ou executar ação (ex: 'qual o número da minha mãe?').",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Termo de busca (ex: 'mãe', 'alarme', 'alergia')",
                },
                "secao": {
                    "type": "string",
                    "enum": ["Contatos", "Preferências", "Rotinas", "Fatos Diversos", "Todas"],
                    "description": "Seção para buscar (padrão: Todas)",
                    "default": "Todas",
                },
            },
            "required": ["query"],
        },
    },
}

MEMORIA_LISTAR = {
    "type": "function",
    "function": {
        "name": "memoria_listar",
        "description": "Lista todos os fatos de uma seção ou toda a memória. Use para 'modo conferência' ou quando usuário perguntar 'o que você sabe sobre mim?'.",
        "parameters": {
            "type": "object",
            "properties": {
                "secao": {
                    "type": "string",
                    "enum": ["Contatos", "Preferências", "Rotinas", "Fatos Diversos", "Todas"],
                    "description": "Seção para listar (padrão: Todas)",
                    "default": "Todas",
                },
            },
            "required": [],
        },
    },
}


# =============================================================================
# FERRAMENTAS DE AUTOMAÇÃO (Android)
# =============================================================================

AUTOMACAO_ABRIR_APP = {
    "type": "function",
    "function": {
        "name": "automacao_abrir_app",
        "description": "Abre um aplicativo Android pelo nome do pacote ou nome visível.",
        "parameters": {
            "type": "object",
            "properties": {
                "package": {
                    "type": "string",
                    "description": "Nome do pacote (ex: com.whatsapp, com.android.chrome) ou nome do app",
                },
                "activity": {
                    "type": "string",
                    "description": "Activity específica (opcional, ex: com.whatsapp.Main)",
                },
            },
            "required": ["package"],
        },
    },
}

AUTOMACAO_ENVIAR_WHATSAPP = {
    "type": "function",
    "function": {
        "name": "automacao_enviar_whatsapp",
        "description": "Envia mensagem no WhatsApp para um contato. O agente abre o app, busca o contato, digita e envia, VERIFICANDO se a mensagem apareceu na tela antes de confirmar.",
        "parameters": {
            "type": "object",
            "properties": {
                "contato": {
                    "type": "string",
                    "description": "Nome do contato exatamente como salvo no WhatsApp (ex: 'Mãe', 'Maria Silva')",
                },
                "mensagem": {
                    "type": "string",
                    "description": "Texto da mensagem a enviar",
                },
                "verificar": {
                    "type": "boolean",
                    "description": "Se deve verificar visualmente se enviou (padrão: true)",
                    "default": True,
                },
            },
            "required": ["contato", "mensagem"],
        },
    },
}

AUTOMACAO_LER_NOTIFICACOES = {
    "type": "function",
    "function": {
        "name": "automacao_ler_notificacoes",
        "description": "Lê notificações recentes do Android via Termux:API.",
        "parameters": {
            "type": "object",
            "properties": {
                "limite": {
                    "type": "integer",
                    "description": "Máximo de notificações para ler (padrão: 10)",
                    "default": 10,
                },
                "apenas_nao_lidas": {
                    "type": "boolean",
                    "description": "Apenas notificações não lidas (padrão: false)",
                    "default": False,
                },
            },
            "required": [],
        },
    },
}

AUTOMACAO_CRIAR_ALARME = {
    "type": "function",
    "function": {
        "name": "automacao_criar_alarme",
        "description": "Cria alarme no Android via Termux:API.",
        "parameters": {
            "type": "object",
            "properties": {
                "hora": {
                    "type": "string",
                    "description": "Hora no formato HH:MM (24h, ex: '06:30')",
                },
                "minutos": {
                    "type": "integer",
                    "description": "Minutos (alternativa a hora)",
                },
                "dias": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["seg", "ter", "qua", "qui", "sex", "sab", "dom"]},
                    "description": "Dias da semana para repetir (opcional, vazio = uma vez)",
                },
                "mensagem": {
                    "type": "string",
                    "description": "Rótulo do alarme (opcional)",
                },
            },
            "required": ["hora"],
        },
    },
}

AUTOMACAO_TIRAR_FOTO = {
    "type": "function",
    "function": {
        "name": "automacao_tirar_foto",
        "description": "Tira foto usando câmera traseira via Termux:API.",
        "parameters": {
            "type": "object",
            "properties": {
                "camera": {
                    "type": "integer",
                    "description": "0 = traseira, 1 = frontal (padrão: 0)",
                    "default": 0,
                },
            },
            "required": [],
        },
    },
}

AUTOMACAO_TOAST = {
    "type": "function",
    "function": {
        "name": "automacao_toast",
        "description": "Mostra toast (pop-up temporário) na tela do Android.",
        "parameters": {
            "type": "object",
            "properties": {
                "mensagem": {
                    "type": "string",
                    "description": "Texto do toast",
                },
                "duracao": {
                    "type": "string",
                    "enum": ["short", "long"],
                    "description": "Duração (padrão: short)",
                    "default": "short",
                },
            },
            "required": ["mensagem"],
        },
    },
}

AUTOMACAO_VIBRAR = {
    "type": "function",
    "function": {
        "name": "automacao_vibrar",
        "description": "Faz o celular vibrar.",
        "parameters": {
            "type": "object",
            "properties": {
                "padrao": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Padrão de vibração em ms (ex: [100, 50, 100] = vibra 100ms, pausa 50ms, vibra 100ms)",
                },
            },
            "required": ["padrao"],
        },
    },
}

AUTOMACAO_CLIPBOARD_GET = {
    "type": "function",
    "function": {
        "name": "automacao_clipboard_get",
        "description": "Lê conteúdo da área de transferência.",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
}

AUTOMACAO_CLIPBOARD_SET = {
    "type": "function",
    "function": {
        "name": "automacao_clipboard_set",
        "description": "Define conteúdo da área de transferência.",
        "parameters": {
            "type": "object",
            "properties": {
                "texto": {
                    "type": "string",
                    "description": "Texto para copiar",
                },
            },
            "required": ["texto"],
        },
    },
}


# =============================================================================
# FERRAMENTAS DE SISTEMA
# =============================================================================

SISTEMA_BATERIA = {
    "type": "function",
    "function": {
        "name": "sistema_bateria",
        "description": "Retorna status da bateria (nível, carregando, temperatura).",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
}

SISTEMA_HORA = {
    "type": "function",
    "function": {
        "name": "sistema_hora",
        "description": "Retorna data e hora atual.",
        "parameters": {
            "type": "object",
            "properties": {
                "formato": {
                    "type": "string",
                    "description": "Formato strftime (padrão: '%d/%m/%Y %H:%M')",
                    "default": "%d/%m/%Y %H:%M",
                },
            },
            "required": [],
        },
    },
}

SISTEMA_LOCALIZACAO = {
    "type": "function",
    "function": {
        "name": "sistema_localizacao",
        "description": "Obtém localização atual via GPS/Network (requer permissão).",
        "parameters": {
            "type": "object",
            "properties": {
                "precisao": {
                    "type": "string",
                    "enum": ["high", "low"],
                    "description": "Precisão (padrão: high)",
                    "default": "high",
                },
            },
            "required": [],
        },
    },
}


# =============================================================================
# LISTA COMPLETA DE FERRAMENTAS
# =============================================================================

ALL_TOOLS = [
    # Memória
    MEMORIA_ADICIONAR,
    MEMORIA_REMOVER,
    MEMORIA_BUSCAR,
    MEMORIA_LISTAR,
    # Automação
    AUTOMACAO_ABRIR_APP,
    AUTOMACAO_ENVIAR_WHATSAPP,
    AUTOMACAO_LER_NOTIFICACOES,
    AUTOMACAO_CRIAR_ALARME,
    AUTOMACAO_TIRAR_FOTO,
    AUTOMACAO_TOAST,
    AUTOMACAO_VIBRAR,
    AUTOMACAO_CLIPBOARD_GET,
    AUTOMACAO_CLIPBOARD_SET,
    # Sistema
    SISTEMA_BATERIA,
    SISTEMA_HORA,
    SISTEMA_LOCALIZACAO,
]


# Ferramentas por categoria
TOOLS_BY_CATEGORY = {
    "memoria": [MEMORIA_ADICIONAR, MEMORIA_REMOVER, MEMORIA_BUSCAR, MEMORIA_LISTAR],
    "automacao": [
        AUTOMACAO_ABRIR_APP,
        AUTOMACAO_ENVIAR_WHATSAPP,
        AUTOMACAO_LER_NOTIFICACOES,
        AUTOMACAO_CRIAR_ALARME,
        AUTOMACAO_TIRAR_FOTO,
        AUTOMACAO_TOAST,
        AUTOMACAO_VIBRAR,
        AUTOMACAO_CLIPBOARD_GET,
        AUTOMACAO_CLIPBOARD_SET,
    ],
    "sistema": [SISTEMA_BATERIA, SISTEMA_HORA, SISTEMA_LOCALIZACAO],
}


def get_tools_for_llm(categories: List[str] = None) -> List[Dict]:
    """
    Retorna lista de ferramentas para passar ao LLM.

    Args:
        categories: Lista de categorias ['memoria', 'automacao', 'sistema'].
                    None = todas.

    Returns:
        Lista de definições de ferramentas no formato OpenAI.
    """
    if categories is None:
        return ALL_TOOLS

    tools = []
    for cat in categories:
        tools.extend(TOOLS_BY_CATEGORY.get(cat, []))
    return tools


def get_tool_by_name(name: str) -> Dict:
    """Retorna definição de ferramenta pelo nome."""
    for tool in ALL_TOOLS:
        if tool["function"]["name"] == name:
            return tool
    raise ValueError(f"Ferramenta não encontrada: {name}")