"""
TTS via Sherpa-ONNX — Alta qualidade, suporte a VITS/matcha.

Requer:
- pip install sherpa-onnx
- Modelo ONNX (VITS pt-BR) em models/tts/

Modelos:
- Sherpa-ONNX VITS pt-BR ~80 MB
- Download: https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models
"""

import tempfile
from pathlib import Path
from typing import Dict, Any, Optional

from oraculo.tts import TTSEngine, TTSResult, register_engine
from oraculo.utils.logger import get_logger

logger = get_logger(__name__)


class SherpaOnnxTTS(TTSEngine):
    """Wrapper para Sherpa-ONNX TTS."""

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        super().__init__(model_path, config)
        self.tts = None
        self.speaker_id = config.get("speaker", 0)
        self.speed = config.get("speed", 1.0)

    def load(self) -> bool:
        """Carrega modelo Sherpa-ONNX."""
        try:
            import sherpa_onnx
        except ImportError:
            logger.error(
                "sherpa-onnx não instalado.\n"
                "pip install sherpa-onnx"
            )
            return False

        if not self.model_path.exists():
            logger.error(f"Modelo não encontrado: {self.model_path}")
            logger.info("Baixe em: https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models")
            return False

        # Verifica se é diretório (modelos VITS) ou arquivo
        if self.model_path.is_dir():
            model_file = self.model_path / "model.onnx"
            tokens_file = self.model_path / "tokens.txt"
            config_file = self.model_path / "config.json"
        else:
            # Assume arquivo .onnx único com config ao lado
            model_file = self.model_path
            tokens_file = self.model_path.with_suffix(".tokens.txt")
            config_file = self.model_path.with_suffix(".json")

        if not model_file.exists():
            logger.error(f"Arquivo do modelo não encontrado: {model_file}")
            return False

        try:
            logger.info(f"Carregando Sherpa-ONNX: {model_file}")

            if tokens_file.exists() and config_file.exists():
                # VITS completo
                self.tts = sherpa_onnx.OfflineTts(
                    model=str(model_file),
                    tokens=str(tokens_file),
                    config=str(config_file),
                    num_threads=4,
                )
            else:
                # Modelo simplificado
                self.tts = sherpa_onnx.OfflineTts(
                    model=str(model_file),
                    num_threads=4,
                )

            self._loaded = True
            logger.info("Sherpa-ONNX TTS carregado")
            return True

        except Exception as e:
            logger.error(f"Erro carregando Sherpa-ONNX: {e}")
            return False

    def synthesize(self, text: str, output_path: Path) -> TTSResult:
        """Sintetiza usando Sherpa-ONNX."""
        if not self._loaded:
            if not self.load():
                return TTSResult(audio_path=output_path, success=False, error="Sherpa-ONNX não carregado", engine="sherpa_onnx")

        if not text.strip():
            return TTSResult(audio_path=output_path, success=False, error="Texto vazio", engine="sherpa_onnx")

        output_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            import sherpa_onnx

            logger.debug(f"Sherpa-ONNX sintetizando: {text[:100]}...")

            # Gera áudio
            audio = self.tts.generate(
                text=text,
                sid=self.speaker_id,
                speed=self.speed,
            )

            if audio is None or len(audio.samples) == 0:
                logger.error("Sherpa-ONNX retornou áudio vazio")
                return TTSResult(audio_path=output_path, success=False, error="Áudio vazio", engine="sherpa_onnx")

            # Salva como WAV
            import wave
            import numpy as np

            samples = audio.samples
            sample_rate = audio.sample_rate

            # Converte float32 [-1,1] para int16
            samples_int16 = (np.clip(samples, -1.0, 1.0) * 32767).astype(np.int16)

            with wave.open(str(output_path), "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sample_rate)
                wf.writeframes(samples_int16.tobytes())

            duration = len(samples) / sample_rate
            logger.info(f"Sherpa-ONNX TTS: {output_path} ({duration:.1f}s)")

            return TTSResult(
                audio_path=output_path,
                duration=duration,
                engine="sherpa_onnx",
                success=True,
            )

        except Exception as e:
            logger.error(f"Erro no Sherpa-ONNX: {e}")
            return TTSResult(audio_path=output_path, success=False, error=str(e), engine="sherpa_onnx")

    def unload(self) -> None:
        self.tts = None
        self._loaded = False


# Registra engine
register_engine("sherpa_onnx", SherpaOnnxTTS)