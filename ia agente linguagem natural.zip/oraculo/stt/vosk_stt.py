"""
STT via Vosk — Alternativa offline robusta para pt-BR.

Requer:
- pip install vosk
- Modelo Vosk pt-BR (~1.2 GB) em models/stt/vosk-model-pt-br

Modelo: https://alphacephei.com/vosk/models/vosk-model-pt-br-0.25.zip
"""

import json
import wave
from pathlib import Path
from typing import Dict, Any, Optional

from oraculo.stt import STTEngine, STTResult, register_engine
from oraculo.utils.logger import get_logger

logger = get_logger(__name__)


class VoskSTT(STTEngine):
    """Wrapper para Vosk STT."""

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        super().__init__(model_path, config)
        self.model = None
        self.recognizer = None
        self.sample_rate = config.get("sample_rate", 16000)

    def load(self) -> bool:
        """Carrega modelo Vosk."""
        try:
            from vosk import Model, KaldiRecognizer, SetLogLevel
        except ImportError:
            logger.error("Vosk não instalado. Execute: pip install vosk")
            return False

        # Reduz logs do Vosk
        SetLogLevel(-1)

        if not self.model_path.exists():
            logger.error(f"Modelo Vosk não encontrado: {self.model_path}")
            logger.info("Baixe em: https://alphacephei.com/vosk/models/vosk-model-pt-br-0.25.zip")
            logger.info("Extraia para models/stt/")
            return False

        try:
            logger.info(f"Carregando modelo Vosk: {self.model_path}")
            self.model = Model(str(self.model_path))
            self.recognizer = KaldiRecognizer(self.model, self.sample_rate)
            self.recognizer.SetWords(True)
            self._loaded = True
            logger.info("Vosk carregado com sucesso")
            return True
        except Exception as e:
            logger.error(f"Erro carregando Vosk: {e}")
            return False

    def transcribe(self, audio_path: Path) -> STTResult:
        """Transcreve áudio WAV usando Vosk."""
        if not self._loaded:
            if not self.load():
                return STTResult(text="", confidence=0.0, engine="vosk")

        if not audio_path.exists():
            logger.error(f"Arquivo não encontrado: {audio_path}")
            return STTResult(text="", confidence=0.0, engine="vosk")

        try:
            with wave.open(str(audio_path), "rb") as wf:
                # Verifica formato
                if wf.getnchannels() != 1:
                    logger.warning("Áudio não é mono, convertendo...")
                if wf.getsampwidth() != 2:
                    logger.warning("Áudio não é 16-bit, convertendo...")
                if wf.getframerate() != self.sample_rate:
                    logger.warning(f"Sample rate {wf.getframerate()} != {self.sample_rate}")

                # Processa em chunks
                results = []
                while True:
                    data = wf.readframes(4000)
                    if len(data) == 0:
                        break
                    if self.recognizer.AcceptWaveform(data):
                        result = json.loads(self.recognizer.Result())
                        if result.get("text"):
                            results.append(result["text"])

                # Resultado final
                final_result = json.loads(self.recognizer.FinalResult())
                if final_result.get("text"):
                    results.append(final_result["text"])

                text = " ".join(results).strip()

                # Calcula confidence média dos resultados
                confidence = 0.85 if text else 0.0

                return STTResult(
                    text=text,
                    confidence=confidence,
                    language="pt",
                    engine="vosk",
                )

        except Exception as e:
            logger.error(f"Erro na transcrição Vosk: {e}")
            return STTResult(text="", confidence=0.0, engine="vosk")

    def unload(self) -> None:
        """Libera modelo."""
        self.model = None
        self.recognizer = None
        self._loaded = False


# Registra engine
register_engine("vosk", VoskSTT)


def download_vosk_model(output_dir: Path, model_name: str = "vosk-model-pt-br-0.25") -> bool:
    """Baixa e extrai modelo Vosk pt-BR."""
    import urllib.request
    import zipfile

    url = f"https://alphacephei.com/vosk/models/{model_name}.zip"
    zip_path = output_dir / f"{model_name}.zip"
    extract_dir = output_dir / model_name

    output_dir.mkdir(parents=True, exist_ok=True)

    if extract_dir.exists():
        logger.info(f"Modelo já existe: {extract_dir}")
        return True

    logger.info(f"Baixando modelo Vosk ({model_name})...")
    logger.warning("Arquivo ~1.2 GB — pode demorar")

    try:
        urllib.request.urlretrieve(url, zip_path)
        logger.info("Download concluído, extraindo...")

        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(output_dir)

        # Remove zip
        zip_path.unlink()

        logger.info(f"Modelo Vosk extraído em: {extract_dir}")
        return True

    except Exception as e:
        logger.error(f"Erro baixando/extraindo modelo: {e}")
        return False