"""
Automação Android — Interface base e fábrica.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass


@dataclass
class AutomationResult:
    """Resultado de ação de automação."""
    success: bool
    message: str = ""
    data: Any = None
    screenshot_path: Optional[Path] = None


class AutomationBackend(ABC):
    """Interface base para backends de automação."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self._connected = False

    @abstractmethod
    def connect(self) -> bool:
        """Conecta/inicializa backend. Retorna True se sucesso."""
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Desconecta/limpa."""
        pass

    @abstractmethod
    def execute_action(self, action: str, params: Dict[str, Any]) -> AutomationResult:
        """
        Executa ação de automação.

        Args:
            action: Nome da ação (ex: "abrir_app", "enviar_whatsapp", "ler_notificacoes")
            params: Parâmetros da ação

        Returns:
            AutomationResult
        """
        pass

    @property
    def is_connected(self) -> bool:
        return self._connected

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()


# Registry
_BACKENDS: Dict[str, type] = {}


def register_backend(name: str, backend_class: type) -> None:
    _BACKENDS[name] = backend_class


def get_backend(name: str) -> Optional[type]:
    return _BACKENDS.get(name)


def list_backends() -> Dict[str, type]:
    return _BACKENDS.copy()


def create_automation(backend_name: str, config: Dict[str, Any]) -> Optional[AutomationBackend]:
    backend_class = get_backend(backend_name)
    if backend_class is None:
        return None
    return backend_class(config)