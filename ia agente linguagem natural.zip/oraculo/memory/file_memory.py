"""
Memória baseada em arquivos Markdown (memoria.md, perfil.md).

Formato memoria.md:
## Contatos
- **mãe**: Maria Silva, +55 11 99999-9999, WhatsApp
- **pai**: José Silva, +55 11 88888-8888

## Preferências
- **respostas**: curtas e diretas
- **temperatura**: Celsius

## Rotinas
- **alarme_manha**: 6:30 dias úteis
- **academia**: 19:00 seg/qua/sex

## Fatos Diversos
- **alergia**: camarão
"""

import re
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

from oraculo.memory import MemoryBackend, MemoryFact, register_backend
from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import read_text_safe, write_text_safe, ensure_dir

logger = get_logger(__name__)


# Seções válidas
VALID_SECOES = ["Contatos", "Preferências", "Rotinas", "Fatos Diversos"]
SECAO_ALIASES = {
    "contato": "Contatos",
    "contatos": "Contatos",
    "preferencia": "Preferências",
    "preferências": "Preferências",
    "prefs": "Preferências",
    "rotina": "Rotinas",
    "rotinas": "Rotinas",
    "fato": "Fatos Diversos",
    "fatos": "Fatos Diversos",
    "diversos": "Fatos Diversos",
}


class FileMemory(MemoryBackend):
    """Backend de memória em arquivos Markdown."""

    def __init__(
        self,
        file_path: Path = Path("memoria.md"),
        profile_path: Path = Path("perfil.md"),
    ):
        self.file_path = file_path
        self.profile_path = profile_path
        self._cache: Dict[str, List[MemoryFact]] = {}
        self._loaded = False

    def _normalize_secao(self, secao: str) -> str:
        """Normaliza nome da seção."""
        secao_lower = secao.strip().lower()
        return SECAO_ALIASES.get(secao_lower, secao)

    def _parse_memory_file(self, content: str) -> Dict[str, List[MemoryFact]]:
        """Parseia conteúdo do memoria.md."""
        facts_by_section: Dict[str, List[MemoryFact]] = {s: [] for s in VALID_SECOES}

        current_section = None
        # Regex para linhas: - **chave**: valor
        item_pattern = re.compile(r"^\s*-\s*\*\*(.+?)\*\*\s*:\s*(.+)$")

        for line in content.split("\n"):
            line_stripped = line.strip()

            # Detecta seção
            if line_stripped.startswith("## "):
                section_name = line_stripped[3:].strip()
                normalized = self._normalize_secao(section_name)
                if normalized in VALID_SECOES:
                    current_section = normalized
                else:
                    current_section = None
                continue

            # Parseia item
            if current_section and line_stripped.startswith("- **"):
                match = item_pattern.match(line)
                if match:
                    chave = match.group(1).strip()
                    valor = match.group(2).strip()
                    facts_by_section[current_section].append(MemoryFact(
                        secao=current_section,
                        chave=chave,
                        valor=valor,
                        timestamp=datetime.now().isoformat(),
                    ))

        return facts_by_section

    def _serialize_memory(self, facts: Dict[str, List[MemoryFact]]) -> str:
        """Serializa fatos para formato Markdown."""
        lines = ["# Memória do ORÁCULO", ""]

        for secao in VALID_SECOES:
            section_facts = facts.get(secao, [])
            if section_facts:
                lines.append(f"## {secao}")
                for fact in section_facts:
                    lines.append(f"- **{fact.chave}**: {fact.valor}")
                lines.append("")

        return "\n".join(lines).strip() + "\n"

    def load(self) -> bool:
        """Carrega arquivo de memória."""
        content = read_text_safe(self.file_path)
        if not content:
            # Cria arquivo vazio com estrutura
            content = self._serialize_memory({s: [] for s in VALID_SECOES})
            write_text_safe(self.file_path, content)

        self._cache = self._parse_memory_file(content)
        self._loaded = True
        logger.debug(f"Memória carregada: {sum(len(v) for v in self._cache.values())} fatos")
        return True

    def save(self) -> bool:
        """Salva memória no arquivo."""
        if not self._loaded:
            self.load()

        content = self._serialize_memory(self._cache)
        return write_text_safe(self.file_path, content)

    def adicionar(self, secao: str, chave: str, valor: str, contexto: str = "") -> bool:
        """Adiciona ou atualiza fato."""
        if not self._loaded:
            self.load()

        secao_norm = self._normalize_secao(secao)
        if secao_norm not in VALID_SECOES:
            logger.error(f"Seção inválida: {secao}. Válidas: {VALID_SECOES}")
            return False

        # Remove se já existe (atualização)
        self.remover(secao_norm, chave)

        # Adiciona
        fact = MemoryFact(
            secao=secao_norm,
            chave=chave,
            valor=valor,
            contexto=contexto,
            timestamp=datetime.now().isoformat(),
        )
        self._cache[secao_norm].append(fact)

        return self.save()

    def remover(self, secao: str, chave: str) -> bool:
        """Remove fato."""
        if not self._loaded:
            self.load()

        secao_norm = self._normalize_secao(secao)
        if secao_norm not in VALID_SECOES:
            return False

        original_len = len(self._cache[secao_norm])
        self._cache[secao_norm] = [
            f for f in self._cache[secao_norm] if f.chave.lower() != chave.lower()
        ]

        if len(self._cache[secao_norm]) < original_len:
            return self.save()
        return False

    def buscar(self, query: str, secao: str = "Todas", top_k: int = 5) -> List[MemoryFact]:
        """Busca fatos por palavra-chave (match simples)."""
        if not self._loaded:
            self.load()

        query_lower = query.lower()
        results = []

        secoes_busca = VALID_SECOES if secao == "Todas" else [self._normalize_secao(secao)]

        for sec in secoes_busca:
            for fact in self._cache.get(sec, []):
                # Busca em chave, valor e contexto
                if (query_lower in fact.chave.lower() or
                    query_lower in fact.valor.lower() or
                    query_lower in fact.contexto.lower()):
                    results.append(fact)
                    if len(results) >= top_k:
                        break

        return results

    def listar(self, secao: str = "Todas") -> List[MemoryFact]:
        """Lista todos os fatos de uma seção."""
        if not self._loaded:
            self.load()

        if secao == "Todas":
            all_facts = []
            for sec in VALID_SECOES:
                all_facts.extend(self._cache.get(sec, []))
            return all_facts

        secao_norm = self._normalize_secao(secao)
        return self._cache.get(secao_norm, [])

    def carregar_tudo(self) -> Dict[str, List[MemoryFact]]:
        """Retorna toda a memória estruturada."""
        if not self._loaded:
            self.load()
        return self._cache.copy()

    def get_formatted_memory(self) -> str:
        """Retorna memória formatada para prompt do LLM."""
        if not self._loaded:
            self.load()

        parts = []
        for secao in VALID_SECOES:
            facts = self._cache.get(secao, [])
            if facts:
                parts.append(f"## {secao}")
                for fact in facts:
                    parts.append(f"- **{fact.chave}**: {fact.valor}")
                parts.append("")

        return "\n".join(parts).strip() if parts else "(memória vazia)"

    def get_profile(self) -> str:
        """Lê perfil do usuário."""
        return read_text_safe(self.profile_path, "(perfil não preenchido)")


# Registra backend
register_backend("file", FileMemory)