"""
Automação via AccessibilityService — Fallback/alternativa ao ADB.

Requer:
- App de acessibilidade instalado (ex: AutoMate, ou app customizado)
- Serviço ativado em Config > Acessibilidade

Nota: Implementação completa requer app Android separado.
Este módulo fornece interface para comunicação via Intent/broadcast.
"""

from pathlib import Path
from typing import Dict, Any, Optional

from oraculo.automation import AutomationBackend, AutomationResult, register_backend
from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import run_command, check_command_exists

logger = get_logger(__name__)


class AccessibilityAutomation(AutomationBackend):
    """Backend via AccessibilityService (comunicação via Intent)."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.service_package = config.get("service_package", "com.seuapp.accessibility")
        self.service_class = config.get("service_class", "com.seuapp.accessibility.MyAccessibilityService")
        self._enabled = False

    def connect(self) -> bool:
        """Verifica se serviço de acessibilidade está ativo."""
        # Verifica via dumpsys
        result = run_command(["dumpsys", "accessibility"], timeout=5)
        if result[0] != 0:
            logger.warning("Não conseguiu verificar acessibilidade (precisa root?)")
            return False

        if self.service_package in result[1]:
            self._enabled = True
            logger.info(f"AccessibilityService ativo: {self.service_package}")
            return True

        logger.warning(f"AccessibilityService não encontrado: {self.service_package}")
        logger.info("Ative em: Config > Acessibilidade > Serviços instalados")
        return False

    def disconnect(self) -> None:
        self._enabled = False

    def execute_action(self, action: str, params: Dict[str, Any]) -> AutomationResult:
        """Envia comando via broadcast/intent para o serviço."""
        if not self._enabled:
            return AutomationResult(success=False, message="Serviço não ativo")

        actions = {
            "clicar": self._clicar,
            "digitar": self._digitar,
            "rolar": self._rolar,
            "encontrar_texto": self._encontrar_texto,
            "abrir_app": self._abrir_app,
            "voltar": self._voltar,
            "home": self._home,
            "recentes": self._recentes,
        }

        func = actions.get(action)
        if not func:
            return AutomationResult(success=False, message=f"Ação desconhecida: {action}")

        try:
            return func(params)
        except Exception as e:
            logger.error(f"Erro em {action}: {e}")
            return AutomationResult(success=False, message=f"Erro: {e}")

    def _send_intent(self, action: str, extras: Dict = None) -> AutomationResult:
        """Envia broadcast para o serviço de acessibilidade."""
        cmd = [
            "am", "broadcast",
            "-a", f"{self.service_package}.ACTION_{action.upper()}",
            "-p", self.service_package,
        ]

        if extras:
            for k, v in extras.items():
                if isinstance(v, str):
                    cmd.extend(["--es", k, v])
                elif isinstance(v, int):
                    cmd.extend(["--ei", k, str(v)])
                elif isinstance(v, bool):
                    cmd.extend(["--ez", k, str(v).lower()])

        result = run_command(cmd, timeout=10)
        return AutomationResult(
            success=result[0] == 0,
            message=result[1] if result[0] == 0 else result[2],
        )

    def _clicar(self, params: Dict) -> AutomationResult:
        x = params.get("x")
        y = params.get("y")
        if x is None or y is None:
            return AutomationResult(success=False, message="x,y obrigatórios")
        return self._send_intent("click", {"x": x, "y": y})

    def _digitar(self, params: Dict) -> AutomationResult:
        texto = params.get("texto", "")
        return self._send_intent("type", {"text": texto})

    def _rolar(self, params: Dict) -> AutomationResult:
        direcao = params.get("direcao", "down")  # up, down, left, right
        return self._send_intent("scroll", {"direction": direcao})

    def _encontrar_texto(self, params: Dict) -> AutomationResult:
        texto = params.get("texto", "")
        return self._send_intent("find_text", {"text": texto})

    def _abrir_app(self, params: Dict) -> AutomationResult:
        package = params.get("package")
        if not package:
            return AutomationResult(success=False, message="package obrigatório")
        return self._send_intent("open_app", {"package": package})

    def _voltar(self, params: Dict) -> AutomationResult:
        return self._send_intent("back", {})

    def _home(self, params: Dict) -> AutomationResult:
        return self._send_intent("home", {})

    def _recentes(self, params: Dict) -> AutomationResult:
        return self._send_intent("recents", {})


# Registra backend
register_backend("accessibility", AccessibilityAutomation)


# Helper para criar app de acessibilidade básico
ACCESSIBILITY_SERVICE_TEMPLATE = '''
<!-- AndroidManifest.xml -->
<service
    android:name=".MyAccessibilityService"
    android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
    android:exported="true">
    <intent-filter>
        <action android:name="android.accessibilityservice.AccessibilityService" />
    </intent-filter>
    <meta-data
        android:name="android.accessibilityservice"
        android:resource="@xml/accessibility_service_config" />
</service>

<receiver android:name=".CommandReceiver" android:exported="true">
    <intent-filter>
        <action android:name="com.seuapp.accessibility.ACTION_CLICK" />
        <action android:name="com.seuapp.accessibility.ACTION_TYPE" />
        <action android:name="com.seuapp.accessibility.ACTION_SCROLL" />
        <action android:name="com.seuapp.accessibility.ACTION_FIND_TEXT" />
        <action android:name="com.seuapp.accessibility.ACTION_OPEN_APP" />
        <action android:name="com.seuapp.accessibility.ACTION_BACK" />
        <action android:name="com.seuapp.accessibility.ACTION_HOME" />
        <action android:name="com.seuapp.accessibility.ACTION_RECENTS" />
    </intent-filter>
</receiver>
'''

ACCESSIBILITY_CONFIG_XML = '''
<!-- res/xml/accessibility_service_config.xml -->
<accessibility-service
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeAllMask"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagDefault|flagIncludeNotImportantViews|flagReportViewIds|flagRetrieveInteractiveWindows"
    android:canRetrieveWindowContent="true"
    android:canRequestTouchExploration="true"
    android:canRequestFilterKeyEvents="true"
    android:description="@string/accessibility_service_description"
    android:notificationTimeout="100"
    android:packageNames="com.whatsapp,com.android.chrome,com.google.android.apps.maps" />
'''

# Nota: Implementação completa do serviço Kotlin/Java necessária para funcionar.
# Este módulo serve como interface cliente.