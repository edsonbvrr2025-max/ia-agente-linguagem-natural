"""
TTS via Piper — Voz natural de alta qualidade para pt-BR.

Requer:
- pip install piper-tts
- Modelo ONNX pt-BR em models/tts/

Modelos recomendados:
- pt_BR-faber-medium.onnx     ~50 MB  ← RECOMENDADO (equilibrado)
- pt_BR-faber-low.onnx        ~15 MB  (rápido, qualidade menor)
- pt_BR-faber-high.onnx       ~150 MB (alta qualidade, mais lento)

Download: https://huggingface.co/rhasspy/piper-voices/tree/main/pt/pt_BR/faber
"""

import subprocess
import json
import tempfile
from pathlib import Path
from typing import Dict, Any, Optional

from oraculo.tts import TTSEngine, TTSResult, register_engine
from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import check_command_exists, run_command

logger = get_logger(__name__)


class PiperTTS(TTSEngine):
    """Wrapper para Piper TTS."""

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        super().__init__(model_path, config)
        self.piper_config = config.get("piper", {})
        self.speaker_id = config.get("speaker", 0)
        self.length_scale = self.piper_config.get("length_scale", 1.0)
        self.noise_scale = self.piper_config.get("noise_scale", 0.667)
        self.noise_w = self.piper_config.get("noise_w", 0.8)

    def load(self) -> bool:
        """Verifica modelo e binário piper."""
        # Verifica modelo .onnx
        if not self.model_path.exists():
            logger.error(f"Modelo Piper não encontrado: {self.model_path}")
            logger.info("Baixe em: https://huggingface.co/rhasspy/piper-voices/tree/main/pt/pt_BR/faber")
            return False

        # Verifica arquivo de config .json (mesmo nome do .onnx)
        config_path = self.model_path.with_suffix(".json")
        if not config_path.exists():
            logger.warning(f"Config do modelo não encontrado: {config_path}")

        # Verifica binário piper
        if not check_command_exists("piper"):
            logger.error(
                "Piper não instalado.\n"
                "Termux: pkg install piper-tts (se disponível)\n"
                "Ou: pip install piper-tts\n"
                "Ou compile: https://github.com/rhasspy/piper"
            )
            return False

        logger.info(f"Piper TTS pronto: {self.model_path}")
        self._loaded = True
        return True

    def synthesize(self, text: str, output_path: Path) -> TTSResult:
        """Sintetiza texto usando Piper."""
        if not self._loaded:
            if not self.load():
                return TTSResult(audio_path=output_path, success=False, error="Piper não carregado", engine="piper")

        if not text.strip():
            return TTSResult(audio_path=output_path, success=False, error="Texto vazio", engine="piper")

        # Garante diretório de saída
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Comando piper
        cmd = [
            "piper",
            "--model", str(self.model_path),
            "--output_file", str(output_path),
        ]

        # Speaker ID (se modelo multi-speaker)
        if self.speaker_id is not None:
            cmd.extend(["--speaker", str(self.speaker_id)])

        # Parâmetros de qualidade
        cmd.extend([
            "--length_scale", str(self.length_scale),
            "--noise_scale", str(self.noise_scale),
            "--noise_w", str(self.noise_w),
        ])

        # Sentence silence (pausa entre frases)
        cmd.extend(["--sentence_silence", "0.2"])

        logger.debug(f"Piper: {' '.join(cmd)}")
        logger.debug(f"Texto: {text[:100]}...")

        try:
            # Piper lê texto do stdin
            result = subprocess.run(
                cmd,
                input=text,
                text=True,
                capture_output=True,
                timeout=self.config.get("timeout", 30),
            )

            if result.returncode != 0:
                error = result.stderr.strip() or "Erro desconhecido"
                logger.error(f"Piper falhou: {error}")
                return TTSResult(
                    audio_path=output_path,
                    success=False,
                    error=error,
                    engine="piper",
                )

            # Verifica arquivo gerado
            if not output_path.exists() or output_path.stat().st_size < 100:
                logger.error("Arquivo de áudio não gerado ou vazio")
                return TTSResult(
                    audio_path=output_path,
                    success=False,
                    error="Arquivo vazio",
                    engine="piper",
                )

            # Estima duração (aproximado)
            import wave
            try:
                with wave.open(str(output_path), "rb") as wf:
                    frames = wf.getnframes()
                    rate = wf.getframerate()
                    duration = frames / float(rate)
            except Exception:
                duration = len(text) * 0.08  # ~80ms por caractere

            logger.info(f"TTS gerado: {output_path} ({duration:.1f}s)")
            return TTSResult(
                audio_path=output_path,
                duration=duration,
                engine="piper",
                success=True,
            )

        except subprocess.TimeoutExpired:
            logger.error("Piper timeout")
            return TTSResult(audio_path=output_path, success=False, error="Timeout", engine="piper")
        except Exception as e:
            logger.error(f"Erro inesperado no Piper: {e}")
            return TTSResult(audio_path=output_path, success=False, error=str(e), engine="piper")

    def unload(self) -> None:
        self._loaded = False


# Registra engine
register_engine("piper", PiperTTS)


def download_piper_model(model_name: str, output_dir: Path) -> bool:
    """
    Baixa modelo Piper do Hugging Face.

    Modelos pt-BR disponíveis:
    - pt_BR-faber-low.onnx + .json
    - pt_BR-faber-medium.onnx + .json
    - pt_BR-faber-high.onnx + .json
    """
    import urllib.request

    base_url = "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber"
    files = [f"{model_name}.onnx", f"{model_name}.onnx.json"]

    output_dir.mkdir(parents=True, exist_ok=True)

    for filename in files:
        url = f"{base_url}/{filename}"
        output_path = output_dir / filename

        if output_path.exists():
            logger.info(f"Já existe: {output_path}")
            continue

        logger.info(f"Baixando {filename}...")
        try:
            urllib.request.urlretrieve(url, output_path)
            logger.info(f"Baixado: {output_path} ({output_path.stat().st_size / 1024 / 1024:.1f} MB)")
        except Exception as e:
            logger.error(f"Erro baixando {filename}: {e}")
            return False

    return True