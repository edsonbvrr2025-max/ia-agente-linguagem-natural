"""
TTS via espeak-ng — Robótico, instantâneo, zero modelo extra.

Requer:
- pkg install espeak-ng (Termux)
- Não precisa de modelo — usa voz embutida pt-BR

Vantagens: Funciona sempre, instantâneo, leve.
Desvantagens: Voz robótica, menos natural.
"""

import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Any

from oraculo.tts import TTSEngine, TTSResult, register_engine
from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import check_command_exists, run_command

logger = get_logger(__name__)


class EspeakNGTTS(TTSEngine):
    """Wrapper para espeak-ng."""

    # Vozes pt-BR disponíveis no espeak-ng
    VOICES = {
        "pt-br": "Português (Brasil) - voz padrão",
        "pt": "Português (Portugal)",
        "mb-br1": "Brasileiro masculino 1",
        "mb-br2": "Brasileiro masculino 2",
        "mb-br3": "Brasileiro masculino 3",
        "fb-br1": "Brasileiro feminino 1",
        "fb-br2": "Brasileiro feminino 2",
    }

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        super().__init__(model_path, config)
        # model_path ignorado — espeak-ng não usa modelo externo
        self.voice = config.get("voice", "pt-br")
        self.speed = config.get("speed", 1.0)  # 80-450 palavras/min
        self.pitch = config.get("pitch", 50)   # 0-99
        self.gap = config.get("gap", 10)       # Pausa entre palavras (ms)

    def load(self) -> bool:
        """Verifica se espeak-ng está instalado."""
        if not check_command_exists("espeak-ng"):
            logger.error(
                "espeak-ng não encontrado.\n"
                "Termux: pkg install espeak-ng"
            )
            return False

        # Lista vozes disponíveis
        result = run_command(["espeak-ng", "--voices=pt"])
        if result[0] == 0:
            logger.debug(f"Vozes pt disponíveis:\n{result[1]}")

        logger.info(f"espeak-ng pronto (voz: {self.voice})")
        self._loaded = True
        return True

    def synthesize(self, text: str, output_path: Path) -> TTSResult:
        """Sintetiza texto usando espeak-ng."""
        if not self._loaded:
            if not self.load():
                return TTSResult(audio_path=output_path, success=False, error="espeak-ng não carregado", engine="espeak_ng")

        if not text.strip():
            return TTSResult(audio_path=output_path, success=False, error="Texto vazio", engine="espeak_ng")

        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Converte speed (1.0 = normal) para palavras por minuto
        # espeak-ng default ~175 wpm
        wpm = int(175 * self.speed)
        wpm = max(80, min(450, wpm))

        cmd = [
            "espeak-ng",
            "-v", self.voice,
            "-s", str(wpm),
            "-p", str(self.pitch),
            "-g", str(self.gap),
            "-w", str(output_path),  # Output para arquivo WAV
            "--",  # Fim de opções, início do texto
            text,
        ]

        logger.debug(f"espeak-ng: {' '.join(cmd[:8])} ... '{text[:50]}...'")

        try:
            result = run_command(cmd, timeout=self.config.get("timeout", 15))

            if result[0] != 0:
                logger.error(f"espeak-ng falhou: {result[2]}")
                return TTSResult(
                    audio_path=output_path,
                    success=False,
                    error=result[2],
                    engine="espeak_ng",
                )

            if not output_path.exists() or output_path.stat().st_size < 100:
                logger.error("Arquivo WAV não gerado")
                return TTSResult(
                    audio_path=output_path,
                    success=False,
                    error="Arquivo vazio",
                    engine="espeak_ng",
                )

            # Duração estimada
            import wave
            try:
                with wave.open(str(output_path), "rb") as wf:
                    frames = wf.getnframes()
                    rate = wf.getframerate()
                    duration = frames / float(rate)
            except Exception:
                duration = len(text) * 0.06

            logger.info(f"TTS espeak-ng: {output_path} ({duration:.1f}s)")
            return TTSResult(
                audio_path=output_path,
                duration=duration,
                engine="espeak_ng",
                success=True,
            )

        except Exception as e:
            logger.error(f"Erro no espeak-ng: {e}")
            return TTSResult(audio_path=output_path, success=False, error=str(e), engine="espeak_ng")

    def unload(self) -> None:
        self._loaded = False


# Registra engine
register_engine("espeak_ng", EspeakNGTTS)