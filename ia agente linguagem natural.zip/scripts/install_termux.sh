#!/bin/bash
# ORÁCULO — Instalação completa no Termux
# Execute: bash scripts/install_termux.sh

set -e  # Para em erro

echo "=========================================="
echo "  ORÁCULO — Instalação no Termux"
echo "=========================================="
echo ""

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[AVISO]${NC} $1"; }
log_error() { echo -e "${RED}[ERRO]${NC} $1"; }

# Verifica se está no Termux
if [ ! -d "/data/data/com.termux" ]; then
    log_error "Este script deve rodar no Termux no Android!"
    exit 1
fi

# Verifica se Termux veio do F-Droid/GitHub (não Play Store)
if [ -f "/data/data/com.termux/files/usr/bin/termux-api" ] 2>/dev/null; then
    log_ok "Termux:API binário encontrado"
else
    log_warn "Termux:API pode não estar instalado corretamente"
fi

# Atualiza pacotes
log_info "Atualizando pacotes..."
pkg update -y && pkg upgrade -y

# Pacotes essenciais
log_info "Instalando pacotes essenciais..."
pkg install -y \
    python \
    python-pip \
    git \
    ffmpeg \
    sox \
    termux-api \
    android-tools \
    clang \
    cmake \
    make \
    wget \
    curl \
    unzip \
    htop \
    ncurses-utils \
    jq

# Python packages
log_info "Atualizando pip..."
pip install --upgrade pip setuptools wheel

log_info "Instalando dependências Python..."
pip install -r requirements.txt

# llama-cpp-python (compila no Termux)
log_info "Instalando llama-cpp-python (CPU)..."
pip install llama-cpp-python --no-binary llama-cpp-python -v 2>&1 | tail -20

# Tenta instalar com Vulkan se disponível
if [ -f "/system/lib64/libvulkan.so" ] || [ -f "/vendor/lib64/libvulkan.so" ]; then
    log_info "Vulkan detectado, tentando compilar com suporte GPU..."
    GGML_VULKAN=1 pip install llama-cpp-python --no-binary llama-cpp-python -v 2>&1 | tail -20
else
    log_warn "Vulkan não detectado, usando apenas CPU"
fi

# Cria diretórios
log_info "Criando diretórios..."
mkdir -p models/llm models/stt models/tts models/embeddings memory backups logs

# Permissões Termux:API
log_info "Configurando Termux:API..."
# Precisa abrir app Termux:API uma vez para conceder permissões
am start -n com.termux.api/com.termux.api.TermuxApiActivity 2>/dev/null || true
sleep 2

# Verifica instalação
log_info "Verificando instalação..."
checks=(
    "python3 --version"
    "pip --version"
    "git --version"
    "ffmpeg -version"
    "adb version"
    "termux-api --help"
)

for cmd in "${checks[@]}"; do
    if eval "$cmd" >/dev/null 2>&1; then
        log_ok "$cmd"
    else
        log_warn "$cmd (pode não estar no PATH)"
    fi
done

# Termux:API endpoints
log_info "Endpoints Termux:API disponíveis:"
for ep in termux-notification termux-toast termux-vibrate termux-clipboard-get termux-contact-list termux-sms-list termux-alarm-list termux-camera-photo termux-microphone-record termux-media-player termux-wake-lock termux-battery-status termux-wifi-scaninfo termux-location; do
    if command -v "$ep" >/dev/null; then
        log_ok "  $ep"
    else
        log_warn "  $ep (não encontrado)"
    fi
done

echo ""
echo "=========================================="
log_ok "Instalação base concluída!"
echo "=========================================="
echo ""
echo "Próximos passos:"
echo "  1. Baixe modelos: bash scripts/download_models.sh"
echo "  2. Configure ADB wireless: bash scripts/setup_adb_wireless.sh"
echo "  3. Teste componentes: python -m tests.test_stt"
echo "  4. Inicie o agente: python -m oraculo"
echo ""