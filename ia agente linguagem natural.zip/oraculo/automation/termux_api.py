"""
Automação via Termux:API — Nativo do Termux, bom para notificações, contatos, SMS, alarme, clipboard.

Requer:
- Termux:API app instalado (F-Droid/GitHub)
- pkg install termux-api
"""

import subprocess
import json
from pathlib import Path
from typing import Dict, Any, List, Optional

from oraculo.automation import AutomationBackend, AutomationResult, register_backend
from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import run_command, check_command_exists

logger = get_logger(__name__)


class TermuxAPIAutomation(AutomationBackend):
    """Backend de automação via Termux:API."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.enabled_features = config.get("termux_api", {
            "notification": True,
            "contact": True,
            "sms": True,
            "alarm": True,
            "camera": True,
            "clipboard": True,
            "toast": True,
            "vibration": True,
        })

    def connect(self) -> bool:
        """Verifica Termux:API disponível."""
        endpoints = [
            "termux-notification-list",
            "termux-contact-list",
            "termux-sms-list",
            "termux-alarm-list",
            "termux-camera-photo",
            "termux-clipboard-get",
            "termux-toast",
            "termux-vibrate",
        ]

        available = []
        for ep in endpoints:
            if check_command_exists(ep):
                available.append(ep)

        if not available:
            logger.error(
                "Nenhum endpoint Termux:API encontrado.\n"
                "Instale: pkg install termux-api\n"
                "E o app Termux:API do F-Droid/GitHub"
            )
            return False

        logger.info(f"Termux:API endpoints disponíveis: {', '.join(available)}")
        self._connected = True
        return True

    def disconnect(self) -> None:
        self._connected = False

    def execute_action(self, action: str, params: Dict[str, Any]) -> AutomationResult:
        """Dispatch de ações Termux:API."""
        actions = {
            "ler_notificacoes": self._ler_notificacoes,
            "listar_contatos": self._listar_contatos,
            "enviar_sms": self._enviar_sms,
            "listar_sms": self._listar_sms,
            "criar_alarme": self._criar_alarme,
            "listar_alarmes": self._listar_alarmes,
            "tirar_foto": self._tirar_foto,
            "clipboard_get": self._clipboard_get,
            "clipboard_set": self._clipboard_set,
            "toast": self._toast,
            "vibrar": self._vibrar,
            "bateria": self._bateria,
            "wifi_scan": self._wifi_scan,
            "localizacao": self._localizacao,
            "gravar_audio": self._gravar_audio,
            "tocar_audio": self._tocar_audio,
        }

        func = actions.get(action)
        if not func:
            return AutomationResult(success=False, message=f"Ação desconhecida: {action}")

        try:
            return func(params)
        except Exception as e:
            logger.error(f"Erro em {action}: {e}")
            return AutomationResult(success=False, message=f"Erro: {e}")

    def _ler_notificacoes(self, params: Dict) -> AutomationResult:
        """Lista notificações."""
        result = run_command(["termux-notification-list", "-j"], timeout=10)
        if result[0] != 0:
            return AutomationResult(success=False, message=result[2])

        try:
            notifications = json.loads(result[1])
            limite = params.get("limite", 10)
            apenas_nao_lidas = params.get("apenas_nao_lidas", False)

            filtered = []
            for n in notifications[:limite]:
                if apenas_nao_lidas and n.get("read", False):
                    continue
                filtered.append({
                    "title": n.get("title", ""),
                    "content": n.get("content", ""),
                    "package": n.get("packageName", ""),
                    "time": n.get("when", 0),
                })

            return AutomationResult(
                success=True,
                message=f"{len(filtered)} notificação(ões)",
                data={"notifications": filtered},
            )
        except json.JSONDecodeError:
            return AutomationResult(success=False, message="Erro parseando JSON")

    def _listar_contatos(self, params: Dict) -> AutomationResult:
        """Lista contatos."""
        result = run_command(["termux-contact-list", "-j"], timeout=15)
        if result[0] != 0:
            return AutomationResult(success=False, message=result[2])

        try:
            contacts = json.loads(result[1])
            query = params.get("query", "").lower()

            if query:
                contacts = [
                    c for c in contacts
                    if query in c.get("name", "").lower()
                    or any(query in p.get("number", "") for p in c.get("phoneNumbers", []))
                ]

            return AutomationResult(
                success=True,
                message=f"{len(contacts)} contato(s)",
                data={"contacts": contacts},
            )
        except json.JSONDecodeError:
            return AutomationResult(success=False, message="Erro parseando contatos")

    def _enviar_sms(self, params: Dict) -> AutomationResult:
        """Envia SMS."""
        numero = params.get("numero")
        mensagem = params.get("mensagem")

        if not numero or not mensagem:
            return AutomationResult(success=False, message="Número e mensagem obrigatórios")

        result = run_command(["termux-sms-send", "-n", numero, "-b", mensagem], timeout=15)
        return AutomationResult(
            success=result[0] == 0,
            message="SMS enviado" if result[0] == 0 else result[2],
        )

    def _listar_sms(self, params: Dict) -> AutomationResult:
        """Lista SMS."""
        result = run_command(["termux-sms-list", "-j", "-l", str(params.get("limite", 20))], timeout=10)
        if result[0] != 0:
            return AutomationResult(success=False, message=result[2])

        try:
            sms_list = json.loads(result[1])
            return AutomationResult(
                success=True,
                message=f"{len(sms_list)} SMS",
                data={"sms": sms_list},
            )
        except json.JSONDecodeError:
            return AutomationResult(success=False, message="Erro parseando SMS")

    def _criar_alarme(self, params: Dict) -> AutomationResult:
        """Cria alarme."""
        hora = params.get("hora")
        if not hora:
            return AutomationResult(success=False, message="Hora obrigatória (HH:MM)")

        try:
            h, m = map(int, hora.split(":"))
        except ValueError:
            return AutomationResult(success=False, message="Formato HH:MM")

        import datetime
        now = datetime.datetime.now()
        alarm_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
        if alarm_time <= now:
            alarm_time += datetime.timedelta(days=1)

        timestamp_ms = int(alarm_time.timestamp() * 1000)

        cmd = ["termux-alarm", "--time", str(timestamp_ms)]
        msg = params.get("mensagem", "Alarme")
        cmd.extend(["--title", msg])

        result = run_command(cmd, timeout=10)
        return AutomationResult(
            success=result[0] == 0,
            message=f"Alarme para {hora}" if result[0] == 0 else result[2],
        )

    def _listar_alarmes(self, params: Dict) -> AutomationResult:
        """Lista alarmes."""
        result = run_command(["termux-alarm-list", "-j"], timeout=5)
        if result[0] != 0:
            return AutomationResult(success=False, message=result[2])

        try:
            alarms = json.loads(result[1])
            return AutomationResult(
                success=True,
                message=f"{len(alarms)} alarme(s)",
                data={"alarms": alarms},
            )
        except json.JSONDecodeError:
            return AutomationResult(success=False, message="Erro parseando alarmes")

    def _tirar_foto(self, params: Dict) -> AutomationResult:
        """Tira foto."""
        camera = params.get("camera", 0)
        output = params.get("output", "/sdcard/oraculo_foto.jpg")

        result = run_command(["termux-camera-photo", "-c", str(camera), output], timeout=15)
        return AutomationResult(
            success=result[0] == 0,
            message="Foto tirada" if result[0] == 0 else result[2],
            data={"path": output} if result[0] == 0 else None,
        )

    def _clipboard_get(self, params: Dict) -> AutomationResult:
        result = run_command(["termux-clipboard-get"], timeout=5)
        return AutomationResult(
            success=result[0] == 0,
            message=result[1].strip(),
            data={"text": result[1].strip()},
        )

    def _clipboard_set(self, params: Dict) -> AutomationResult:
        texto = params.get("texto", "")
        result = run_command(["termux-clipboard-set", texto], timeout=5)
        return AutomationResult(
            success=result[0] == 0,
            message="Copiado" if result[0] == 0 else result[2],
        )

    def _toast(self, params: Dict) -> AutomationResult:
        msg = params.get("mensagem", "")
        duracao = params.get("duracao", "short")
        result = run_command(["termux-toast", "-g", duracao, msg], timeout=5)
        return AutomationResult(success=result[0]==0, message="Toast ok" if result[0]==0 else result[2])

    def _vibrar(self, params: Dict) -> AutomationResult:
        padrao = params.get("padrao", [100])
        pattern_str = ",".join(map(str, padrao))
        result = run_command(["termux-vibrate", "-f", "-p", pattern_str], timeout=5)
        return AutomationResult(success=result[0]==0, message="Vibrou" if result[0]==0 else result[2])

    def _bateria(self, params: Dict) -> AutomationResult:
        result = run_command(["termux-battery-status", "-j"], timeout=5)
        if result[0] != 0:
            return AutomationResult(success=False, message=result[2])
        try:
            data = json.loads(result[1])
            return AutomationResult(success=True, message=f"Bateria: {data.get('percentage', '?')}%", data=data)
        except json.JSONDecodeError:
            return AutomationResult(success=False, message="Erro parseando bateria")

    def _wifi_scan(self, params: Dict) -> AutomationResult:
        result = run_command(["termux-wifi-scaninfo", "-j"], timeout=10)
        if result[0] != 0:
            return AutomationResult(success=False, message=result[2])
        try:
            data = json.loads(result[1])
            return AutomationResult(success=True, message=f"{len(data)} redes", data={"networks": data})
        except json.JSONDecodeError:
            return AutomationResult(success=False, message="Erro parseando WiFi")

    def _localizacao(self, params: Dict) -> AutomationResult:
        precisao = params.get("precisao", "high")
        provider = "gps" if precisao == "high" else "network"
        result = run_command(["termux-location", "-p", provider, "-j"], timeout=15)
        if result[0] != 0:
            return AutomationResult(success=False, message=result[2])
        try:
            data = json.loads(result[1])
            return AutomationResult(success=True, message=f"Lat: {data.get('latitude')}, Lon: {data.get('longitude')}", data=data)
        except json.JSONDecodeError:
            return AutomationResult(success=False, message="Erro parseando localização")

    def _gravar_audio(self, params: Dict) -> AutomationResult:
        """Grava áudio via termux-microphone-record."""
        duration = params.get("duration", 5)
        output = params.get("output", "/sdcard/oraculo_record.wav")

        result = run_command([
            "termux-microphone-record",
            "-f", output,
            "-l", "1048576",  # 1MB limit
        ], timeout=duration + 5)

        return AutomationResult(
            success=result[0] == 0,
            message=f"Gravado {duration}s" if result[0] == 0 else result[2],
            data={"path": output} if result[0] == 0 else None,
        )

    def _tocar_audio(self, params: Dict) -> AutomationResult:
        """Toca áudio via termux-media-player."""
        file_path = params.get("file")
        if not file_path:
            return AutomationResult(success=False, message="Arquivo obrigatório")

        result = run_command(["termux-media-player", "play", file_path], timeout=30)
        return AutomationResult(
            success=result[0] == 0,
            message="Tocando" if result[0] == 0 else result[2],
        )


# Registra backend
register_backend("termux_api", TermuxAPIAutomation)