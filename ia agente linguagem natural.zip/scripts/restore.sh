#!/bin/bash
# ORÁCULO — Restaura backup

set -e

BACKUP_DIR="backups"

echo "=========================================="
echo "  ORÁCULO — Restauração"
echo "=========================================="
echo ""

# Lista backups disponíveis
echo "Backups disponíveis:"
ls -lh "$BACKUP_DIR"/oraculo_backup_*.tar.gz 2>/dev/null | awk '{print "  " $9 " (" $5 ")"}' || {
    echo "  Nenhum backup encontrado em $BACKUP_DIR/"
    exit 1
}

echo ""
read -p "Nome do arquivo (ex: oraculo_backup_20250115_143000.tar.gz): " BACKUP_FILE

BACKUP_PATH="${BACKUP_DIR}/${BACKUP_FILE}"

if [ ! -f "$BACKUP_PATH" ]; then
    echo "Arquivo não encontrado: $BACKUP_PATH"
    exit 1
fi

echo ""
echo "⚠️  ISSO VAI SOBRESCREVER:"
echo "  - memoria.md"
echo "  - perfil.md"
echo "  - config.yaml"
echo "  - memory/vectors.db"
echo ""
read -p "Confirmar restauração? (s/N): " CONFIRM
if [[ ! "$CONFIRM" =~ ^[Ss]$ ]]; then
    echo "Cancelado."
    exit 0
fi

# Extrai em temp
TEMP_DIR=$(mktemp -d)
echo "[EXTRAINDO] em $TEMP_DIR"
tar -xzf "$BACKUP_PATH" -C "$TEMP_DIR"

# Encontra pasta extraída
EXTRACTED=$(find "$TEMP_DIR" -maxdepth 1 -type d -name "oraculo_backup_*" | head -1)

if [ -z "$EXTRACTED" ]; then
    echo "Erro: estrutura de backup inválida"
    rm -rf "$TEMP_DIR"
    exit 1
fi

# Restaura arquivos
echo "[RESTAURANDO] memoria.md"
cp "$EXTRACTED/memoria.md" . 2>/dev/null || echo "  (não no backup)"

echo "[RESTAURANDO] perfil.md"
cp "$EXTRACTED/perfil.md" . 2>/dev/null || echo "  (não no backup)"

echo "[RESTAURANDO] config.yaml"
cp "$EXTRACTED/config.yaml" . 2>/dev/null || echo "  (não no backup)"

echo "[RESTAURANDO] memory/vectors.db"
mkdir -p memory
cp "$EXTRACTED/vectors.db" memory/ 2>/dev/null || echo "  (não no backup)"

# Logs
if [ -d "$EXTRACTED" ]; then
    for log in "$EXTRACTED"/*.log; do
        [ -f "$log" ] && cp "$log" logs/ 2>/dev/null
    done
fi

# Limpa temp
rm -rf "$TEMP_DIR"

echo ""
echo "=========================================="
echo "  ✅ Restauração concluída"
echo "=========================================="
echo ""
echo "Verifique:"
echo "  cat memoria.md"
echo "  cat config.yaml"
echo ""