"""
STT (Speech-to-Text) — Interface base e fábrica.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class STTResult:
    """Resultado de transcrição."""
    text: str
    confidence: float = 1.0
    language: str = "pt"
    duration: float = 0.0
    engine: str = "unknown"


class STTEngine(ABC):
    """Interface base para engines de STT."""

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        self.model_path = model_path
        self.config = config
        self._loaded = False

    @abstractmethod
    def load(self) -> bool:
        """Carrega modelo na memória. Retorna True se sucesso."""
        pass

    @abstractmethod
    def transcribe(self, audio_path: Path) -> STTResult:
        """
        Transcreve arquivo de áudio.

        Args:
            audio_path: Caminho para arquivo de áudio (WAV 16kHz mono recomendado)

        Returns:
            STTResult com texto transcrito
        """
        pass

    @abstractmethod
    def unload(self) -> None:
        """Libera recursos do modelo."""
        pass

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def __enter__(self):
        self.load()
        return self

    def __exit__(self, *args):
        self.unload()


# Registry de engines disponíveis
_ENGINES: Dict[str, type] = {}


def register_engine(name: str, engine_class: type) -> None:
    """Registra engine de STT."""
    _ENGINES[name] = engine_class


def get_engine(name: str) -> Optional[type]:
    """Retorna classe de engine pelo nome."""
    return _ENGINES.get(name)


def list_engines() -> Dict[str, type]:
    """Lista engines registradas."""
    return _ENGINES.copy()


def create_stt(engine_name: str, model_path: Path, config: Dict[str, Any]) -> Optional[STTEngine]:
    """Factory para criar instância de STT."""
    engine_class = get_engine(engine_name)
    if engine_class is None:
        return None
    return engine_class(model_path, config)