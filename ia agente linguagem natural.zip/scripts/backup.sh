#!/bin/bash
# ORÁCULO — Backup de memória, config e modelos

set -e

BACKUP_DIR="backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_NAME="oraculo_backup_${TIMESTAMP}"
BACKUP_PATH="${BACKUP_DIR}/${BACKUP_NAME}"

mkdir -p "$BACKUP_PATH"

echo "=========================================="
echo "  ORÁCULO — Backup"
echo "=========================================="
echo ""

# Backup memória
echo "[BACKUP] memoria.md"
cp memoria.md "$BACKUP_PATH/" 2>/dev/null || echo "  (não existe)"

echo "[BACKUP] perfil.md"
cp perfil.md "$BACKUP_PATH/" 2>/dev/null || echo "  (não existe)"

echo "[BACKUP] config.yaml"
cp config.yaml "$BACKUP_PATH/" 2>/dev/null || echo "  (não existe)"

# Backup memória vetorial
if [ -f "memory/vectors.db" ]; then
    echo "[BACKUP] memory/vectors.db"
    cp memory/vectors.db "$BACKUP_PATH/"
fi

# Backup logs recentes (últimos 7 dias)
if [ -d "logs" ]; then
    echo "[BACKUP] logs (últimos 7 dias)"
    find logs -name "*.log" -mtime -7 -exec cp {} "$BACKUP_PATH/" \;
fi

# Cria arquivo de metadados
cat > "$BACKUP_PATH/METADATA.txt" << EOF
ORÁCULO Backup
Data: $(date)
Versão: $(git describe --tags 2>/dev/null || echo "desconhecida")
Commit: $(git rev-parse HEAD 2>/dev/null || echo "não git")
Android: $(getprop ro.build.version.release)
Modelo: $(getprop ro.product.model)
EOF

# Compacta
echo "[COMPACTANDO] ${BACKUP_NAME}.tar.gz"
cd "$BACKUP_DIR"
tar -czf "${BACKUP_NAME}.tar.gz" "${BACKUP_NAME}"
rm -rf "${BACKUP_NAME}"
cd ..

SIZE=$(du -h "${BACKUP_DIR}/${BACKUP_NAME}.tar.gz" | cut -f1)
echo ""
echo "=========================================="
echo "  ✅ Backup concluído: ${BACKUP_NAME}.tar.gz (${SIZE})"
echo "  Local: ${BACKUP_DIR}/"
echo "=========================================="

# Limpa backups antigos (mantém últimos 10)
cd "$BACKUP_DIR"
ls -t oraculo_backup_*.tar.gz 2>/dev/null | tail -n +11 | xargs -r rm -f
cd ..