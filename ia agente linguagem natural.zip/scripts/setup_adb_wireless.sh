#!/bin/bash
# ORÁCULO — Configuração ADB Wireless no próprio celular
# Android 11+ suporta pareamento sem fio nativo (sem PC, sem cabo)

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[AVISO]${NC} $1"; }
log_error() { echo -e "${RED}[ERRO]${NC} $1"; }

echo "=========================================="
echo "  ORÁCULO — ADB Wireless Setup"
echo "=========================================="
echo ""

# Verifica Android 11+ (API 30+)
API_LEVEL=$(getprop ro.build.version.sdk)
if [ "$API_LEVEL" -lt 30 ]; then
    log_error "Android 11+ (API 30+) necessário para pareamento sem fio nativo."
    log_error "Seu Android: API $API_LEVEL"
    log_info "Alternativa: use ADB via cabo USB no PC uma vez, depois adb tcpip 5555"
    exit 1
fi

log_ok "Android $API_LEVEL — suporte a pareamento sem fio nativo ✓"

# Verifica adb
if ! command -v adb >/dev/null; then
    log_error "ADB não instalado. Execute: pkg install android-tools"
    exit 1
fi

log_ok "ADB encontrado: $(adb version | head -1)"

# Mata servidor ADB existente
adb kill-server 2>/dev/null
sleep 1

# Verifica se já está pareado/conectado
if adb devices | grep -q "device$"; then
    DEVICE=$(adb devices | grep "device$" | cut -f1)
    log_ok "Já conectado: $DEVICE"
    echo ""
    echo "Testando conexão..."
    adb -s "$DEVICE" shell getprop ro.product.model
    exit 0
fi

echo ""
log_info "Iniciando pareamento sem fio..."
echo ""
echo "PASSOS NO CELULAR:"
echo "1. Vá em Configurações > Sistema > Opções do desenvolvedor"
echo "2. Ative 'Depuração USB' e 'Depuração sem fio'"
echo "3. Em 'Depuração sem fio', toque em 'Parear dispositivo com código de pareamento'"
echo "4. Anote o IP:PORTA e o CÓDIGO de 6 dígitos que aparecer"
echo ""
read -p "Pressione ENTER quando tiver o IP:PORTA e CÓDIGO..."

read -p "IP:PORTA (ex: 192.168.1.100:37891): " PAIR_ADDR
read -p "CÓDIGO (6 dígitos): " PAIR_CODE

log_info "Pareando com $PAIR_ADDR..."
adb pair "$PAIR_ADDR" "$PAIR_CODE"

if [ $? -ne 0 ]; then
    log_error "Pareamento falhou. Verifique IP, porta e código."
    exit 1
fi

log_ok "Pareamento bem-sucedido!"

# Agora conecta
read -p "IP:PORTA para conexão (geralmente 192.168.x.x:5555): " CONNECT_ADDR

log_info "Conectando em $CONNECT_ADDR..."
adb connect "$CONNECT_ADDR"

if [ $? -ne 0 ]; then
    log_error "Conexão falhou."
    exit 1
fi

log_ok "Conectado!"

# Verifica
DEVICE=$(adb devices | grep "device$" | cut -f1)
log_info "Dispositivo: $DEVICE"
adb -s "$DEVICE" shell getprop ro.product.model
adb -s "$DEVICE" shell getprop ro.build.version.release

echo ""
echo "=========================================="
log_ok "ADB Wireless configurado com sucesso!"
echo "=========================================="
echo ""
echo "Para usar no ORÁCULO, edite config.yaml:"
echo "  automation:"
echo "    method: adb"
echo "    adb_host: \"$(echo $CONNECT_ADDR | cut -d: -f1)\""
echo "    adb_port: $(echo $CONNECT_ADDR | cut -d: -f2)"
echo ""
echo "Teste rápido:"
echo "  adb shell input tap 500 500"
echo "  adb shell am start -n com.whatsapp/.Main"
echo ""