"""
Utilidades de áudio para ORÁCULO.
Usa termux-microphone-record e termux-media-player (nativos do Termux:API).
"""

import subprocess
import tempfile
import os
import wave
import struct
from pathlib import Path
from typing import Optional, Tuple, BinaryIO
from dataclasses import dataclass

from oraculo.utils.helpers import run_command, check_command_exists
from oraculo.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class AudioConfig:
    """Configuração de áudio."""
    sample_rate: int = 16000
    channels: int = 1
    format: str = "wav"  # wav, mp3, opus
    encoding: str = "signed-integer"
    bits_per_sample: int = 16


# Configuração padrão
DEFAULT_AUDIO_CONFIG = AudioConfig()


def check_audio_tools() -> Tuple[bool, bool]:
    """
    Verifica ferramentas de áudio disponíveis.

    Returns:
        (has_microphone_record, has_media_player)
    """
    has_record = check_command_exists("termux-microphone-record")
    has_play = check_command_exists("termux-media-player")
    return has_record, has_play


def record_audio(
    output_path: Path,
    duration: Optional[float] = None,
    limit: Optional[int] = None,
    config: AudioConfig = DEFAULT_AUDIO_CONFIG,
) -> bool:
    """
    Grava áudio do microfone usando termux-microphone-record.

    Args:
        output_path: Caminho do arquivo de saída
        duration: Duração em segundos (None = até Ctrl+C ou limite)
        limit: Limite em bytes (padrão Termux: 1048576 = 1MB)
        config: Configuração de áudio

    Returns:
        True se gravou com sucesso
    """
    if not check_command_exists("termux-microphone-record"):
        logger.error("termux-microphone-record não encontrado. Instale Termux:API (F-Droid).")
        return False

    # Garante diretório
    output_path.parent.mkdir(parents=True, exist_ok=True)

    cmd = ["termux-microphone-record", "-f", str(output_path)]

    if config.format == "wav":
        cmd.extend(["-e", "wav"])
    elif config.format == "mp3":
        cmd.extend(["-e", "mp3"])
    elif config.format == "opus":
        cmd.extend(["-e", "opus"])

    if config.sample_rate:
        cmd.extend(["-r", str(config.sample_rate)])

    if config.channels:
        cmd.extend(["-c", str(config.channels)])

    if limit:
        cmd.extend(["-l", str(limit)])

    logger.info(f"Gravando áudio: {' '.join(cmd)}")

    try:
        if duration:
            # Termux-microphone-record não tem opção -d, roda em background e mata depois
            proc = subprocess.Popen(cmd)
            import time
            time.sleep(duration)
            proc.terminate()
            proc.wait(timeout=2)
        else:
            # Modo interativo - usuário para com Ctrl+C
            result = subprocess.run(cmd, check=True)
            if result.returncode != 0:
                logger.error(f"Gravação falhou: código {result.returncode}")
                return False
    except subprocess.CalledProcessError as e:
        logger.error(f"Erro na gravação: {e}")
        return False
    except KeyboardInterrupt:
        logger.info("Gravação interrompida pelo usuário")
    except Exception as e:
        logger.error(f"Erro inesperado: {e}")
        return False

    # Verifica se arquivo foi criado e tem conteúdo
    if output_path.exists() and output_path.stat().st_size > 100:
        logger.info(f"Áudio gravado: {output_path} ({output_path.stat().st_size} bytes)")
        return True
    else:
        logger.error("Arquivo de áudio vazio ou não criado")
        return False


def record_audio_vad(
    output_path: Path,
    silence_threshold: float = 0.02,
    silence_duration: float = 1.5,
    max_duration: float = 30.0,
    config: AudioConfig = DEFAULT_AUDIO_CONFIG,
) -> bool:
    """
    Grava áudio com detecção de voz (VAD) simples.
    Grava até detectar silêncio por `silence_duration` segundos.

    Nota: Implementação simples baseada em RMS. Para VAD real, use webrtcvad ou silero-vad.
    """
    logger.info(f"Iniciando gravação com VAD (silêncio: {silence_duration}s, threshold: {silence_threshold})")

    # Como termux-microphone-record não suporta VAD nativo,
    # gravamos em chunks e analisamos RMS
    import time
    import numpy as np

    chunk_duration = 0.5  # segundos
    chunk_samples = int(config.sample_rate * chunk_duration)
    silence_chunks_needed = int(silence_duration / chunk_duration)

    # Grava arquivo temporário contínuo
    temp_path = output_path.with_suffix(".tmp.wav")

    cmd = [
        "termux-microphone-record",
        "-f", str(temp_path),
        "-e", "wav",
        "-r", str(config.sample_rate),
        "-c", str(config.channels),
    ]

    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    silence_chunks = 0
    total_chunks = 0
    max_chunks = int(max_duration / chunk_duration)

    try:
        while total_chunks < max_chunks:
            time.sleep(chunk_duration)
            total_chunks += 1

            # Verifica tamanho do arquivo
            if temp_path.exists() and temp_path.stat().st_size > 44:  # header WAV = 44 bytes
                # Lê último chunk para calcular RMS
                try:
                    with wave.open(str(temp_path), "rb") as wf:
                        frames = wf.readframes(chunk_samples)
                        if frames:
                            # Calcula RMS simples
                            samples = struct.unpack(f"<{len(frames)//2}h", frames)
                            rms = (sum(s*s for s in samples) / len(samples)) ** 0.5
                            max_amplitude = 32767  # 16-bit signed
                            normalized_rms = rms / max_amplitude

                            if normalized_rms < silence_threshold:
                                silence_chunks += 1
                            else:
                                silence_chunks = 0

                            if silence_chunks >= silence_chunks_needed:
                                logger.info("Silêncio detectado, finalizando gravação")
                                break
                except Exception:
                    pass
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()

    # Move temp para final
    if temp_path.exists():
        temp_path.replace(output_path)
        logger.info(f"Gravação VAD concluída: {output_path}")
        return True

    return False


def play_audio(file_path: Path) -> bool:
    """
    Toca arquivo de áudio usando termux-media-player.

    Args:
        file_path: Caminho do arquivo de áudio

    Returns:
        True se tocou com sucesso
    """
    if not check_command_exists("termux-media-player"):
        logger.error("termux-media-player não encontrado. Instale Termux:API (F-Droid).")
        return False

    if not file_path.exists():
        logger.error(f"Arquivo não encontrado: {file_path}")
        return False

    logger.info(f"Tocando áudio: {file_path}")

    try:
        # termux-media-player play <file>
        result = subprocess.run(
            ["termux-media-player", "play", str(file_path)],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            logger.error(f"Erro ao tocar: {result.stderr}")
            return False
        return True
    except subprocess.TimeoutExpired:
        logger.error("Timeout ao tocar áudio")
        return False
    except Exception as e:
        logger.error(f"Erro inesperado: {e}")
        return False


def stop_audio() -> bool:
    """Para reprodução de áudio."""
    try:
        subprocess.run(["termux-media-player", "stop"], check=False)
        return True
    except Exception:
        return False


def convert_audio(input_path: Path, output_path: Path, target_sr: int = 16000) -> bool:
    """
    Converte áudio usando ffmpeg (se disponível).
    """
    if not check_command_exists("ffmpeg"):
        logger.warning("ffmpeg não disponível, pulando conversão")
        return False

    try:
        subprocess.run([
            "ffmpeg", "-y", "-i", str(input_path),
            "-ar", str(target_sr),
            "-ac", "1",
            "-c:a", "pcm_s16le",
            str(output_path)
        ], check=True, capture_output=True)
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Erro na conversão: {e.stderr.decode()}")
        return False


def get_audio_duration(file_path: Path) -> float:
    """Retorna duração do áudio em segundos."""
    try:
        with wave.open(str(file_path), "rb") as wf:
            frames = wf.getnframes()
            rate = wf.getframerate()
            return frames / float(rate)
    except Exception:
        return 0.0


def create_silence(duration: float, output_path: Path, config: AudioConfig = DEFAULT_AUDIO_CONFIG) -> bool:
    """Cria arquivo de silêncio (útil para testes)."""
    try:
        sample_rate = config.sample_rate
        channels = config.channels
        num_samples = int(sample_rate * duration)

        with wave.open(str(output_path), "wb") as wf:
            wf.setnchannels(channels)
            wf.setsampwidth(config.bits_per_sample // 8)
            wf.setframerate(sample_rate)
            # Escreve zeros (silêncio)
            silence = struct.pack(f"<{num_samples * channels}h", *([0] * num_samples * channels))
            wf.writeframes(silence)
        return True
    except Exception as e:
        logger.error(f"Erro criando silêncio: {e}")
        return False