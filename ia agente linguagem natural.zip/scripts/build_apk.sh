#!/bin/bash
# ORÁCULO — Compila APK no Termux via Buildozer
# ATENÇÃO: Compilar no celular leva 20-60 min. Use carregador!

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[AVISO]${NC} $1"; }
log_error() { echo -e "${RED}[ERRO]${NC} $1"; }

echo "=========================================="
echo "  ORÁCULO — Build APK (Buildozer)"
echo "=========================================="
echo ""
log_warn "Compilar no celular consome muita bateria e tempo (20-60 min)."
log_warn "Mantenha o celular no carregador e não trave a tela."
echo ""

read -p "Continuar? (s/N): " CONFIRM
if [[ ! "$CONFIRM" =~ ^[Ss]$ ]]; then
    log_info "Cancelado."
    exit 0
fi

# Verifica espaço
FREE_GB=$(df -h /data | tail -1 | awk '{print $4}' | sed 's/G//')
if (( $(echo "$FREE_GB < 5" | bc -l) )); then
    log_error "Espaço insuficiente: ${FREE_GB}GB livres (mín 5GB)"
    exit 1
fi
log_ok "Espaço livre: ${FREE_GB}GB"

# Verifica buildozer.spec
if [ ! -f "buildozer.spec" ]; then
    log_error "buildozer.spec não encontrado na raiz do projeto"
    exit 1
fi

# Instala dependências do sistema
log_info "Instalando dependências do sistema..."
pkg update -y
pkg install -y \
    openjdk-17 \
    python3 \
    python3-pip \
    git \
    zip \
    unzip \
    wget \
    curl \
    libffi \
    libffi-dev \
    openssl \
    openssl-dev \
    zlib \
    zlib-dev \
    ncurses \
    ncurses-dev \
    readline \
    readline-dev \
    sqlite \
    sqlite-dev \
    libxml2 \
    libxml2-dev \
    libxslt \
    libxslt-dev \
    patchelf \
    ccache

# Configura Java
export JAVA_HOME="/usr/lib/jvm/java-17-openjdk"
export PATH="$JAVA_HOME/bin:$PATH"
log_ok "Java: $(java -version 2>&1 | head -1)"

# Instala buildozer
log_info "Instalando buildozer..."
pip install --upgrade pip setuptools wheel cython
pip install buildozer

# Inicializa buildozer se necessário
if [ ! -d ".buildozer" ]; then
    log_info "Inicializando buildozer (primeira vez, baixa Android SDK/NDK)..."
    buildozer init
    # Restaura nosso buildozer.spec
    git checkout buildozer.spec 2>/dev/null || true
fi

# Build
log_info "Iniciando build (pode demorar muito)..."
log_warn "Não trave a tela! Use: termux-wake-lock"

termux-wake-lock

# Build debug
buildozer -v android debug 2>&1 | tee build.log

termux-wake-unlock

# Verifica resultado
APK_PATH=$(find bin -name "*.apk" -type f 2>/dev/null | head -1)
if [ -n "$APK_PATH" ]; then
    log_ok "APK gerado: $APK_PATH"
    SIZE=$(du -h "$APK_PATH" | cut -f1)
    log_info "Tamanho: $SIZE"

    # Instala opcional
    read -p "Instalar APK agora? (s/N): " INSTALL
    if [[ "$INSTALL" =~ ^[Ss]$ ]]; then
        termux-open "$APK_PATH"
        log_info "Abra o instalador que apareceu na tela."
    fi
else
    log_error "APK não gerado. Verifique build.log"
    tail -50 build.log
    exit 1
fi

echo ""
echo "=========================================="
log_ok "Build concluído!"
echo "=========================================="