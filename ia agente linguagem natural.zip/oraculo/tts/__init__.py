"""
TTS (Text-to-Speech) — Interface base e fábrica.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class TTSResult:
    """Resultado de síntese de fala."""
    audio_path: Path
    duration: float = 0.0
    engine: str = "unknown"
    success: bool = True
    error: str = ""


class TTSEngine(ABC):
    """Interface base para engines de TTS."""

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        self.model_path = model_path
        self.config = config
        self._loaded = False

    @abstractmethod
    def load(self) -> bool:
        """Carrega modelo/engine. Retorna True se sucesso."""
        pass

    @abstractmethod
    def synthesize(self, text: str, output_path: Path) -> TTSResult:
        """
        Sintetiza texto em áudio.

        Args:
            text: Texto para sintetizar
            output_path: Caminho do arquivo de saída

        Returns:
            TTSResult com caminho do áudio gerado
        """
        pass

    @abstractmethod
    def unload(self) -> None:
        """Libera recursos."""
        pass

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def __enter__(self):
        self.load()
        return self

    def __exit__(self, *args):
        self.unload()


# Registry
_ENGINES: Dict[str, type] = {}


def register_engine(name: str, engine_class: type) -> None:
    _ENGINES[name] = engine_class


def get_engine(name: str) -> Optional[type]:
    return _ENGINES.get(name)


def list_engines() -> Dict[str, type]:
    return _ENGINES.copy()


def create_tts(engine_name: str, model_path: Path, config: Dict[str, Any]) -> Optional[TTSEngine]:
    engine_class = get_engine(engine_name)
    if engine_class is None:
        return None
    return engine_class(model_path, config)