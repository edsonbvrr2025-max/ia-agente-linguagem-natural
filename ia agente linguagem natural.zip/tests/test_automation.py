"""
Testes para Automação (ADB + Termux:API).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from oraculo.config import get_config
from oraculo.automation import create_automation, list_backends
from oraculo.utils.logger import setup_logging
from oraculo.utils.helpers import check_command_exists


def test_automation_backends():
    print("Backends automação registrados:", list_backends())


def test_adb():
    config = get_config()
    auto_config = config.automation

    if auto_config.method != "adb":
        print(f"Método configurado é {auto_config.method}")
        return True

    if not check_command_exists("adb"):
        print("ADB não instalado (pkg install android-tools)")
        return False

    adb = create_automation("adb", auto_config.__dict__)
    if not adb:
        print("Falha criando backend ADB")
        return False

    if not adb.connect():
        print("Falha conectando ADB")
        print("Execute: bash scripts/setup_adb_wireless.sh")
        return False

    print("✅ ADB conectado")

    # Teste simples: toast
    result = adb.execute_action("toast", {"mensagem": "Teste ADB ORÁCULO", "duracao": "short"})
    print(f"Toast: {result.message}")

    # Teste: bateria
    result = adb.execute_action("bateria", {})
    print(f"Bateria: {result.message}")

    adb.disconnect()
    return True


def test_termux_api():
    config = get_config()
    auto_config = config.automation

    if auto_config.method != "termux_api":
        print(f"Método configurado é {auto_config.method}")
        return True

    termux_api = create_automation("termux_api", auto_config.__dict__)
    if not termux_api:
        print("Falha criando backend Termux:API")
        return False

    if not termux_api.connect():
        print("Termux:API não disponível")
        print("Instale: pkg install termux-api + app Termux:API do F-Droid")
        return False

    print("✅ Termux:API conectado")

    # Teste: notificações
    result = termux_api.execute_action("ler_notificacoes", {"limite": 3})
    print(f"Notificações: {result.message}")

    # Teste: toast
    result = termux_api.execute_action("toast", {"mensagem": "Teste Termux:API"})
    print(f"Toast: {result.message}")

    return True


def test_whatsapp():
    """Teste WhatsApp (requer ADB conectado e WhatsApp instalado)."""
    from oraculo.automation.whatsapp import WhatsAppAutomation

    config = get_config()
    auto_config = config.automation

    if auto_config.method != "adb":
        print("Teste WhatsApp requer ADB")
        return True

    if not check_command_exists("adb"):
        return True

    wa = WhatsAppAutomation()
    if not wa.connect():
        print("ADB não conectado para teste WhatsApp")
        return True

    print("✅ WhatsAppAutomation conectado")
    print("Para testar envio real, use:")
    print("  python -m oraculo.automation.whatsapp 'Contato' 'Mensagem'")

    wa.disconnect()
    return True


def main():
    setup_logging()
    print("="*50)
    print("  TESTE AUTOMAÇÃO")
    print("="*50)

    test_automation_backends()
    print()

    all_passed = True
    all_passed &= test_adb()
    all_passed &= test_termux_api()
    all_passed &= test_whatsapp()

    print("\n" + "="*50)
    if all_passed:
        print("  ✅ TODOS OS TESTES PASSARAM")
    else:
        print("  ❌ ALGUNS TESTES FALHARAM")
    print("="*50)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())