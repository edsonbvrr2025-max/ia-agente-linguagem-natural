"""
LLM (Large Language Model) — Interface base e fábrica.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass


@dataclass
class LLMResponse:
    """Resposta do LLM."""
    text: str
    tool_calls: List[Dict[str, Any]] = None
    usage: Dict[str, int] = None
    model: str = "unknown"


@dataclass
class ToolCall:
    """Chamada de ferramenta (function calling)."""
    name: str
    arguments: Dict[str, Any]
    call_id: str = ""


class LLMEngine(ABC):
    """Interface base para engines de LLM."""

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        self.model_path = model_path
        self.config = config
        self._loaded = False

    @abstractmethod
    def load(self) -> bool:
        """Carrega modelo. Retorna True se sucesso."""
        pass

    @abstractmethod
    def generate(
        self,
        prompt: str,
        tools: Optional[List[Dict]] = None,
        tool_choice: str = "auto",
        max_tokens: int = 512,
        temperature: float = 0.3,
        stop: Optional[List[str]] = None,
    ) -> LLMResponse:
        """
        Gera resposta do modelo.

        Args:
            prompt: Prompt completo (system + user + histórico)
            tools: Lista de definições de ferramentas (OpenAI format)
            tool_choice: "auto" | "none" | "required" | {"type": "function", "function": {"name": "..."}}
            max_tokens: Máximo de tokens na resposta
            temperature: Temperatura de amostragem
            stop: Sequências de parada

        Returns:
            LLMResponse com texto e tool_calls opcionais
        """
        pass

    @abstractmethod
    def unload(self) -> None:
        """Libera recursos."""
        pass

    @abstractmethod
    def tokenize(self, text: str) -> List[int]:
        """Tokeniza texto (para contagem de tokens)."""
        pass

    @abstractmethod
    def detokenize(self, tokens: List[int]) -> str:
        """Converte tokens de volta para texto."""
        pass

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def __enter__(self):
        self.load()
        return self

    def __exit__(self, *args):
        self.unload()


# Registry
_ENGINES: Dict[str, type] = {}


def register_engine(name: str, engine_class: type) -> None:
    _ENGINES[name] = engine_class


def get_engine(name: str) -> Optional[type]:
    return _ENGINES.get(name)


def list_engines() -> Dict[str, type]:
    return _ENGINES.copy()


def create_llm(engine_name: str, model_path: Path, config: Dict[str, Any]) -> Optional[LLMEngine]:
    engine_class = get_engine(engine_name)
    if engine_class is None:
        return None
    return engine_class(model_path, config)