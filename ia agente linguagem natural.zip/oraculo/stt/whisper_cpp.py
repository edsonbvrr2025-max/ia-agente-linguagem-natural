"""
STT via whisper.cpp — Melhor precisão para pt-BR offline.

Requer:
- whisper.cpp compilado no Termux (ou binário pré-compilado)
- Modelo GGML (ex: ggml-base-pt-br.bin, ggml-small-pt-br.bin)

Instalação no Termux:
  pkg install clang cmake make
  git clone https://github.com/ggerganov/whisper.cpp
  cd whisper.cpp
  make -j$(nproc)
  # Binário em: ./main ou ./build/bin/whisper-cli

Modelos pt-BR (baixar em models/stt/):
- ggml-tiny-pt-br.bin    ~39 MB  (rápido, menos preciso)
- ggml-base-pt-br.bin    ~142 MB (equilibrado) ← RECOMENDADO
- ggml-small-pt-br.bin   ~466 MB (mais preciso, mais lento)
"""

import subprocess
import json
import tempfile
from pathlib import Path
from typing import Dict, Any, List, Optional

from oraculo.stt import STTEngine, STTResult, register_engine
from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import check_command_exists, run_command

logger = get_logger(__name__)


class WhisperCppSTT(STTEngine):
    """Wrapper para whisper.cpp CLI."""

    # Binários possíveis (ordem de preferência)
    BINARIES = [
        "whisper-cli",           # whisper.cpp novo (2024+)
        "main",                  # whisper.cpp antigo
        "whisper-cpp",           # Alguns pacotes
        "/data/data/com.termux/files/usr/bin/whisper-cli",  # Termux instalado
    ]

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        super().__init__(model_path, config)
        self.binary_path: Optional[Path] = None
        self.whisper_config = config.get("whisper", {})

    def _find_binary(self) -> Optional[Path]:
        """Procura binário whisper.cpp no PATH ou caminhos conhecidos."""
        for binary in self.BINARIES:
            if check_command_exists(binary):
                # Resolve caminho real
                result = subprocess.run(["which", binary], capture_output=True, text=True)
                if result.returncode == 0 and result.stdout.strip():
                    return Path(result.stdout.strip())
        return None

    def load(self) -> bool:
        """Verifica binário e modelo."""
        self.binary_path = self._find_binary()

        if not self.binary_path:
            logger.error(
                "whisper.cpp não encontrado. Instale no Termux:\n"
                "  pkg install clang cmake make\n"
                "  git clone https://github.com/ggerganov/whisper.cpp\n"
                "  cd whisper.cpp && make -j$(nproc)"
            )
            return False

        if not self.model_path.exists():
            logger.error(f"Modelo não encontrado: {self.model_path}")
            logger.info("Baixe em: https://huggingface.co/ggerganov/whisper.cpp/tree/main")
            return False

        logger.info(f"whisper.cpp encontrado: {self.binary_path}")
        logger.info(f"Modelo: {self.model_path}")
        self._loaded = True
        return True

    def transcribe(self, audio_path: Path) -> STTResult:
        """Transcreve áudio usando whisper.cpp."""
        if not self._loaded:
            if not self.load():
                return STTResult(text="", confidence=0.0, engine="whisper_cpp")

        if not audio_path.exists():
            logger.error(f"Arquivo de áudio não encontrado: {audio_path}")
            return STTResult(text="", confidence=0.0, engine="whisper_cpp")

        # Prepara comando
        cmd = [
            str(self.binary_path),
            "-m", str(self.model_path),
            "-f", str(audio_path),
            "-l", self.config.get("language", "pt"),  # idioma
            "-nt",  # no timestamps
            "-np",  # no progress
        ]

        # Threads
        threads = self.whisper_config.get("n_threads", 4)
        if threads:
            cmd.extend(["-t", str(threads)])

        # Output JSON para parsing fácil
        cmd.extend(["-oj"])  # output json

        logger.debug(f"Executando: {' '.join(cmd)}")

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.config.get("timeout", 60),
            )

            if result.returncode != 0:
                logger.error(f"whisper.cpp falhou: {result.stderr}")
                return STTResult(text="", confidence=0.0, engine="whisper_cpp")

            # Parse JSON output
            # whisper.cpp -oj imprime JSON no stdout
            output = result.stdout.strip()
            if not output:
                logger.warning("whisper.cpp retornou saída vazia")
                return STTResult(text="", confidence=0.0, engine="whisper_cpp")

            # O JSON pode estar em múltiplas linhas, pega a última linha válida
            for line in reversed(output.split("\n")):
                line = line.strip()
                if line.startswith("{"):
                    try:
                        data = json.loads(line)
                        text = data.get("text", "").strip()
                        # whisper.cpp não retorna confidence nativamente
                        # Usamos heurística baseada em tokens
                        return STTResult(
                            text=text,
                            confidence=0.9 if text else 0.0,
                            language=self.config.get("language", "pt"),
                            engine="whisper_cpp",
                        )
                    except json.JSONDecodeError:
                        continue

            # Fallback: pega stdout direto se não for JSON
            text = output.strip()
            return STTResult(
                text=text,
                confidence=0.8 if text else 0.0,
                language=self.config.get("language", "pt"),
                engine="whisper_cpp",
            )

        except subprocess.TimeoutExpired:
            logger.error("whisper.cpp timeout")
            return STTResult(text="", confidence=0.0, engine="whisper_cpp")
        except Exception as e:
            logger.error(f"Erro inesperado: {e}")
            return STTResult(text="", confidence=0.0, engine="whisper_cpp")

    def unload(self) -> None:
        """Nada a liberar (processo externo)."""
        self._loaded = False


# Registra engine
register_engine("whisper_cpp", WhisperCppSTT)


# Função auxiliar para baixar modelo
def download_model(model_name: str, output_dir: Path) -> bool:
    """
    Baixa modelo GGML do Hugging Face.

    Modelos disponíveis:
    - ggml-tiny-pt-br.bin
    - ggml-base-pt-br.bin
    - ggml-small-pt-br.bin
    - ggml-medium-pt-br.bin
    - ggml-large-v3-pt-br.bin (muito grande)
    """
    import urllib.request

    base_url = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main"
    url = f"{base_url}/{model_name}"
    output_path = output_dir / model_name

    output_dir.mkdir(parents=True, exist_ok=True)

    if output_path.exists():
        logger.info(f"Modelo já existe: {output_path}")
        return True

    logger.info(f"Baixando {model_name} de {url}...")
    try:
        urllib.request.urlretrieve(url, output_path)
        logger.info(f"Modelo baixado: {output_path} ({output_path.stat().st_size / 1024 / 1024:.1f} MB)")
        return True
    except Exception as e:
        logger.error(f"Erro baixando modelo: {e}")
        return False


def compile_whisper_cpp(build_dir: Path = Path("whisper.cpp")) -> bool:
    """
    Compila whisper.cpp no Termux.
    Retorna True se sucesso.
    """
    if not check_command_exists("git"):
        logger.error("git não instalado: pkg install git")
        return False
    if not check_command_exists("cmake"):
        logger.error("cmake não instalado: pkg install cmake")
        return False
    if not check_command_exists("make"):
        logger.error("make não instalado: pkg install make")
        return False
    if not check_command_exists("clang"):
        logger.error("clang não instalado: pkg install clang")
        return False

    logger.info("Clonando whisper.cpp...")
    if not build_dir.exists():
        result = run_command(["git", "clone", "https://github.com/ggerganov/whisper.cpp.git", str(build_dir)])
        if result[0] != 0:
            logger.error(f"Falha no clone: {result[2]}")
            return False

    logger.info("Compilando whisper.cpp...")
    # Tenta compilar com Vulkan se disponível
    cmake_args = ["-DGGML_VULKAN=ON"] if _check_vulkan() else []

    result = run_command(["cmake", "-B", "build", *cmake_args], capture=False)
    if result[0] != 0:
        logger.warning("CMake com Vulkan falhou, tentando sem...")
        result = run_command(["cmake", "-B", "build"], capture=False)
        if result[0] != 0:
            logger.error("CMake falhou")
            return False

    result = run_command(["cmake", "--build", "build", "--config", "Release", "-j"], capture=False)
    if result[0] != 0:
        logger.error("Build falhou")
        return False

    # Copia binário para $PREFIX/bin
    binary = build_dir / "build" / "bin" / "whisper-cli"
    if binary.exists():
        import shutil
        prefix_bin = Path("/data/data/com.termux/files/usr/bin")
        prefix_bin.mkdir(parents=True, exist_ok=True)
        shutil.copy2(binary, prefix_bin / "whisper-cli")
        logger.info(f"whisper-cli instalado em {prefix_bin}")
        return True

    logger.error("Binário não encontrado após build")
    return False


def _check_vulkan() -> bool:
    """Verifica se Vulkan está disponível no Termux."""
    # Verifica se libvulkan.so existe
    vulkan_paths = [
        "/system/lib64/libvulkan.so",
        "/vendor/lib64/libvulkan.so",
        "/data/data/com.termux/files/usr/lib/libvulkan.so",
    ]
    return any(Path(p).exists() for p in vulkan_paths)