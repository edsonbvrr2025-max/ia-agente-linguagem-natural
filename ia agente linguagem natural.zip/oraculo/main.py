#!/usr/bin/env python3
"""
ORÁCULO — Entry point principal.

Uso:
    python -m oraculo          # Inicia agente (usa config.yaml)
    python -m oraculo --test   # Executa testes isolados
    python -m oraculo --diagnostico  # Mostra info do sistema
"""

import sys
import argparse
from pathlib import Path

from oraculo.orchestrator.loop import main as orchestrator_main
from oraculo.utils.helpers import get_system_info, print_system_info
from oraculo.utils.logger import setup_logging, get_logger

logger = get_logger(__name__)


def run_diagnostics():
    """Executa diagnóstico completo do sistema."""
    print("\n" + "="*60)
    print("  ORÁCULO — Diagnóstico do Sistema")
    print("="*60)

    info = get_system_info()
    print_system_info(info)

    # Verifica dependências chave
    print("\n📦 Dependências:")
    deps = [
        ("termux-api", "Termux:API (notificação, microfone, etc.)"),
        ("termux-microphone-record", "Gravação de áudio"),
        ("termux-media-player", "Reprodução de áudio"),
        ("adb", "ADB (automação WhatsApp)"),
        ("python3", "Python 3.11+"),
        ("pip", "pip"),
        ("git", "Git"),
        ("ffmpeg", "FFmpeg (conversão áudio)"),
        ("sox", "SoX (áudio)"),
    ]

    for cmd, desc in deps:
        from oraculo.utils.helpers import check_command_exists
        status = "✅" if check_command_exists(cmd) else "❌"
        print(f"  {status} {cmd:30s} — {desc}")

    # Verifica Termux:API endpoints
    print("\n🔌 Termux:API Endpoints:")
    from oraculo.utils.helpers import get_termux_api_endpoints
    endpoints = get_termux_api_endpoints()
    for ep in endpoints:
        print(f"  ✅ {ep}")
    if not endpoints:
        print("  ❌ Nenhum (instale Termux:API do F-Droid)")

    # Verifica modelos
    print("\n🤖 Modelos:")
    model_paths = {
        "LLM": Path("models/llm"),
        "STT": Path("models/stt"),
        "TTS": Path("models/tts"),
        "Embeddings": Path("models/embeddings"),
    }
    for name, path in model_paths.items():
        if path.exists():
            files = list(path.glob("*"))
            print(f"  ✅ {name}: {len(files)} arquivo(s) em {path}")
            for f in files[:5]:
                print(f"      - {f.name}")
            if len(files) > 5:
                print(f"      ... e mais {len(files)-5}")
        else:
            print(f"  ❌ {name}: pasta não existe ({path})")

    # Verifica arquivos de config/memória
    print("\n📄 Arquivos:")
    for fname in ["config.yaml", "memoria.md", "perfil.md"]:
        path = Path(fname)
        status = "✅" if path.exists() else "❌"
        print(f"  {status} {fname}")

    print("\n" + "="*60)


def run_tests():
    """Executa testes isolados de cada componente."""
    import subprocess

    tests = [
        ("test_stt", "STT (whisper.cpp/Vosk/termux-stt)"),
        ("test_llm", "LLM (llama.cpp)"),
        ("test_tts", "TTS (Piper/espeak-ng)"),
        ("test_automation", "Automação (ADB/Termux:API)"),
        ("test_memory", "Memória (arquivo + vetorial)"),
    ]

    print("\n🧪 Executando testes isolados...\n")

    for module, desc in tests:
        print(f"▶️  Testando {desc}...")
        result = subprocess.run(
            [sys.executable, "-m", f"oraculo.tests.{module}"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode == 0:
            print(f"   ✅ PASSOU")
            if result.stdout.strip():
                for line in result.stdout.strip().split("\n")[:3]:
                    print(f"      {line}")
        else:
            print(f"   ❌ FALHOU")
            if result.stderr.strip():
                for line in result.stderr.strip().split("\n")[:3]:
                    print(f"      {line}")
        print()


def main():
    parser = argparse.ArgumentParser(description="ORÁCULO — Agente IA Offline para Android")
    parser.add_argument("--config", default="config.yaml", help="Arquivo de configuração")
    parser.add_argument("--test", action="store_true", help="Executa testes isolados")
    parser.add_argument("--diagnostico", action="store_true", help="Mostra diagnóstico do sistema")
    parser.add_argument("--continuous", action="store_true", help="Modo contínuo (loop)")
    parser.add_argument("--single", action="store_true", help="Modo comando único")

    args = parser.parse_args()

    if args.diagnostico:
        run_diagnostics()
        return

    if args.test:
        run_tests()
        return

    # Inicia orquestrador
    sys.argv = [sys.argv[0]] + ([args.config] if args.config != "config.yaml" else [])
    orchestrator_main()


if __name__ == "__main__":
    main()