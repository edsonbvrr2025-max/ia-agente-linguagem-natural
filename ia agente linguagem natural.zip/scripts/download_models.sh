#!/bin/bash
# ORÁCULO — Download de modelos
# Uso: bash scripts/download_models.sh [opções]
# Opções:
#   --llm MODEL       Baixa LLM (qwen2.5-3b-q4, llama-3.2-3b-q4, gemma-3-4b-q4, phi-4-mini-q4)
#   --stt MODEL       Baixa STT (whisper_base, whisper_small, vosk)
#   --tts MODEL       Baixa TTS (piper_low, piper_medium, piper_high)
#   --embeddings      Baixa modelo de embeddings (all-MiniLM-L6-v2)
#   --all             Baixa todos os recomendados
#   --list            Lista modelos disponíveis

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[AVISO]${NC} $1"; }
log_error() { echo -e "${RED}[ERRO]${NC} $1"; }

# Diretórios
mkdir -p models/llm models/stt models/tts models/embeddings

# Python downloader
PYTHON_DOWNLOADER=$(cat << 'PYEOF'
import sys
import urllib.request
import os
from pathlib import Path

def download(url, dest, desc=""):
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        print(f"[OK] Já existe: {dest.name}")
        return True
    print(f"[DOWNLOAD] {desc or dest.name}...")
    try:
        urllib.request.urlretrieve(url, dest)
        size = dest.stat().st_size / 1024 / 1024
        print(f"[OK] Baixado: {dest.name} ({size:.1f} MB)")
        return True
    except Exception as e:
        print(f"[ERRO] Falha: {e}")
        return False

# Modelos LLM (GGUF)
LLM_MODELS = {
    "qwen2.5-3b-q4": {
        "url": "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf",
        "dest": "models/llm/qwen2.5-3b-instruct-q4_k_m.gguf",
        "size": "~2.1 GB",
    },
    "llama-3.2-3b-q4": {
        "url": "https://huggingface.co/meta-llama/Llama-3.2-3B-Instruct-GGUF/resolve/main/llama-3.2-3b-instruct-q4_k_m.gguf",
        "dest": "models/llm/llama-3.2-3b-instruct-q4_k_m.gguf",
        "size": "~2.0 GB",
    },
    "gemma-3-4b-q4": {
        "url": "https://huggingface.co/google/gemma-3-4b-it-GGUF/resolve/main/gemma-3-4b-it-q4_k_m.gguf",
        "dest": "models/llm/gemma-3-4b-it-q4_k_m.gguf",
        "size": "~2.5 GB",
    },
    "phi-4-mini-q4": {
        "url": "https://huggingface.co/microsoft/Phi-4-mini-instruct-GGUF/resolve/main/phi-4-mini-instruct-q4_k_m.gguf",
        "dest": "models/llm/phi-4-mini-instruct-q4_k_m.gguf",
        "size": "~1.8 GB",
    },
}

# Modelos STT (whisper.cpp)
STT_MODELS = {
    "whisper_tiny": {
        "url": "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny-pt-br.bin",
        "dest": "models/stt/ggml-tiny-pt-br.bin",
        "size": "~39 MB",
    },
    "whisper_base": {
        "url": "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base-pt-br.bin",
        "dest": "models/stt/ggml-base-pt-br.bin",
        "size": "~142 MB",
    },
    "whisper_small": {
        "url": "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small-pt-br.bin",
        "dest": "models/stt/ggml-small-pt-br.bin",
        "size": "~466 MB",
    },
}

# Modelos TTS (Piper)
TTS_MODELS = {
    "piper_low": {
        "url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/pt_BR-faber-low.onnx",
        "dest": "models/tts/pt_BR-faber-low.onnx",
        "size": "~15 MB",
    },
    "piper_medium": {
        "url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/pt_BR-faber-medium.onnx",
        "dest": "models/tts/pt_BR-faber-medium.onnx",
        "size": "~50 MB",
    },
    "piper_high": {
        "url": "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/pt_BR-faber-high.onnx",
        "dest": "models/tts/pt_BR-faber-high.onnx",
        "size": "~150 MB",
    },
}

# Configs Piper (JSON)
PIPER_CONFIGS = {
    "piper_low": "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/pt_BR-faber-low.onnx.json",
    "piper_medium": "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/pt_BR-faber-medium.onnx.json",
    "piper_high": "https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/pt_BR-faber-high.onnx.json",
}

# Embeddings
EMBEDDING_MODEL = {
    "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/onnx/model.onnx",
    "dest": "models/embeddings/all-MiniLM-L6-v2.onnx",
    "size": "~90 MB",
}

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--llm", help="Modelo LLM para baixar")
    parser.add_argument("--stt", help="Modelo STT para baixar")
    parser.add_argument("--tts", help="Modelo TTS para baixar")
    parser.add_argument("--embeddings", action="store_true", help="Baixar embeddings")
    parser.add_argument("--all", action="store_true", help="Baixar todos recomendados")
    parser.add_argument("--list", action="store_true", help="Listar disponíveis")
    args = parser.parse_args()

    if args.list:
        print("=== LLM ===")
        for k, v in LLM_MODELS.items():
            print(f"  {k:20s} {v['size']:>8s}  {v['url']}")
        print("\n=== STT ===")
        for k, v in STT_MODELS.items():
            print(f"  {k:20s} {v['size']:>8s}  {v['url']}")
        print("\n=== TTS ===")
        for k, v in TTS_MODELS.items():
            print(f"  {k:20s} {v['size']:>8s}  {v['url']}")
        print("\n=== Embeddings ===")
        print(f"  all-MiniLM-L6-v2    {EMBEDDING_MODEL['size']:>8s}  {EMBEDDING_MODEL['url']}")
        sys.exit(0)

    success = True

    if args.all or args.llm:
        models = [args.llm] if args.llm else ["qwen2.5-3b-q4"]
        for m in models:
            if m in LLM_MODELS:
                success &= download(LLM_MODELS[m]["url"], LLM_MODELS[m]["dest"], f"LLM {m} ({LLM_MODELS[m]['size']})")
            else:
                print(f"[ERRO] LLM desconhecido: {m}")
                success = False

    if args.all or args.stt:
        models = [args.stt] if args.stt else ["whisper_base"]
        for m in models:
            if m in STT_MODELS:
                success &= download(STT_MODELS[m]["url"], STT_MODELS[m]["dest"], f"STT {m} ({STT_MODELS[m]['size']})")
            else:
                print(f"[ERRO] STT desconhecido: {m}")
                success = False

    if args.all or args.tts:
        models = [args.tts] if args.tts else ["piper_medium"]
        for m in models:
            if m in TTS_MODELS:
                success &= download(TTS_MODELS[m]["url"], TTS_MODELS[m]["dest"], f"TTS {m} ({TTS_MODELS[m]['size']})")
                # Baixa config JSON também
                if m in PIPER_CONFIGS:
                    config_dest = TTS_MODELS[m]["dest"] + ".json"
                    download(PIPER_CONFIGS[m], config_dest, f"Config {m}")
            else:
                print(f"[ERRO] TTS desconhecido: {m}")
                success = False

    if args.all or args.embeddings:
        success &= download(EMBEDDING_MODEL["url"], EMBEDDING_MODEL["dest"], f"Embeddings ({EMBEDDING_MODEL['size']})")

    if not any([args.llm, args.stt, args.tts, args.embeddings, args.all]):
        parser.print_help()
        sys.exit(1)

    sys.exit(0 if success else 1)
PYEOF
)

# Executa downloader Python
python3 -c "$PYTHON_DOWNLOADER" "$@"