"""
STT via termux-stt — Usa API nativa do Android (SpeechRecognizer).

Vantagens:
- Zero setup, usa modelo do sistema
- Funciona offline no Android 10+ (se modelo baixado nas configurações)
- Muito leve

Desvantagens:
- Menos preciso que whisper.cpp para pt-BR coloquial
- Dependente de fabricante/versão Android
- Não permite escolher modelo
"""

import subprocess
import json
import time
from pathlib import Path
from typing import Dict, Any

from oraculo.stt import STTEngine, STTResult, register_engine
from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import check_command_exists, run_command

logger = get_logger(__name__)


class TermuxSTT(STTEngine):
    """Wrapper para termux-stt (Android SpeechRecognizer)."""

    def __init__(self, model_path: Path, config: Dict[str, Any]):
        super().__init__(model_path, config)
        # model_path ignorado — usa modelo do sistema

    def load(self) -> bool:
        """Verifica se termux-stt está disponível."""
        if not check_command_exists("termux-stt"):
            logger.error(
                "termux-stt não encontrado.\n"
                "Instale Termux:API do F-Droid/GitHub (não Play Store).\n"
                "Depois: pkg install termux-api"
            )
            return False

        # Testa se funciona
        result = run_command(["termux-stt", "engines"])
        if result[0] != 0:
            logger.error(f"termux-stt engines falhou: {result[2]}")
            return False

        engines = result[1].strip()
        logger.info(f"Motores STT disponíveis: {engines}")
        self._loaded = True
        return True

    def transcribe(self, audio_path: Path) -> STTResult:
        """
        Transcreve usando termux-stt.

        Nota: termux-stt grava do microfone diretamente, não aceita arquivo.
        Esta implementação grava temporariamente e usa o resultado.
        """
        if not self._loaded:
            if not self.load():
                return STTResult(text="", confidence=0.0, engine="termux_stt")

        # termux-stt não aceita arquivo de entrada — ele grava do microfone
        # Workaround: usa termux-microphone-record + termux-stt em sequência
        # Mas termux-stt é interativo... Melhor usar whisper.cpp ou Vosk para arquivos.

        logger.warning("termux-stt não suporta arquivo de entrada direto.")
        logger.warning("Use whisper_cpp ou vosk para transcrição de arquivos.")
        logger.info("Para uso interativo, rode: termux-stt listen")

        return STTResult(
            text="",
            confidence=0.0,
            engine="termux_stt",
        )

    def listen_continuous(self, timeout: int = 10) -> STTResult:
        """
        Escuta continuamente e retorna texto reconhecido.
        Usa termux-stt listen (interativo).
        """
        if not self._loaded:
            if not self.load():
                return STTResult(text="", confidence=0.0, engine="termux_stt")

        logger.info(f"Escutando por {timeout}s... (termux-stt listen)")

        try:
            # termux-stt listen [-t timeout] [-l language]
            cmd = ["termux-stt", "listen"]
            if timeout:
                cmd.extend(["-t", str(timeout)])
            lang = self.config.get("language", "pt-BR")
            cmd.extend(["-l", lang])

            result = run_command(cmd, timeout=timeout + 5)

            if result[0] != 0:
                logger.error(f"termux-stt listen falhou: {result[2]}")
                return STTResult(text="", confidence=0.0, engine="termux_stt")

            # Output é JSON
            try:
                data = json.loads(result[1].strip())
                text = data.get("text", "").strip()
                confidence = data.get("confidence", 0.8)
                return STTResult(
                    text=text,
                    confidence=confidence,
                    language=lang,
                    engine="termux_stt",
                )
            except json.JSONDecodeError:
                # Fallback: texto direto
                text = result[1].strip()
                return STTResult(
                    text=text,
                    confidence=0.7 if text else 0.0,
                    language=lang,
                    engine="termux_stt",
                )

        except Exception as e:
            logger.error(f"Erro no termux-stt listen: {e}")
            return STTResult(text="", confidence=0.0, engine="termux_stt")

    def unload(self) -> None:
        self._loaded = False


# Registra engine
register_engine("termux_stt", TermuxSTT)