"""
Automação via ADB Wireless — Método mais confiável para WhatsApp e apps.

Requer:
- Android 11+ (pareamento sem fio nativo)
- ADB instalado no Termux: pkg install android-tools
- Pareamento: adb pair IP:PORTA + código
- Conexão: adb connect IP:PORTA

Fluxo WhatsApp completo com VERIFICAÇÃO:
1. am start -n com.whatsapp/.Main → abre app
2. input tap / uiautomator → busca contato
3. input text → digita mensagem
4. input tap → envia
5. uiautomator dump → VERIFICA se bolha da mensagem aparece na tela
6. Só então confirma "enviado"
"""

import subprocess
import time
import xml.etree.ElementTree as ET
import re
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

from oraculo.automation import AutomationBackend, AutomationResult, register_backend
from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import run_command, check_command_exists

logger = get_logger(__name__)


class ADBAutomation(AutomationBackend):
    """Backend de automação via ADB Wireless."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.host = config.get("adb_host", "127.0.0.1")
        self.port = config.get("adb_port", 5555)
        self.timeout = config.get("adb_timeout", 30)
        self.verify_actions = config.get("verify_actions", True)
        self.device_serial = None
        self._ui_cache = None
        self._ui_cache_time = 0

        # Delays configuráveis (ms)
        self.delays = config.get("delays", {
            "open_app": 2000,
            "search_contact": 1500,
            "open_chat": 1000,
            "focus_input": 500,
            "type_message": 1000,
            "tap_send": 500,
            "verify_sent": 2000,
        })

        # Seletores UI WhatsApp (XPath para uiautomator)
        self.ui_selectors = config.get("ui_selectors", {
            "search_box": "//*[@resource-id='com.whatsapp:id/search_box' or @content-desc='Buscar' or @text='Buscar']",
            "chat_list": "//*[@resource-id='com.whatsapp:id/chat_list']",
            "message_input": "//*[@resource-id='com.whatsapp:id/entry' or @content-desc='Mensagem']",
            "send_button": "//*[@resource-id='com.whatsapp:id/send' or @content-desc='Enviar']",
            "message_bubble": "//*[@resource-id='com.whatsapp:id/message_text']",
        })

    def connect(self) -> bool:
        """Conecta ADB wireless."""
        if not check_command_exists("adb"):
            logger.error("ADB não instalado. Termux: pkg install android-tools")
            return False

        # Verifica se já conectado
        if self._check_connection():
            logger.info(f"ADB já conectado: {self.device_serial}")
            self._connected = True
            return True

        # Tenta conectar
        logger.info(f"Conectando ADB em {self.host}:{self.port}...")
        result = run_command(["adb", "connect", f"{self.host}:{self.port}"], timeout=10)

        if result[0] != 0:
            logger.error(f"ADB connect falhou: {result[2]}")
            logger.info("Execute: bash scripts/setup_adb_wireless.sh")
            return False

        # Extrai serial do dispositivo
        match = re.search(r"connected to ([\d.:]+)", result[1])
        if match:
            self.device_serial = match.group(1)
        else:
            # Lista dispositivos
            result = run_command(["adb", "devices"])
            for line in result[1].split("\n"):
                if "\tdevice" in line:
                    self.device_serial = line.split("\t")[0]
                    break

        if self.device_serial:
            logger.info(f"ADB conectado: {self.device_serial}")
            self._connected = True
            return True

        logger.error("Não conseguiu obter serial do dispositivo")
        return False

    def _check_connection(self) -> bool:
        """Verifica se ADB está conectado."""
        result = run_command(["adb", "devices"])
        if result[0] != 0:
            return False

        for line in result[1].split("\n"):
            if "\tdevice" in line and (self.host in line or ":" in line.split("\t")[0]):
                self.device_serial = line.split("\t")[0]
                return True
        return False

    def disconnect(self) -> None:
        """Desconecta ADB."""
        if self.device_serial:
            run_command(["adb", "disconnect", self.device_serial], timeout=5)
        self._connected = False
        self.device_serial = None

    def _adb_shell(self, cmd: str, timeout: int = None) -> Tuple[int, str, str]:
        """Executa comando adb shell."""
        full_cmd = ["adb", "-s", self.device_serial, "shell"] + cmd.split()
        return run_command(full_cmd, timeout=timeout or self.timeout)

    def _adb_exec(self, cmd: List[str], timeout: int = None) -> Tuple[int, str, str]:
        """Executa comando adb direto."""
        full_cmd = ["adb", "-s", self.device_serial] + cmd
        return run_command(full_cmd, timeout=timeout or self.timeout)

    def _dump_ui(self, force: bool = False) -> Optional[ET.Element]:
        """Faz dump da UI atual via uiautomator."""
        import time
        now = time.time()

        # Cache por 500ms
        if not force and self._ui_cache and (now - self._ui_cache_time) < 0.5:
            return self._ui_cache

        result = self._adb_shell("uiautomator dump /dev/stdout", timeout=10)
        if result[0] != 0:
            logger.warning(f"uiautomator dump falhou: {result[2]}")
            return None

        try:
            root = ET.fromstring(result[1])
            self._ui_cache = root
            self._ui_cache_time = now
            return root
        except ET.ParseError as e:
            logger.warning(f"Erro parseando UI dump: {e}")
            return None

    def _find_element(self, xpath: str) -> Optional[Dict[str, Any]]:
        """Encontra elemento por XPath no dump UI."""
        root = self._dump_ui()
        if root is None:
            return None

        # uiautomator XML usa namespace
        ns = {"android": "http://schemas.android.com/apk/res/android"}

        # Busca por xpath simplificado (sem namespace)
        for elem in root.iter():
            # Verifica atributos relevantes
            resource_id = elem.get("resource-id") or elem.get("{http://schemas.android.com/apk/res/android}resource-id")
            content_desc = elem.get("content-desc") or elem.get("{http://schemas.android.com/apk/res/android}content-desc")
            text = elem.get("text") or elem.get("{http://schemas.android.com/apk/res/android}text")
            class_name = elem.get("class") or elem.get("{http://schemas.android.com/apk/res/android}class")
            bounds = elem.get("bounds") or elem.get("{http://schemas.android.com/apk/res/android}bounds")

            # Match simples (pode melhorar com XPath real)
            matched = False
            if xpath.startswith("//*[@resource-id="):
                target_id = xpath.split("'")[1] if "'" in xpath else xpath.split('"')[1]
                if resource_id and target_id in resource_id:
                    matched = True
            elif xpath.startswith("//*[@content-desc="):
                target_desc = xpath.split("'")[1] if "'" in xpath else xpath.split('"')[1]
                if content_desc and target_desc in content_desc:
                    matched = True
            elif xpath.startswith("//*[@text="):
                target_text = xpath.split("'")[1] if "'" in xpath else xpath.split('"')[1]
                if text and target_text in text:
                    matched = True

            if matched and bounds:
                # Parse bounds: [x1,y1][x2,y2]
                match = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", bounds)
                if match:
                    x1, y1, x2, y2 = map(int, match.groups())
                    return {
                        "bounds": (x1, y1, x2, y2),
                        "center": ((x1 + x2) // 2, (y1 + y2) // 2),
                        "resource_id": resource_id,
                        "content_desc": content_desc,
                        "text": text,
                        "class": class_name,
                    }

        return None

    def _tap(self, x: int, y: int) -> bool:
        """Toca na tela."""
        result = self._adb_shell(f"input tap {x} {y}")
        return result[0] == 0

    def _type_text(self, text: str) -> bool:
        """Digita texto (escapa caracteres especiais)."""
        # Escapa para shell
        escaped = text.replace(" ", "%s").replace("'", "\\'").replace('"', '\\"')
        # Adiciona outros escapes necessários
        escaped = escaped.replace("&", "\\&").replace("(", "\\(").replace(")", "\\)")
        result = self._adb_shell(f"input text '{escaped}'")
        return result[0] == 0

    def _swipe(self, x1: int, y1: int, x2: int, y2: int, duration: int = 300) -> bool:
        """Desliza na tela."""
        result = self._adb_shell(f"input swipe {x1} {y1} {x2} {y2} {duration}")
        return result[0] == 0

    def _wait(self, ms: int) -> None:
        """Aguarda ms milissegundos."""
        time.sleep(ms / 1000.0)

    # =========================================================================
    # AÇÕES DE ALTO NÍVEL
    # =========================================================================

    def execute_action(self, action: str, params: Dict[str, Any]) -> AutomationResult:
        """Dispatch de ações."""
        actions = {
            "abrir_app": self._abrir_app,
            "enviar_whatsapp": self._enviar_whatsapp,
            "ler_notificacoes": self._ler_notificacoes,
            "criar_alarme": self._criar_alarme,
            "tirar_foto": self._tirar_foto,
            "toast": self._toast,
            "vibrar": self._vibrar,
            "clipboard_get": self._clipboard_get,
            "clipboard_set": self._clipboard_set,
            "input_tap": self._input_tap,
            "input_text": self._input_text,
            "input_swipe": self._input_swipe,
            "am_start": self._am_start,
        }

        func = actions.get(action)
        if not func:
            return AutomationResult(success=False, message=f"Ação desconhecida: {action}")

        try:
            return func(params)
        except Exception as e:
            logger.error(f"Erro em {action}: {e}")
            return AutomationResult(success=False, message=f"Erro: {e}")

    def _abrir_app(self, params: Dict) -> AutomationResult:
        """Abre app por package/activity."""
        package = params.get("package")
        activity = params.get("activity")

        if not package:
            return AutomationResult(success=False, message="Package obrigatório")

        cmd = ["am", "start"]
        if activity:
            cmd.extend(["-n", f"{package}/{activity}"])
        else:
            cmd.extend(["-n", f"{package}/.MainActivity"])

        result = self._adb_exec(cmd)
        if result[0] != 0:
            return AutomationResult(success=False, message=f"Falha abrindo app: {result[2]}")

        self._wait(self.delays.get("open_app", 2000))
        return AutomationResult(success=True, message=f"App {package} aberto")

    def _enviar_whatsapp(self, params: Dict) -> AutomationResult:
        """
        Envia WhatsApp com VERIFICAÇÃO OBRIGATÓRIA.
        Fluxo completo: abrir → buscar → digitar → enviar → VERIFICAR bolha na tela.
        """
        contato = params.get("contato")
        mensagem = params.get("mensagem")
        verificar = params.get("verificar", True)

        if not contato or not mensagem:
            return AutomationResult(success=False, message="Contato e mensagem obrigatórios")

        logger.info(f"Enviando WhatsApp para '{contato}': {mensagem[:50]}...")

        # 1. Abre WhatsApp
        wa_config = self.config.get("whatsapp", {})
        package = wa_config.get("package", "com.whatsapp")
        activity = wa_config.get("activity", "com.whatsapp.Main")

        result = self._abrir_app({"package": package, "activity": activity})
        if not result.success:
            return result

        # 2. Busca contato
        search_selector = self.ui_selectors.get("search_box")
        search_elem = self._find_element(search_selector)
        if not search_elem:
            return AutomationResult(success=False, message="Não encontrou campo de busca do WhatsApp")

        self._tap(*search_elem["center"])
        self._wait(500)
        self._type_text(contato)
        self._wait(self.delays.get("search_contact", 1500))

        # 3. Seleciona primeiro resultado (tocando na área da lista)
        chat_list_selector = self.ui_selectors.get("chat_list")
        chat_elem = self._find_element(chat_list_selector)
        if chat_elem:
            # Toca no primeiro item da lista (ajuste Y para primeiro item)
            x, y = chat_elem["center"]
            self._tap(x, y + 100)  # Aproximação para primeiro item
        else:
            # Fallback: toca na área central superior da lista
            self._tap(540, 400)

        self._wait(self.delays.get("open_chat", 1000))

        # 4. Foca campo de mensagem
        input_selector = self.ui_selectors.get("message_input")
        input_elem = self._find_element(input_selector)
        if not input_elem:
            return AutomationResult(success=False, message="Não encontrou campo de mensagem")

        self._tap(*input_elem["center"])
        self._wait(self.delays.get("focus_input", 500))

        # 5. Digita mensagem
        self._type_text(mensagem)
        self._wait(self.delays.get("type_message", 1000))

        # 6. Envia
        send_selector = self.ui_selectors.get("send_button")
        send_elem = self._find_element(send_selector)
        if send_elem:
            self._tap(*send_elem["center"])
        else:
            # Fallback: Enter key
            self._adb_shell("input keyevent 66")

        self._wait(self.delays.get("tap_send", 500))

        # 7. VERIFICAÇÃO OBRIGATÓRIA - Confirma se mensagem apareceu na tela
        if verificar:
            self._wait(self.delays.get("verify_sent", 2000))
            if not self._verificar_mensagem_enviada(mensagem):
                return AutomationResult(
                    success=False,
                    message="Mensagem NÃO confirmada na tela (falha na verificação)",
                )

        return AutomationResult(success=True, message=f"WhatsApp enviado para {contato}")

    def _verificar_mensagem_enviada(self, mensagem: str) -> bool:
        """Verifica se a mensagem aparece na tela (bolha enviada)."""
        # Faz dump fresco
        root = self._dump_ui(force=True)
        if root is None:
            return False

        # Procura por texto da mensagem em bolhas
        msg_lower = mensagem.lower()
        for elem in root.iter():
            text = elem.get("text") or elem.get("{http://schemas.android.com/apk/res/android}text")
            resource_id = elem.get("resource-id") or elem.get("{http://schemas.android.com/apk/res/android}resource-id")

            # Verifica se é bolha de mensagem enviada (pode ter resource-id específico)
            if text and msg_lower in text.lower():
                # Verifica se é bolha "enviada" (geralmente tem cor/status diferente)
                # Simplificado: se achou o texto, assume que enviou
                logger.info(f"Verificação OK: encontrou '{text[:50]}...' na tela")
                return True

        logger.warning("Verificação falhou: mensagem não encontrada na tela")
        return False

    def _ler_notificacoes(self, params: Dict) -> AutomationResult:
        """Lê notificações via Termux:API (ADB não tem acesso direto)."""
        # ADB não lê notificações facilmente sem root
        # Delega para Termux:API via shell
        result = run_command(["termux-notification-list"], timeout=10)
        if result[0] != 0:
            return AutomationResult(success=False, message="termux-notification-list falhou")

        try:
            import json
            notifications = json.loads(result[1])
            limite = params.get("limite", 10)
            notifications = notifications[:limite]

            texts = []
            for n in notifications:
                title = n.get("title", "")
                content = n.get("content", "")
                if title or content:
                    texts.append(f"{title}: {content}")

            return AutomationResult(
                success=True,
                message=f"{len(texts)} notificação(ões)",
                data={"notifications": texts},
            )
        except json.JSONDecodeError:
            return AutomationResult(success=False, message="Erro parseando notificações")

    def _criar_alarme(self, params: Dict) -> AutomationResult:
        """Cria alarme via Termux:API."""
        hora = params.get("hora")
        if not hora:
            return AutomationResult(success=False, message="Hora obrigatória (HH:MM)")

        # Converte HH:MM para timestamp
        try:
            h, m = map(int, hora.split(":"))
        except ValueError:
            return AutomationResult(success=False, message="Formato de hora inválido (HH:MM)")

        # Calcula timestamp em ms desde epoch
        import datetime
        now = datetime.datetime.now()
        alarm_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
        if alarm_time <= now:
            alarm_time += datetime.timedelta(days=1)

        timestamp_ms = int(alarm_time.timestamp() * 1000)

        cmd = ["termux-alarm", "--time", str(timestamp_ms)]

        dias = params.get("dias", [])
        if dias:
            # Termux:API não suporta repetição nativamente
            # Precisa de workaround com Tasker ou alarme repetido manual
            pass

        msg = params.get("mensagem", "Alarme ORÁCULO")
        cmd.extend(["--title", msg])

        result = run_command(cmd, timeout=10)
        if result[0] != 0:
            return AutomationResult(success=False, message=f"Falha criando alarme: {result[2]}")

        return AutomationResult(success=True, message=f"Alarme criado para {hora}")

    def _tirar_foto(self, params: Dict) -> AutomationResult:
        """Tira foto via Termux:API."""
        camera = params.get("camera", 0)
        result = run_command(["termux-camera-photo", "-c", str(camera), "/sdcard/oraculo_foto.jpg"], timeout=15)
        if result[0] != 0:
            return AutomationResult(success=False, message=f"Falha tirando foto: {result[2]}")

        return AutomationResult(
            success=True,
            message="Foto tirada",
            data={"path": "/sdcard/oraculo_foto.jpg"},
        )

    def _toast(self, params: Dict) -> AutomationResult:
        """Mostra toast."""
        msg = params.get("mensagem", "")
        duracao = params.get("duracao", "short")
        result = run_command(["termux-toast", "-g", duracao, msg], timeout=5)
        return AutomationResult(success=result[0]==0, message="Toast exibido" if result[0]==0 else result[2])

    def _vibrar(self, params: Dict) -> AutomationResult:
        """Vibra."""
        padrao = params.get("padrao", [100])
        pattern_str = ",".join(map(str, padrao))
        result = run_command(["termux-vibrate", "-f", "-p", pattern_str], timeout=5)
        return AutomationResult(success=result[0]==0, message="Vibrou" if result[0]==0 else result[2])

    def _clipboard_get(self, params: Dict) -> AutomationResult:
        """Lê clipboard."""
        result = run_command(["termux-clipboard-get"], timeout=5)
        return AutomationResult(success=result[0]==0, message=result[1].strip(), data={"text": result[1].strip()})

    def _clipboard_set(self, params: Dict) -> AutomationResult:
        """Define clipboard."""
        texto = params.get("texto", "")
        result = run_command(["termux-clipboard-set", texto], timeout=5)
        return AutomationResult(success=result[0]==0, message="Copiado" if result[0]==0 else result[2])

    def _input_tap(self, params: Dict) -> AutomationResult:
        """input tap direto."""
        x = params.get("x")
        y = params.get("y")
        if x is None or y is None:
            return AutomationResult(success=False, message="x e y obrigatórios")
        ok = self._tap(x, y)
        return AutomationResult(success=ok, message=f"Tap em ({x},{y})" if ok else "Falha no tap")

    def _input_text(self, params: Dict) -> AutomationResult:
        """input text direto."""
        text = params.get("text", "")
        ok = self._type_text(text)
        return AutomationResult(success=ok, message="Texto digitado" if ok else "Falha digitando")

    def _input_swipe(self, params: Dict) -> AutomationResult:
        """input swipe direto."""
        x1 = params.get("x1")
        y1 = params.get("y1")
        x2 = params.get("x2")
        y2 = params.get("y2")
        duration = params.get("duration", 300)
        if None in (x1, y1, x2, y2):
            return AutomationResult(success=False, message="x1,y1,x2,y2 obrigatórios")
        ok = self._swipe(x1, y1, x2, y2, duration)
        return AutomationResult(success=ok, message="Swipe ok" if ok else "Falha no swipe")

    def _am_start(self, params: Dict) -> AutomationResult:
        """am start direto."""
        intent = params.get("intent", "")
        if not intent:
            return AutomationResult(success=False, message="intent obrigatório")
        result = self._adb_shell(f"am start {intent}")
        return AutomationResult(success=result[0]==0, message=result[1] if result[0]==0 else result[2])


# Registra backend
register_backend("adb", ADBAutomation)