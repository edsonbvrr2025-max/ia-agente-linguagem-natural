"""
Memória vetorial (RAG local) via sqlite-vec + embeddings ONNX.

Requer:
- pip install sqlite-vec onnxruntime
- Modelo de embedding ONNX (ex: all-MiniLM-L6-v2.onnx ~90 MB)

Funciona como índice semântico sobre os fatos da memória file-based.
"""

import sqlite3
import json
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional

from oraculo.memory import MemoryBackend, MemoryFact, register_backend
from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import ensure_dir, run_command

logger = get_logger(__name__)


class VectorMemory(MemoryBackend):
    """Backend de memória com busca vetorial (sqlite-vec)."""

    def __init__(
        self,
        db_path: Path = Path("memory/vectors.db"),
        embedding_model: Path = Path("models/embeddings/all-MiniLM-L6-v2.onnx"),
        file_memory=None,  # Referência ao FileMemory para sync
    ):
        self.db_path = db_path
        self.embedding_model_path = embedding_model
        self.file_memory = file_memory
        self.conn = None
        self.ort_session = None
        self._loaded = False
        self._dim = 384  # all-MiniLM-L6-v2 dimension

    def load(self) -> bool:
        """Inicializa banco e modelo de embedding."""
        try:
            # SQLite com sqlite-vec
            self.conn = sqlite3.connect(str(self.db_path))
            self.conn.enable_load_extension(True)

            # Tenta carregar sqlite-vec
            try:
                self.conn.load_extension("sqlite_vec")
            except Exception:
                # Tenta caminhos comuns no Termux
                vec_paths = [
                    "/data/data/com.termux/files/usr/lib/sqlite3/vec0.so",
                    "/data/data/com.termux/files/usr/lib/sqlite-vec.so",
                    "vec0",
                ]
                loaded = False
                for vec_path in vec_paths:
                    try:
                        self.conn.load_extension(vec_path)
                        loaded = True
                        break
                    except Exception:
                        continue
                if not loaded:
                    logger.error("sqlite-vec extension não encontrada. Instale: pip install sqlite-vec")
                    return False

            # Cria tabela virtual vetorial
            self.conn.execute(f"""
                CREATE VIRTUAL TABLE IF NOT EXISTS memory_vec USING vec0(
                    embedding float[{self._dim}]
                )
            """)

            # Tabela de metadados
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS memory_meta (
                    rowid INTEGER PRIMARY KEY,
                    secao TEXT,
                    chave TEXT,
                    valor TEXT,
                    contexto TEXT,
                    timestamp TEXT
                )
            """)

            # Índice para busca por texto
            self.conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_memory_meta_secao ON memory_meta(secao)
            """)

            self.conn.commit()

            # Carrega modelo ONNX
            self._load_embedding_model()

            self._loaded = True
            logger.info(f"VectorMemory carregado: {self.db_path}")
            return True

        except Exception as e:
            logger.error(f"Erro inicializando VectorMemory: {e}")
            return False

    def _load_embedding_model(self) -> bool:
        """Carrega modelo de embedding ONNX."""
        try:
            import onnxruntime as ort
        except ImportError:
            logger.error("onnxruntime não instalado: pip install onnxruntime")
            return False

        if not self.embedding_model_path.exists():
            logger.error(f"Modelo embedding não encontrado: {self.embedding_model_path}")
            logger.info("Baixe: https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/onnx/model.onnx")
            return False

        try:
            self.ort_session = ort.InferenceSession(
                str(self.embedding_model_path),
                providers=["CPUExecutionProvider"],
            )
            logger.info(f"Modelo embedding carregado: {self.embedding_model_path}")
            return True
        except Exception as e:
            logger.error(f"Erro carregando modelo ONNX: {e}")
            return False

    def _embed(self, text: str) -> Optional[np.ndarray]:
        """Gera embedding para texto."""
        if not self.ort_session:
            return None

        try:
            # Tokenização simples (character-level para MiniLM)
            # Na prática, usar tokenizer do transformers, mas para evitar dependência:
            # Usa média de char embeddings como aproximação grosseira
            # TODO: Implementar tokenizer correto

            # Placeholder: retorna vetor aleatório normalizado para teste
            # SUBSTITUIR por tokenização real + inferência ONNX
            vec = np.random.randn(self._dim).astype(np.float32)
            vec = vec / np.linalg.norm(vec)
            return vec

        except Exception as e:
            logger.error(f"Erro gerando embedding: {e}")
            return None

    def _embed_batch(self, texts: List[str]) -> List[Optional[np.ndarray]]:
        """Gera embeddings para lista de textos."""
        return [self._embed(t) for t in texts]

    def adicionar(self, secao: str, chave: str, valor: str, contexto: str = "") -> bool:
        """Adiciona fato ao índice vetorial."""
        if not self._loaded:
            if not self.load():
                return False

        # Texto para embedding
        text = f"{secao} {chave} {valor} {contexto}"
        embedding = self._embed(text)

        if embedding is None:
            logger.warning("Não gerou embedding, pulando índice vetorial")
            return True  # Não falha, só não indexa

        try:
            cursor = self.conn.cursor()

            # Insere metadados
            cursor.execute("""
                INSERT INTO memory_meta (secao, chave, valor, contexto, timestamp)
                VALUES (?, ?, ?, ?, datetime('now'))
            """, (secao, chave, valor, contexto))

            rowid = cursor.lastrowid

            # Insere vetor (sqlite-vec usa rowid correspondente)
            # Formato: INSERT INTO memory_vec(rowid, embedding) VALUES (?, ?)
            embedding_bytes = embedding.tobytes()
            cursor.execute("INSERT INTO memory_vec(rowid, embedding) VALUES (?, ?)", (rowid, embedding_bytes))

            self.conn.commit()
            return True

        except Exception as e:
            logger.error(f"Erro adicionando ao índice vetorial: {e}")
            return False

    def remover(self, secao: str, chave: str) -> bool:
        """Remove fato do índice vetorial."""
        if not self._loaded:
            if not self.load():
                return False

        try:
            cursor = self.conn.cursor()

            # Encontra rowid
            cursor.execute(
                "SELECT rowid FROM memory_meta WHERE secao = ? AND chave = ?",
                (secao, chave)
            )
            rows = cursor.fetchall()

            for (rowid,) in rows:
                # Remove do índice vetorial
                cursor.execute("DELETE FROM memory_vec WHERE rowid = ?", (rowid,))
                # Remove metadados
                cursor.execute("DELETE FROM memory_meta WHERE rowid = ?", (rowid,))

            self.conn.commit()
            return len(rows) > 0

        except Exception as e:
            logger.error(f"Erro removendo do índice vetorial: {e}")
            return False

    def buscar(self, query: str, secao: str = "Todas", top_k: int = 5) -> List[MemoryFact]:
        """Busca semântica por similaridade de embedding."""
        if not self._loaded:
            if not self.load():
                return []

        query_embedding = self._embed(query)
        if query_embedding is None:
            # Fallback: busca textual no file_memory
            if self.file_memory:
                return self.file_memory.buscar(query, secao, top_k)
            return []

        try:
            query_bytes = query_embedding.tobytes()

            # Busca vetorial no sqlite-vec
            sql = """
                SELECT m.secao, m.chave, m.valor, m.contexto, m.timestamp,
                       vec_distance_cosine(mv.embedding, ?) as distance
                FROM memory_meta m
                JOIN memory_vec mv ON m.rowid = mv.rowid
            """
            params = [query_bytes]

            if secao != "Todas":
                sql += " WHERE m.secao = ?"
                params.append(secao)

            sql += " ORDER BY distance ASC LIMIT ?"
            params.append(top_k)

            cursor = self.conn.cursor()
            cursor.execute(sql, params)

            results = []
            for row in cursor.fetchall():
                secao, chave, valor, contexto, timestamp, distance = row
                # Converte distance (0=igual, 2=oposto) para similarity
                similarity = 1 - (distance / 2)
                results.append(MemoryFact(
                    secao=secao,
                    chave=chave,
                    valor=valor,
                    contexto=contexto,
                    timestamp=timestamp,
                ))

            return results

        except Exception as e:
            logger.error(f"Erro na busca vetorial: {e}")
            # Fallback
            if self.file_memory:
                return self.file_memory.buscar(query, secao, top_k)
            return []

    def listar(self, secao: str = "Todas") -> List[MemoryFact]:
        """Lista fatos (delega para file_memory)."""
        if self.file_memory:
            return self.file_memory.listar(secao)
        return []

    def carregar_tudo(self) -> Dict[str, List[MemoryFact]]:
        """Retorna tudo (delega para file_memory)."""
        if self.file_memory:
            return self.file_memory.carregar_tudo()
        return {}

    def sync_from_file_memory(self) -> int:
        """Sincroniza índice vetorial a partir do FileMemory."""
        if not self.file_memory:
            return 0

        if not self._loaded:
            self.load()

        all_facts = self.file_memory.carregar_tudo()
        count = 0

        for secao, facts in all_facts.items():
            for fact in facts:
                # Verifica se já existe
                cursor = self.conn.cursor()
                cursor.execute(
                    "SELECT 1 FROM memory_meta WHERE secao = ? AND chave = ?",
                    (secao, fact.chave)
                )
                if cursor.fetchone():
                    continue  # Já indexado

                # Adiciona
                if self.adicionar(secao, fact.chave, fact.valor, fact.contexto):
                    count += 1

        logger.info(f"Sincronizados {count} fatos do FileMemory para VectorMemory")
        return count

    def unload(self) -> None:
        if self.conn:
            self.conn.close()
            self.conn = None
        self.ort_session = None
        self._loaded = False


# Registra backend
register_backend("vector", VectorMemory)