"""
Utilidades do ORÁCULO.
"""

from oraculo.utils.logger import setup_logging, get_logger, LoggingContext
from oraculo.utils.helpers import (
    run_command,
    run_command_simple,
    check_command_exists,
    get_system_info,
    print_system_info,
    SystemInfo,
    format_bytes,
    parse_json_safe,
    extract_json,
    sanitize_filename,
    ensure_dir,
    read_text_safe,
    write_text_safe,
    get_termux_api_endpoints,
    is_termux_api_installed,
    human_duration,
)
from oraculo.utils.audio import (
    check_audio_tools,
    record_audio,
    record_audio_vad,
    play_audio,
    stop_audio,
    convert_audio,
    get_audio_duration,
    create_silence,
    AudioConfig,
    DEFAULT_AUDIO_CONFIG,
)

__all__ = [
    # Logger
    "setup_logging",
    "get_logger",
    "LoggingContext",
    # Helpers
    "run_command",
    "run_command_simple",
    "check_command_exists",
    "get_system_info",
    "print_system_info",
    "SystemInfo",
    "format_bytes",
    "parse_json_safe",
    "extract_json",
    "sanitize_filename",
    "ensure_dir",
    "read_text_safe",
    "write_text_safe",
    "get_termux_api_endpoints",
    "is_termux_api_installed",
    "human_duration",
    # Audio
    "check_audio_tools",
    "record_audio",
    "record_audio_vad",
    "play_audio",
    "stop_audio",
    "convert_audio",
    "get_audio_duration",
    "create_silence",
    "AudioConfig",
    "DEFAULT_AUDIO_CONFIG",
]