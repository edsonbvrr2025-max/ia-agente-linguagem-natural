"""
Utilidades diversas para ORÁCULO.
"""

import subprocess
import shutil
import os
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class SystemInfo:
    """Informações do sistema Android/Termux."""
    android_version: str
    api_level: int
    device_model: str
    device_brand: str
    abi: str
    ram_total_mb: int
    ram_available_mb: int
    storage_free_gb: float
    cpu_cores: int
    cpu_arch: str
    termux_version: str
    termux_prefix: str
    has_root: bool
    is_android_12_plus: bool


def run_command(cmd: List[str], timeout: int = 30, capture: bool = True) -> Tuple[int, str, str]:
    """
    Executa comando e retorna (exit_code, stdout, stderr).

    Args:
        cmd: Lista de argumentos do comando
        timeout: Timeout em segundos
        capture: Se True, captura stdout/stderr

    Returns:
        Tupla (exit_code, stdout, stderr)
    """
    try:
        result = subprocess.run(
            cmd,
            capture_output=capture,
            text=True,
            timeout=timeout,
            check=False,
        )
        return result.returncode, result.stdout or "", result.stderr or ""
    except subprocess.TimeoutExpired:
        return -1, "", f"Timeout após {timeout}s"
    except FileNotFoundError:
        return -1, "", f"Comando não encontrado: {cmd[0]}"
    except Exception as e:
        return -1, "", str(e)


def run_command_simple(cmd: str, timeout: int = 30) -> str:
    """Executa comando simples e retorna stdout (strip)."""
    code, out, err = run_command(cmd.split(), timeout=timeout)
    if code != 0:
        raise RuntimeError(f"Comando falhou ({code}): {err}")
    return out.strip()


def check_command_exists(cmd: str) -> bool:
    """Verifica se comando existe no PATH."""
    return shutil.which(cmd) is not None


def get_system_info() -> SystemInfo:
    """Coleta informações completas do sistema."""
    # Android version
    android_version = run_command_simple("getprop ro.build.version.release")
    api_level = int(run_command_simple("getprop ro.build.version.sdk"))

    # Device info
    device_model = run_command_simple("getprop ro.product.model")
    device_brand = run_command_simple("getprop ro.product.brand")
    abi = run_command_simple("getprop ro.product.cpu.abi")

    # RAM
    with open("/proc/meminfo", "r") as f:
        meminfo = f.read()
    ram_total_kb = int(re.search(r"MemTotal:\s+(\d+)", meminfo).group(1))
    ram_available_kb = int(re.search(r"MemAvailable:\s+(\d+)", meminfo).group(1))
    ram_total_mb = ram_total_kb // 1024
    ram_available_mb = ram_available_kb // 1024

    # Storage
    stat = shutil.disk_usage("/data")
    storage_free_gb = stat.free / (1024 ** 3)

    # CPU
    with open("/proc/cpuinfo", "r") as f:
        cpuinfo = f.read()
    cpu_cores = len(re.findall(r"^processor\s+:", cpuinfo, re.MULTILINE))
    cpu_arch_match = re.search(r"^CPU architecture:\s+(\d+)", cpuinfo, re.MULTILINE)
    cpu_arch = cpu_arch_match.group(1) if cpu_arch_match else "unknown"

    # Termux
    termux_version = run_command_simple("pkg show termux 2>/dev/null | grep Version | head -1 | awk '{print $2}'")
    if not termux_version:
        termux_version = "unknown"
    termux_prefix = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")

    # Root check
    has_root = check_command_exists("su") and run_command(["su", "-c", "id"])[0] == 0

    return SystemInfo(
        android_version=android_version,
        api_level=api_level,
        device_model=device_model,
        device_brand=device_brand,
        abi=abi,
        ram_total_mb=ram_total_mb,
        ram_available_mb=ram_available_mb,
        storage_free_gb=storage_free_gb,
        cpu_cores=cpu_cores,
        cpu_arch=cpu_arch,
        termux_version=termux_version,
        termux_prefix=termux_prefix,
        has_root=has_root,
        is_android_12_plus=api_level >= 31,
    )


def print_system_info(info: SystemInfo) -> None:
    """Imprime informações do sistema formatadas."""
    print(f"\n{'='*50}")
    print(f"  ORÁCULO — Diagnóstico do Sistema")
    print(f"{'='*50}")
    print(f"  Dispositivo:     {info.device_brand} {info.device_model}")
    print(f"  Android:         {info.android_version} (API {info.api_level})")
    print(f"  ABI:             {info.abi}")
    print(f"  RAM Total:       {info.ram_total_mb} MB")
    print(f"  RAM Livre:       {info.ram_available_mb} MB")
    print(f"  Armazenamento:   {info.storage_free_gb:.1f} GB livres")
    print(f"  CPU:             {info.cpu_cores} cores, Arch {info.cpu_arch}")
    print(f"  Termux:          {info.termux_version} @ {info.termux_prefix}")
    print(f"  Root:            {'Sim' if info.has_root else 'Não'}")
    print(f"  Android 12+:     {'Sim' if info.is_android_12_plus else 'Não'}")
    print(f"{'='*50}\n")


def format_bytes(bytes_val: int) -> str:
    """Formata bytes em string legível."""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if bytes_val < 1024:
            return f"{bytes_val:.1f} {unit}"
        bytes_val /= 1024
    return f"{bytes_val:.1f} PB"


def parse_json_safe(text: str, default: Any = None) -> Any:
    """Tenta parsear JSON, retorna default se falhar."""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return default


def extract_json(text: str) -> Optional[Dict]:
    """Extrai primeiro objeto JSON válido de um texto."""
    # Procura por { ... } balanceado
    brace_count = 0
    start = -1
    for i, char in enumerate(text):
        if char == "{":
            if brace_count == 0:
                start = i
            brace_count += 1
        elif char == "}":
            if brace_count > 0:
                brace_count -= 1
                if brace_count == 0 and start != -1:
                    candidate = text[start:i+1]
                    parsed = parse_json_safe(candidate)
                    if parsed is not None:
                        return parsed
    return None


def sanitize_filename(name: str) -> str:
    """Remove caracteres inválidos de nome de arquivo."""
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)


def ensure_dir(path: Path) -> Path:
    """Garante que diretório existe."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_text_safe(path: Path, default: str = "") -> str:
    """Lê arquivo texto, retorna default se não existir."""
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return default
    except Exception:
        return default


def write_text_safe(path: Path, content: str) -> bool:
    """Escreve arquivo texto, cria diretórios se necessário."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return True
    except Exception:
        return False


def get_termux_api_endpoints() -> List[str]:
    """Lista endpoints Termux:API disponíveis."""
    endpoints = [
        "termux-notification",
        "termux-toast",
        "termux-vibrate",
        "termux-clipboard-get",
        "termux-clipboard-set",
        "termux-contact-list",
        "termux-sms-list",
        "termux-sms-send",
        "termux-telephony-call",
        "termux-camera-photo",
        "termux-microphone-record",
        "termux-media-player",
        "termux-wake-lock",
        "termux-wake-unlock",
        "termux-battery-status",
        "termux-wifi-scaninfo",
        "termux-location",
    ]
    return [ep for ep in endpoints if check_command_exists(ep)]


def is_termux_api_installed() -> bool:
    """Verifica se Termux:API está instalado e funcionando."""
    return check_command_exists("termux-api") or len(get_termux_api_endpoints()) > 0


def human_duration(seconds: float) -> str:
    """Formata duração em string legível."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{seconds/60:.1f}min"
    else:
        return f"{seconds/3600:.1f}h"