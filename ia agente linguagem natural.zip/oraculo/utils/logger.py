"""
Logging colorido e configurável para ORÁCULO.
"""

import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler
from typing import Optional
from rich.logging import RichHandler
from rich.console import Console

from oraculo.config import get_config, LoggingConfig


# Cores ANSI para fallback sem rich
class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    GRAY = "\033[90m"

    # Níveis
    DEBUG = CYAN
    INFO = GREEN
    WARNING = YELLOW
    ERROR = RED
    CRITICAL = BOLD + RED


class ColoredFormatter(logging.Formatter):
    """Formatter com cores ANSI."""

    LEVEL_COLORS = {
        logging.DEBUG: Colors.DEBUG,
        logging.INFO: Colors.INFO,
        logging.WARNING: Colors.WARNING,
        logging.ERROR: Colors.ERROR,
        logging.CRITICAL: Colors.CRITICAL,
    }

    def format(self, record: logging.LogRecord) -> str:
        color = self.LEVEL_COLORS.get(record.levelno, Colors.RESET)
        levelname = f"{color}{record.levelname}{Colors.RESET}"
        message = super().format(record)
        return message.replace(record.levelname, levelname, 1)


def setup_logging(config: Optional[LoggingConfig] = None) -> logging.Logger:
    """
    Configura logging global.

    Args:
        config: Configuração de logging (usa get_config() se None)

    Returns:
        Logger raiz configurado
    """
    if config is None:
        config = get_config().logging

    # Logger raiz
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, config.level.upper(), logging.INFO))

    # Limpa handlers existentes
    root_logger.handlers.clear()

    # Console handler com Rich (colorido, bonito)
    if config.console_colors:
        console = Console(stderr=True, force_terminal=True)
        console_handler = RichHandler(
            console=console,
            show_time=True,
            show_level=True,
            show_path=False,
            markup=True,
            rich_tracebacks=True,
            tracebacks_show_locals=False,
        )
        console_handler.setLevel(getattr(logging, config.level.upper(), logging.INFO))
        root_logger.addHandler(console_handler)
    else:
        # Fallback: handler simples com cores ANSI
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(getattr(logging, config.level.upper(), logging.INFO))
        console_format = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
        console_handler.setFormatter(ColoredFormatter(console_format, datefmt="%H:%M:%S"))
        root_logger.addHandler(console_handler)

    # File handler com rotação
    log_file = Path(config.file)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=config.max_size_mb * 1024 * 1024,
        backupCount=config.backup_count,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)  # Arquivo pega tudo
    file_format = "%(asctime)s | %(levelname)-8s | %(name)s | %(funcName)s:%(lineno)d | %(message)s"
    file_handler.setFormatter(logging.Formatter(file_format, datefmt="%Y-%m-%d %H:%M:%S"))
    root_logger.addHandler(file_handler)

    # Reduz verbosidade de libs terceiras
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("llama_cpp").setLevel(logging.WARNING)

    return root_logger


def get_logger(name: str) -> logging.Logger:
    """Retorna logger nomeado."""
    return logging.getLogger(name)


# Context manager para logging temporário
class LoggingContext:
    """Context manager para alterar nível de log temporariamente."""

    def __init__(self, logger: logging.Logger, level: int):
        self.logger = logger
        self.new_level = level
        self.old_level = logger.level

    def __enter__(self):
        self.logger.setLevel(self.new_level)
        return self

    def __exit__(self, *args):
        self.logger.setLevel(self.old_level)