"""
Loop principal do ORÁCULO — Orquestra STT → LLM → Tools → TTS → Automação.
"""

import json
import time
import signal
import threading
from pathlib import Path
from typing import Optional, Dict, Any, List

from oraculo.config import get_config
from oraculo.utils.logger import get_logger, setup_logging
from oraculo.utils.helpers import check_command_exists
from oraculo.orchestrator.state import ConversationState, Message, MessageRole
from oraculo.orchestrator.wakelock import get_wakelock_manager

logger = get_logger(__name__)


class Orchestrator:
    """
    Orquestrador principal do agente ORÁCULO.

    Fluxo:
    1. STT: Ouve áudio → texto
    2. LLM: Processa texto + histórico + memória + ferramentas → decide ação
    3. TOOLS: Executa ferramenta (memória, automação, sistema)
    4. TTS: Sintetiza resposta em áudio
    5. PLAY: Toca áudio
    6. Loop
    """

    def __init__(self, config_path: str = "config.yaml"):
        self.config = get_config(config_path)
        self.state = ConversationState(max_history_pairs=self.config.orchestrator.max_history)
        self.wakelock = get_wakelock_manager()
        self._running = False
        self._shutdown = False
        self._components = {}

        # Inicializa componentes lazy
        self._stt = None
        self._llm = None
        self._tts = None
        self._automation = None
        self._memory_tools = None

    def initialize(self) -> bool:
        """Inicializa todos os componentes."""
        logger.info("Inicializando ORÁCULO...")

        # Setup logging
        setup_logging(self.config.logging)

        # Wakelock
        if self.config.orchestrator.wakelock:
            self.wakelock.acquire()
            self.wakelock.start_monitor()

        # Notificação foreground (Android 12+)
        if self.config.orchestrator.foreground_notification:
            self._show_foreground_notification()

        # Inicializa componentes
        if not self._init_stt():
            return False
        if not self._init_llm():
            return False
        if not self._init_tts():
            return False
        if not self._init_automation():
            return False
        if not self._init_memory():
            return False

        logger.info("✅ ORÁCULO inicializado com sucesso")
        return True

    def _init_stt(self) -> bool:
        from oraculo.stt import create_stt
        stt_config = self.config.stt
        model_path = Path(stt_config.model)
        self._stt = create_stt(stt_config.engine, model_path, stt_config.__dict__)
        if not self._stt or not self._stt.load():
            logger.error(f"Falha inicializando STT: {stt_config.engine}")
            return False
        logger.info(f"STT pronto: {stt_config.engine}")
        return True

    def _init_llm(self) -> bool:
        from oraculo.llm import create_llm
        llm_config = self.config.llm
        model_path = Path(llm_config.model)
        self._llm = create_llm(llm_config.engine, model_path, llm_config.__dict__)
        if not self._llm or not self._llm.load():
            logger.error(f"Falha inicializando LLM: {llm_config.engine}")
            return False
        logger.info(f"LLM pronto: {llm_config.engine}")
        return True

    def _init_tts(self) -> bool:
        from oraculo.tts import create_tts
        tts_config = self.config.tts
        model_path = Path(tts_config.model)
        self._tts = create_tts(tts_config.engine, model_path, tts_config.__dict__)
        if not self._tts or not self._tts.load():
            logger.error(f"Falha inicializando TTS: {tts_config.engine}")
            return False
        logger.info(f"TTS pronto: {tts_config.engine}")
        return True

    def _init_automation(self) -> bool:
        from oraculo.automation import create_automation
        auto_config = self.config.automation
        self._automation = create_automation(auto_config.method, auto_config.__dict__)
        if not self._automation or not self._automation.connect():
            logger.warning(f"Automação {auto_config.method} não conectou (algumas funções não funcionarão)")
            # Não falha — pode operar sem automação
        else:
            logger.info(f"Automação pronta: {auto_config.method}")
        return True

    def _init_memory(self) -> bool:
        from oraculo.memory.tools import get_memory_tools
        self._memory_tools = get_memory_tools()
        logger.info("Memória pronta")
        return True

    def _show_foreground_notification(self) -> None:
        """Mostra notificação foreground para manter processo vivo."""
        try:
            from oraculo.utils.helpers import run_command
            title = self.config.orchestrator.notification_title
            text = self.config.orchestrator.notification_text
            run_command([
                "termux-notification",
                "--title", title,
                "--content", text,
                "--ongoing", "true",
                "--id", "oraculo_foreground",
            ], timeout=5)
        except Exception as e:
            logger.warning(f"Não conseguiu mostrar notificação foreground: {e}")

    def _hide_foreground_notification(self) -> None:
        try:
            from oraculo.utils.helpers import run_command
            run_command(["termux-notification", "--remove", "oraculo_foreground"], timeout=5)
        except Exception:
            pass

    # =========================================================================
    # LOOP PRINCIPAL
    # =========================================================================

    def run(self, continuous: bool = None) -> None:
        """
        Executa loop principal.

        Args:
            continuous: Se True, mantém loop contínuo. None = usa config.
        """
        if continuous is None:
            continuous = self.config.orchestrator.continuous

        self._running = True
        self._shutdown = False

        # Handler para sinais
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        logger.info("🎙️ ORÁCULO ouvindo... (Ctrl+C para parar)")

        try:
            if continuous:
                self._run_continuous()
            else:
                self._run_single()
        finally:
            self.shutdown()

    def _run_continuous(self) -> None:
        """Loop contínuo com wake word opcional."""
        wake_word = self.config.orchestrator.wake_word

        while self._running and not self._shutdown:
            try:
                if wake_word:
                    # Modo wake word: escuta continuamente por palavra de ativação
                    logger.debug(f"Aguardando wake word: '{wake_word}'")
                    text = self._listen_for_wake_word(wake_word)
                    if not text:
                        continue
                else:
                    # Modo ativação manual: uma gravação por iteração
                    logger.debug("Aguardando comando...")
                    text = self._listen_once()
                    if not text:
                        continue

                # Processa comando
                self._process_command(text)

            except KeyboardInterrupt:
                break
            except Exception as e:
                logger.error(f"Erro no loop: {e}")
                time.sleep(1)

    def _run_single(self) -> None:
        """Executa uma única iteração (comando único)."""
        text = self._listen_once()
        if text:
            self._process_command(text)

    def _listen_for_wake_word(self, wake_word: str) -> Optional[str]:
        """Escuta por wake word (implemente conforme STT)."""
        # Para wake word real, precisaria de VAD + streaming STT
        # Simplificado: grava áudio curto e verifica se contém wake word
        from oraculo.utils.audio import record_audio
        import tempfile

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            temp_path = Path(f.name)

        try:
            # Grava 3 segundos
            if not record_audio(temp_path, duration=3):
                return None

            result = self._stt.transcribe(temp_path)
            if result.text and wake_word.lower() in result.text.lower():
                # Remove wake word do texto
                text = result.text.lower().replace(wake_word.lower(), "").strip()
                return text if text else None
        finally:
            temp_path.unlink(missing_ok=True)

        return None

    def _listen_once(self) -> Optional[str]:
        """Grava um comando único com VAD."""
        from oraculo.utils.audio import record_audio_vad
        import tempfile

        stt_config = self.config.stt

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            temp_path = Path(f.name)

        try:
            logger.debug("🎤 Gravando...")
            if not record_audio_vad(
                temp_path,
                silence_threshold=stt_config.silence_threshold,
                silence_duration=stt_config.silence_duration,
                max_duration=stt_config.get("max_duration", 30),
            ):
                return None

            logger.debug("🔄 Transcrevendo...")
            result = self._stt.transcribe(temp_path)

            if result.text:
                logger.info(f"👂 Ouvido: {result.text}")
                return result.text
            else:
                logger.debug("Nenhuma fala detectada")
                return None

        except Exception as e:
            logger.error(f"Erro na escuta: {e}")
            return None
        finally:
            temp_path.unlink(missing_ok=True)

    def _process_command(self, text: str) -> None:
        """Processa comando de texto completo: LLM → Tool → TTS."""
        logger.info(f"🧠 Processando: {text}")

        # Adiciona ao histórico
        self.state.add_user_message(text)

        # Constrói prompt com memória e histórico
        prompt = self._build_prompt(text)

        # Chama LLM
        from oraculo.llm.tools import get_tools_for_llm
        tools = get_tools_for_llm(["memoria", "automacao", "sistema"])

        llm_response = self._llm.generate(
            prompt=prompt,
            tools=tools,
            tool_choice="auto",
            max_tokens=512,
            temperature=self.config.llm.temperature,
        )

        # Processa resposta
        self._handle_llm_response(llm_response, text)

    def _build_prompt(self, user_text: str) -> str:
        """Constrói prompt completo para o LLM."""
        from oraculo.llm.prompts import build_system_prompt
        from oraculo.memory.tools import get_memory_tools

        memory_tools = get_memory_tools()
        memory_content = memory_tools.file_memory.get_formatted_memory()
        profile_content = memory_tools.file_memory.get_profile()

        system_prompt = build_system_prompt(
            tools=get_tools_for_llm(["memoria", "automacao", "sistema"]),
            memory_content=memory_content,
            profile_content=profile_content,
        )

        # Adiciona histórico recente
        history = self.state.get_history_for_llm()
        history_str = ""
        if history:
            history_str = "\n".join([f"{'Usuário' if m['role']=='user' else 'ORÁCULO'}: {m['content']}" for m in history])
            history_str = f"\n=== HISTÓRICO RECENTE ===\n{history_str}\n"

        prompt = f"{system_prompt}{history_str}\nUsuário: {user_text}\nORÁCULO:"
        return prompt

    def _handle_llm_response(self, llm_response, original_text: str) -> None:
        """Processa resposta do LLM: executa tools, sintetiza fala."""
        # Adiciona resposta do assistant ao histórico
        assistant_msg = self.state.add_assistant_message(
            llm_response.text,
            tool_calls=llm_response.tool_calls,
        )

        # Executa tool calls se houver
        tool_results = []
        if llm_response.tool_calls:
            for tool_call in llm_response.tool_calls:
                result = self._execute_tool(tool_call)
                tool_results.append(result)

                # Adiciona resultado ao histórico
                self.state.add_tool_result(
                    tool_call.get("call_id", ""),
                    json.dumps(result, ensure_ascii=False),
                )

            # Se houve tools, pode gerar nova resposta incorporando resultados
            if tool_results:
                followup_prompt = self._build_followup_prompt(llm_response.text, tool_results)
                followup_response = self._llm.generate(
                    prompt=followup_prompt,
                    tools=None,  # Sem tools no follow-up
                    max_tokens=256,
                    temperature=0.3,
                )
                # Atualiza mensagem do assistant com resposta final
                assistant_msg.content = followup_response.text
                llm_response.text = followup_response.text

        # Sintetiza e toca resposta
        if llm_response.text.strip():
            self._speak(llm_response.text)

    def _build_followup_prompt(self, previous_response: str, tool_results: List) -> str:
        """Constrói prompt para resposta final após tools."""
        results_str = "\n".join([f"Resultado {i}: {json.dumps(r, ensure_ascii=False)}" for i, r in enumerate(tool_results)])
        return f"""Resposta anterior: {previous_response}

Resultados das ferramentas:
{results_str}

Gere uma resposta final natural em português para o usuário, incorporando os resultados acima. Seja conciso."""

    def _execute_tool(self, tool_call: Dict) -> Dict:
        """Executa uma tool call."""
        name = tool_call.get("name")
        arguments = tool_call.get("arguments", {})

        logger.info(f"🔧 Executando tool: {name}({arguments})")

        # Memory tools
        if name.startswith("memoria_"):
            from oraculo.memory.tools import execute_memory_tool
            return execute_memory_tool(name, arguments)

        # Automation tools
        if name.startswith("automacao_") or name.startswith("sistema_"):
            if self._automation and self._automation.is_connected:
                result = self._automation.execute_action(name, arguments)
                return {"success": result.success, "message": result.message, "data": result.data}
            else:
                return {"success": False, "message": "Automação não disponível"}

        return {"success": False, "message": f"Tool desconhecida: {name}"}

    def _speak(self, text: str) -> None:
        """Sintetiza e toca texto."""
        import tempfile

        logger.debug(f"🔊 Falando: {text[:50]}...")

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            temp_path = Path(f.name)

        try:
            result = self._tts.synthesize(text, temp_path)
            if result.success:
                from oraculo.utils.audio import play_audio
                play_audio(temp_path)
            else:
                logger.error(f"TTS falhou: {result.error}")
        finally:
            temp_path.unlink(missing_ok=True)

    def shutdown(self) -> None:
        """Desliga graciosamente."""
        if self._shutdown:
            return

        logger.info("🛑 Desligando ORÁCULO...")
        self._running = False
        self._shutdown = True

        self._hide_foreground_notification()
        self.wakelock.stop_monitor()
        self.wakelock.release()

        # Unload components
        for component in [self._stt, self._llm, self._tts, self._automation]:
            if component and hasattr(component, 'unload'):
                try:
                    component.unload()
                except Exception:
                    pass

        logger.info("✅ ORÁCULO desligado")

    def _signal_handler(self, signum, frame):
        logger.info(f"Sinal {signum} recebido")
        self.shutdown()


# Entry point para CLI
def main():
    import sys

    config_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"

    orchestrator = Orchestrator(config_path)
    if orchestrator.initialize():
        orchestrator.run()
    else:
        logger.error("Falha na inicialização")
        sys.exit(1)


if __name__ == "__main__":
    main()