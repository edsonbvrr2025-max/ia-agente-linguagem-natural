"""
Estado da conversa — Histórico, contexto, memória de curto prazo.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime
from enum import Enum


class MessageRole(Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"


@dataclass
class Message:
    """Uma mensagem na conversa."""
    role: MessageRole
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    tool_call_id: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role": self.role.value,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
            "tool_calls": self.tool_calls,
            "tool_call_id": self.tool_call_id,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Message":
        return cls(
            role=MessageRole(data["role"]),
            content=data["content"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            tool_calls=data.get("tool_calls", []),
            tool_call_id=data.get("tool_call_id", ""),
            metadata=data.get("metadata", {}),
        )


@dataclass
class ConversationState:
    """Estado completo da conversa."""
    messages: List[Message] = field(default_factory=list)
    max_history_pairs: int = 6  # Pares user/assistant
    current_tool_call: Optional[Dict] = None
    pending_confirmation: Optional[Dict] = None
    wake_word_active: bool = False
    interrupted: bool = False

    def add_user_message(self, content: str) -> Message:
        msg = Message(role=MessageRole.USER, content=content)
        self.messages.append(msg)
        return msg

    def add_assistant_message(self, content: str, tool_calls: List = None) -> Message:
        msg = Message(
            role=MessageRole.ASSISTANT,
            content=content,
            tool_calls=tool_calls or [],
        )
        self.messages.append(msg)
        return msg

    def add_tool_result(self, tool_call_id: str, content: str) -> Message:
        msg = Message(
            role=MessageRole.TOOL,
            content=content,
            tool_call_id=tool_call_id,
        )
        self.messages.append(msg)
        return msg

    def get_recent_history(self, max_pairs: int = None) -> List[Message]:
        """Retorna histórico recente (últimos N pares user/assistant)."""
        if max_pairs is None:
            max_pairs = self.max_history_pairs

        # Conta pares user/assistant a partir do fim
        pairs = 0
        result = []
        for msg in reversed(self.messages):
            result.insert(0, msg)
            if msg.role == MessageRole.USER:
                pairs += 1
                if pairs >= max_pairs:
                    break

        return result

    def get_history_for_llm(self, max_pairs: int = None) -> List[Dict]:
        """Retorna histórico formatado para LLM (OpenAI chat format)."""
        history = self.get_recent_history(max_pairs)
        return [
            {"role": msg.role.value, "content": msg.content}
            for msg in history
            if msg.role in (MessageRole.USER, MessageRole.ASSISTANT)
        ]

    def clear_history(self) -> None:
        self.messages.clear()

    def get_last_user_message(self) -> Optional[Message]:
        for msg in reversed(self.messages):
            if msg.role == MessageRole.USER:
                return msg
        return None

    def get_last_assistant_message(self) -> Optional[Message]:
        for msg in reversed(self.messages):
            if msg.role == MessageRole.ASSISTANT:
                return msg
        return None

    def set_pending_confirmation(self, action: str, params: Dict, description: str) -> None:
        self.pending_confirmation = {
            "action": action,
            "params": params,
            "description": description,
            "timestamp": datetime.now().isoformat(),
        }

    def clear_pending_confirmation(self) -> None:
        self.pending_confirmation = None

    def has_pending_confirmation(self) -> bool:
        return self.pending_confirmation is not None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "messages": [m.to_dict() for m in self.messages],
            "max_history_pairs": self.max_history_pairs,
            "current_tool_call": self.current_tool_call,
            "pending_confirmation": self.pending_confirmation,
            "wake_word_active": self.wake_word_active,
            "interrupted": self.interrupted,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConversationState":
        state = cls(
            max_history_pairs=data.get("max_history_pairs", 6),
            wake_word_active=data.get("wake_word_active", False),
            interrupted=data.get("interrupted", False),
        )
        state.messages = [Message.from_dict(m) for m in data.get("messages", [])]
        state.current_tool_call = data.get("current_tool_call")
        state.pending_confirmation = data.get("pending_confirmation")
        return state