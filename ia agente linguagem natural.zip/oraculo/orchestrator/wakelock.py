"""
Gerenciador de Wakelock — Mantém CPU acordada durante operação.

No Android 12+, essencial para evitar que o processo seja morto.
Usa termux-wake-lock / termux-wake-unlock.
"""

import subprocess
import threading
import time
from typing import Optional

from oraculo.utils.logger import get_logger
from oraculo.utils.helpers import check_command_exists, run_command

logger = get_logger(__name__)


class WakelockManager:
    """Gerencia wakelock do Termux."""

    def __init__(self):
        self._active = False
        self._lock = threading.Lock()
        self._monitor_thread: Optional[threading.Thread] = None
        self._stop_monitor = threading.Event()
        self._available = check_command_exists("termux-wake-lock")

    def acquire(self) -> bool:
        """Adquire wakelock."""
        if not self._available:
            logger.warning("termux-wake-lock não disponível")
            return False

        with self._lock:
            if self._active:
                return True

            result = run_command(["termux-wake-lock"], timeout=5)
            if result[0] == 0:
                self._active = True
                logger.debug("Wakelock adquirido")
                return True
            else:
                logger.error(f"Falha adquirindo wakelock: {result[2]}")
                return False

    def release(self) -> bool:
        """Libera wakelock."""
        if not self._available:
            return True

        with self._lock:
            if not self._active:
                return True

            result = run_command(["termux-wake-unlock"], timeout=5)
            if result[0] == 0:
                self._active = False
                logger.debug("Wakelock liberado")
                return True
            else:
                logger.error(f"Falha liberando wakelock: {result[2]}")
                return False

    def is_active(self) -> bool:
        return self._active

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *args):
        self.release()

    # =========================================================================
    # Monitor automático (re-adquire se perdido)
    # =========================================================================

    def start_monitor(self, interval: int = 30) -> None:
        """Inicia thread monitor que re-adquire wakelock periodicamente."""
        if self._monitor_thread and self._monitor_thread.is_alive():
            return

        self._stop_monitor.clear()
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            args=(interval,),
            daemon=True,
            name="WakelockMonitor",
        )
        self._monitor_thread.start()
        logger.debug("Wakelock monitor iniciado")

    def stop_monitor(self) -> None:
        """Para thread monitor."""
        self._stop_monitor.set()
        if self._monitor_thread:
            self._monitor_thread.join(timeout=5)
            self._monitor_thread = None
        logger.debug("Wakelock monitor parado")

    def _monitor_loop(self, interval: int) -> None:
        """Loop de monitoramento."""
        while not self._stop_monitor.is_set():
            time.sleep(interval)
            if self._stop_monitor.is_set():
                break

            with self._lock:
                if self._active:
                    # Verifica se ainda ativo (termux-wake-lock não tem query, só tenta re-adquirir)
                    result = run_command(["termux-wake-lock"], timeout=5)
                    if result[0] != 0:
                        logger.warning("Wakelock perdido, re-adquirindo...")
                        self._active = False
                        self.acquire()


# Instância global
_wakelock_manager: Optional[WakelockManager] = None


def get_wakelock_manager() -> WakelockManager:
    global _wakelock_manager
    if _wakelock_manager is None:
        _wakelock_manager = WakelockManager()
    return _wakelock_manager