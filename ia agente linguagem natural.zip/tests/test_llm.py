"""
Testes para LLM.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from oraculo.config import get_config
from oraculo.llm import create_llm, list_engines
from oraculo.utils.logger import setup_logging


def test_llm_engines():
    print("Engines LLM registradas:", list_engines())


def test_llama_cpp():
    config = get_config()
    llm_config = config.llm

    if llm_config.engine != "llama_cpp":
        print(f"Engine configurado é {llm_config.engine}")
        return True

    model_path = Path(llm_config.model)
    if not model_path.exists():
        print(f"Modelo não encontrado: {model_path}")
        print("Baixe com: bash scripts/download_models.sh --llm qwen2.5-3b-q4")
        return False

    llm = create_llm("llama_cpp", model_path, llm_config.__dict__)
    if not llm or not llm.load():
        print("Falha carregando llama.cpp")
        return False

    # Teste simples
    print("Testando geração...")
    response = llm.generate(
        prompt="Diga 'olá mundo' em português:",
        max_tokens=20,
        temperature=0.1,
    )

    print(f"Resposta: {response.text}")
    print(f"Tool calls: {response.tool_calls}")
    print(f"Usage: {response.usage}")

    # Teste tokenização
    tokens = llm.tokenize("olá mundo")
    print(f"Tokens para 'olá mundo': {tokens} ({len(tokens)} tokens)")

    detok = llm.detokenize(tokens)
    print(f"Detokenizado: {detok}")

    return True


def test_function_calling():
    """Testa function calling se modelo suportar."""
    config = get_config()
    llm_config = config.llm

    if llm_config.engine != "llama_cpp":
        return True

    model_path = Path(llm_config.model)
    if not model_path.exists():
        return True

    llm = create_llm("llama_cpp", model_path, llm_config.__dict__)
    if not llm or not llm.load():
        return False

    # Tool simples
    tools = [{
        "type": "function",
        "function": {
            "name": "teste_tool",
            "description": "Ferramenta de teste",
            "parameters": {
                "type": "object",
                "properties": {
                    "mensagem": {"type": "string"}
                },
                "required": ["mensagem"]
            }
        }
    }]

    response = llm.generate(
        prompt="Use a ferramenta teste_tool com mensagem 'funcionou'",
        tools=tools,
        tool_choice="auto",
        max_tokens=100,
    )

    print(f"Function calling test: {response.tool_calls}")
    return True


def main():
    setup_logging()
    print("="*50)
    print("  TESTE LLM")
    print("="*50)

    test_llm_engines()
    print()

    all_passed = True
    all_passed &= test_llama_cpp()
    all_passed &= test_function_calling()

    print("\n" + "="*50)
    if all_passed:
        print("  ✅ TODOS OS TESTES PASSARAM")
    else:
        print("  ❌ ALGUNS TESTES FALHARAM")
    print("="*50)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())