"""
Sistema de Memória do ORÁCULO.

Dois níveis:
1. Arquivos Markdown (memoria.md, perfil.md) — legíveis, editáveis por voz
2. Índice vetorial (sqlite-vec) — busca semântica para muitos fatos
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class MemoryFact:
    """Um fato na memória."""
    secao: str
    chave: str
    valor: str
    contexto: str = ""
    timestamp: str = ""


class MemoryBackend(ABC):
    """Interface base para backends de memória."""

    @abstractmethod
    def adicionar(self, secao: str, chave: str, valor: str, contexto: str = "") -> bool:
        pass

    @abstractmethod
    def remover(self, secao: str, chave: str) -> bool:
        pass

    @abstractmethod
    def buscar(self, query: str, secao: str = "Todas", top_k: int = 5) -> List[MemoryFact]:
        pass

    @abstractmethod
    def listar(self, secao: str = "Todas") -> List[MemoryFact]:
        pass

    @abstractmethod
    def carregar_tudo(self) -> Dict[str, List[MemoryFact]]:
        pass


# Registry
_BACKENDS: Dict[str, type] = {}


def register_backend(name: str, backend_class: type) -> None:
    _BACKENDS[name] = backend_class


def get_backend(name: str) -> Optional[type]:
    return _BACKENDS.get(name)


def create_memory(backend_name: str, **kwargs) -> Optional[MemoryBackend]:
    backend_class = get_backend(backend_name)
    if backend_class is None:
        return None
    return backend_class(**kwargs)